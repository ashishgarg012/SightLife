﻿var SightLife_TissueEval = (function (SightLife_TissueEval) {
    SightLife_TissueEval.showDiscardReasons = function showDiscardReasons() {
        var gems_approvaloutcome = Xrm.Page.getAttribute("gems_approvaloutcome").getValue();
        var gems_tissuedisposition = Xrm.Page.getAttribute("gems_tissuedisposition").getValue();

        if (gems_tissuedisposition == 5)
            //gems_approvaloutcome == 2 &&
        {
            Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("sec_Discard_reasons").setVisible(true);
        } else {
            Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("sec_Discard_reasons").setVisible(false);
        }
    };

    return SightLife_TissueEval;
}
	(SightLife_TissueEval || {}));

SightLife_TissueEval.showDiscardReasons

function getTissueEvalDetails() {
    var donorId;
    var result = {};
    if (Xrm.Page.getAttribute("gems_medicalreviewidid") != null && Xrm.Page.getAttribute("gems_medicalreviewidid") != undefined) {
        if (Xrm.Page.getAttribute("gems_medicalreviewidid").getValue() != null && Xrm.Page.getAttribute("gems_medicalreviewidid").getValue() != undefined) {
            donorId = Xrm.Page.getAttribute("gems_medicalreviewidid").getValue()[0].id;

            var tissueEvalXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
				"<entity name='gems_tissuedetail'>" +
				"<attribute name='gems_tissuedetailid' />" +
				"<attribute name='gems_name' />" +
				"<attribute name='createdon' />" +
				"<attribute name='gems_eye' />" +
				"<order attribute='gems_name' descending='false' />" +
				"<filter type='and'>" +
				"<condition attribute='gems_medicalreviewidid' operator='eq' value='" + donorId + "' />" +
				"</filter>" +
				"</entity>" +
				"</fetch>";

            result = XrmServiceToolkit.Soap.Fetch(tissueEvalXml);
        }
    }
    return result;
}

function tissueEvaluation() {
    var tissueEvalDetails = getTissueEvalDetails();

    var formType = Xrm.Page.ui.getFormType();

    if (formType == 1) {
        if (tissueEvalDetails.length > 0 && tissueEvalDetails.length < 2) {
            var eye = tissueEvalDetails[0].attributes.gems_eye.value;
            if (eye == 1) { //OD = 1 & OS = 2
                Xrm.Page.getAttribute("gems_eye").setValue(2);
                Xrm.Page.getControl("gems_eye").setDisabled(true);
            } else if (eye == 2) {
                Xrm.Page.getAttribute("gems_eye").setValue(1);
                Xrm.Page.getControl("gems_eye").setDisabled(true);
            }
        } else if (tissueEvalDetails.length >= 2) {
            Xrm.Utility.alertDialog("You have already added two tissues for the selected Donor.");
            //context.getEventArgs().preventDefault();
        }
    }
}

function onSaveTissueEval(context) {
    var tissueEvalDetails = getTissueEvalDetails();
    if (tissueEvalDetails.length > 2) {
        Xrm.Utility.alertDialog("You have already added two tissues for the selected Donor.");
        context.getEventArgs().preventDefault();
    }
}
