﻿function HideSocialPaneTab() {
    var ctrlElement = parent.document.getElementById("header_notescontrol");
    //.getElementById() is not supported by many browsers and causes errors
    if (ctrlElement != null && ctrlElement.children != null && ctrlElement.children.length > 0) {
        for (var ele = 0; ele < ctrlElement.children.length; ele++) {
            var ctrl = ctrlElement.children[ele];
            if (ctrl.title == 'ACTIVITIES') {
                ctrl.style.display = "none";
                if (ele + 1 < ctrlElement.children.length) {
                    ctrlElement.children[ele + 1].click();
                    return;
                } else if ((ele - 1) >= 0) {
                    ctrlElement.children[ele - 1].click();
                    return;
                }
            }
        }
    }
}

function showDonorMedInfoTabsForMobile() {
    debugger;
    var client = Xrm.Page.context.client.getClient();

    if (Xrm.Page.getAttribute("gems_eyesorcorneasrecovered") != null && Xrm.Page.getAttribute("gems_eyesorcorneasrecovered") != undefined) {
        var eyesOrCorneasRecovered = Xrm.Page.getAttribute("gems_eyesorcorneasrecovered").getValue();

        if (client.toLowerCase() == "mobile") {
            Xrm.Page.ui.tabs.get("DonorMedicalInformation").setVisible(true);
            Xrm.Page.ui.tabs.get("LaboratoryInformationTab").setVisible(true);

            if (eyesOrCorneasRecovered == 1) {
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EYEASSESSMENTPENLIGHTEXAM").setVisible(false);
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EyeAssessmentOS").setVisible(true);
            } else if (eyesOrCorneasRecovered == 2) {
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EyeAssessmentOS").setVisible(false);
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EYEASSESSMENTPENLIGHTEXAM").setVisible(true);
            } else {
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EyeAssessmentOS").setVisible(true);
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EYEASSESSMENTPENLIGHTEXAM").setVisible(true);
            }
        } else {
            Xrm.Page.ui.tabs.get("DonorMedicalInformation").setVisible(false);
            Xrm.Page.ui.tabs.get("LaboratoryInformationTab").setVisible(false);
        }
    }
}

function wbcChange() {
    debugger;
    var client = Xrm.Page.context.client.getClient();

    if (client.toLowerCase() == "mobile") {
        if (Xrm.Page.getAttribute("gems_wbcsperformed") != null && Xrm.Page.getAttribute("gems_wbcsperformed") != undefined) {
            var wbcsPerformed = Xrm.Page.getAttribute("gems_wbcsperformed").getValue();

            if (wbcsPerformed) {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("WBCPerformedData").setVisible(true);
            } else {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("WBCPerformedData").setVisible(false);
            }
        }
    }
}

function temperatureChange() {
    debugger;
    var client = Xrm.Page.context.client.getClient();

    if (client.toLowerCase() == "mobile") {
        if (Xrm.Page.getAttribute("gems_temperaturerecorded") != null && Xrm.Page.getAttribute("gems_temperaturerecorded") != undefined) {
            var temperatureRecorded = Xrm.Page.getAttribute("gems_temperaturerecorded").getValue();

            if (temperatureRecorded) {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("TemperatureReason").setVisible(false);
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("TemperatureData").setVisible(true);
            } else {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("TemperatureData").setVisible(false);
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("TemperatureReason").setVisible(true);
            }
        }
    }
}

function culturesChange() {
    debugger;
    var client = Xrm.Page.context.client.getClient();

    if (client.toLowerCase() == "mobile") {
        if (Xrm.Page.getAttribute("gems_culturesdone") != null && Xrm.Page.getAttribute("gems_culturesdone") != undefined) {
            var culturesDone = Xrm.Page.getAttribute("gems_culturesdone").getValue();
            if (culturesDone) {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("CulturesData").setVisible(true);
            } else {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("CulturesData").setVisible(false);
            }
        }
    }
}
