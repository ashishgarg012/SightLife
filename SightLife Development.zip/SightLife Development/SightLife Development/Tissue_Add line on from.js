﻿function reportButtons() {
    // debugger;
    var WebResourceArray;
    var entityName = Xrm.Page.data.entity.getEntityName();
    if (entityName == "gems_request") {
        WebResourceArray = ["WebResource_RecipientInformation"];
    }
    else if (entityName == "gems_distribution") {
        WebResourceArray = ["WebResource_AdverseReactionButton", "WebResource_testbutton"];
    }
    else if (entityName == "gems_tissuedetail") {
        WebResourceArray = ["WebResource_tissueDetailsButton", "WebResource_adhesiveButton", "WebResource_PostCustForm"];
    }
    hideandshowbuttons(WebResourceArray);
}

function hideandshowbuttons(webresourcenames) {
    for (var i = 0; i < webresourcenames.length; i++) {
        var resource = webresourcenames[i];
        if (Xrm.Page.ui.getFormType() == 1) {
            Xrm.Page.getControl(resource).setVisible(false);
        }
        else {
            Xrm.Page.getControl(resource).setVisible(true);
        }
    }
}



//***********Add Header line on Tissue & Placement form*************************************************
function HeaderLine() {
   // debugger;
    if (parent.document.getElementById("crmFormHeaderTop") != null) {
        parent.document.getElementById("crmFormHeaderTop").style.borderBottom = "2px solid";
        parent.document.getElementById("crmFormHeaderTop").style.borderBottomColor = "#b3aeae";
    }
}


//***********Add Header line on Request form*************************************************

function HeaderLineRequestPage() {
    //  debugger;
    if (parent.document.getElementById("crmFormHeaderTop") != null) {
        parent.document.getElementById("crmFormHeaderTop").style.borderBottom = "2px solid";
        parent.document.getElementById("crmFormHeaderTop").style.borderBottomColor = "#b3aeae";
    }
    if (parent.document.getElementById("HeaderTitleElement") != null) {
        parent.document.getElementById("HeaderTitleElement").style.marginBottom = "-2%";
    }
}

//**************************************************************************************************

