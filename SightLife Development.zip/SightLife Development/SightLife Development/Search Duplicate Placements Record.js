﻿
//---To search tissue is already placed for placement record on Placement entity...fun on change  of "Tissue Disposition" field
function searchDuplicatePlacementsRecord() {
    debugger;
    var collection;
    var message = "This Tissue is already placed.";
    var type = "INFO"; //INFO, WARNING, ERROR
    var id = "Info1"; //Notification Id
    var time = 3000; //Display time in milliseconds
    lookupselectTissue = Xrm.Page.data.entity.attributes.get("gems_tissuedetail");

    if (lookupselectTissue.getValue() != null) {
        entityId = lookupselectTissue.getValue()[0].id;
        entityName = lookupselectTissue.getValue()[0].entityType;
        entityLabel = lookupselectTissue.getValue()[0].name;

        if (entityLabel != null && entityLabel != undefined) {
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
           "<entity name='gems_distribution'>" +
             "<attribute name='gems_distributionid' />" +
             "<attribute name='gems_name' />" +
              "<order attribute='gems_name' descending='false' />" +
             "<filter type='and'>" +
               "<condition attribute='gems_tissuedetailname' operator='eq' value='" + entityLabel + "' />" +
               "<condition attribute='gems_tissuedisposition' operator='eq' value='1' />" +
             "</filter>" +
           "</entity>" +
         "</fetch>";

            collection = XrmServiceToolkit.Soap.Fetch(fetchXml);
        }
        if (collection.length > 0) {

            Xrm.Page.ui.setFormNotification(message, type, id);
        }
        else {
            Xrm.Page.ui.clearFormNotification(id);
        }

        //Wait the designated time and then remove tissue if it was already placed
        setTimeout(
            function () {
                if (collection.length > 0) {
                    Xrm.Page.getAttribute("gems_tissuedetail").setValue();
                }
            },
            time
        );

    }
}


//----The user should not be able to create multiple placements for a single request on Placement entity...fun on change 
//----of "Select Request" field
function toCheckSingleRequestforSinglePlacement() {
    debugger;
    var collection;
    var message = "This Request is already placed.";
    var type = "INFO"; //INFO, WARNING, ERROR
    var id = "Info1"; //Notification Id
    var time = 3000; //Display time in milliseconds
    lookupselectRequest = Xrm.Page.data.entity.attributes.get("gems_requestdetail");

    if (lookupselectRequest.getValue() != null) {
        selectRequestId = lookupselectRequest.getValue()[0].id;
        selectRequestName = lookupselectRequest.getValue()[0].entityType;
        selectRequest = lookupselectRequest.getValue()[0].name;

        if (selectRequestId != null && selectRequestId != undefined) {
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                   "<entity name='gems_distribution'>" +
                     "<attribute name='gems_distributionid' />" +
                     "<attribute name='gems_name' />" +
                      "<order attribute='gems_name' descending='false' />" +
                     "<filter type='and'>" +
                       "<condition attribute='gems_requestdetail' operator='eq' value='" + selectRequestId + "' />" +
                     "</filter>" +
                   "</entity>" +
                 "</fetch>";

            collection = XrmServiceToolkit.Soap.Fetch(fetchXml);
        }

        if (collection.length > 0) {
            Xrm.Page.ui.setFormNotification(message, type, id);
        }
        else {
            Xrm.Page.ui.clearFormNotification(id);
        }

        //Wait the designated time and then remove request if it was already placed
        setTimeout(
            function () {
                if (collection.length > 0) {
                    Xrm.Page.getAttribute("gems_requestdetail").setValue();
                }
            },
            time
        );

    }
}


