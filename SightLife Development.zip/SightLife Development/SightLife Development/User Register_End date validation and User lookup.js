﻿//End Date should be later than Start Date Validation on User Register entity...9 Feb 2017...on change of End date field
function userRegisterStartDate_Validation() {
    debugger;
    if (Xrm.Page.getAttribute("gems_startdate") != null || Xrm.Page.getAttribute("gems_startdate") != undefined) {
        var startDate = Xrm.Page.getAttribute("gems_startdate").getValue();
    }
    if (Xrm.Page.getAttribute("gems_enddate") != null) {
        var endDate = Xrm.Page.getAttribute("gems_enddate").getValue();

        if (endDate != null && startDate != null && endDate < startDate) {
            alert("The End Date should be later than Start Date");
            Xrm.Page.getAttribute("gems_enddate").setValue();
        }
    }
}

