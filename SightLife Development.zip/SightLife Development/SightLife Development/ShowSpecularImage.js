﻿//To open dialoge box & show Annotation(precut) image
//function showImage() {
//    debugger;
//    var parameters = {};
//    var objectID = Xrm.Page.data.entity.getId();
//    parameters["regardingObjectId_0"] = objectID;
//    Xrm.Utility.openWebResource("gems_showEntityImage.html?typename=gems_tissuedetail&id=" + objectID, null, 400, 400);
//}

//To open dialoge box & show Annotation(precut) image,Postcut image
function showImage(buttonName) {
    debugger;
    var parameters = {};
    var objectID = Xrm.Page.data.entity.getId();
    parameters["regardingObjectId_0"] = objectID;
    Xrm.Utility.openWebResource("gems_showEntityImage.html?typename=gems_tissuedetail&id=" + objectID, buttonName, 400, 400);
}


