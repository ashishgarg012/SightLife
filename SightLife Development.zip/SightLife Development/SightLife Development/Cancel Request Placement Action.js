﻿//----To Call Workflow on Cancel Request to update Request Status=Cancel & change status,status reason as Inactive on Request Entity
function callRequestWorkflow() {
    debugger;
     var r = confirm("Whether you want to cancel the Request.");
    if (r == true) {
        var entityId = Xrm.Page.data.entity.getId();
        var objectID = entityId.replace("{", "").replace("}", "");
        Process.callWorkflow("81F1969B-EB64-45EC-8866-8AD103C16837",
        objectID,
        function () {
            alert("Request Canceled successfully");
            window.parent.Xrm.Utility.openEntityForm("gems_request", objectID);
        },
        function () {
            alert("Error executing Request Cancel");
        }
        );
    }
}
//-------To Call Workflow on Cancel Request to update Request Status=Cancel & change status,status reason as Inactive on Request Entity

//-------To Call Workflow on Cancel Placement to update Tissue Disposition=Cancel & change status,status reason as Inactive on Request Entity
function callPlacementWorkflow() {
    debugger;
    var r = confirm("Whether you want to cancel the Placement.");
    if (r == true) {
        var entityId = Xrm.Page.data.entity.getId();
        var objectID = entityId.replace("{", "").replace("}", "");
        Process.callWorkflow("7ff206e8-f29f-4cf9-96ef-b5af95fa83bb",
        objectID,
        function () {
            alert("Placement Canceled successfully");
            window.parent.Xrm.Utility.openEntityForm("gems_distribution", objectID);
        },
        function () {
            alert("Error executing Placement Cancel");
        }
        );
    }
}
//------To Call Workflow on Cancel Placement to update Tissue Disposition=Cancel & change status,status reason as Inactive on Request Entity


