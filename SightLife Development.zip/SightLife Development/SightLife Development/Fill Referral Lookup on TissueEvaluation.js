﻿/*//------To get Age field(from Referral entity) in Tissue lookup on Placement entity-----1)Added Referral lookup on Tissue Eval entity----
//------2)Fill this lookup value using below JS function---------------------------------------------------------------------------------*/
function getReferralValueOnTissueEvaluation() {
    debugger;
    //
    lookupFieldObject = Xrm.Page.data.entity.attributes.get("gems_medicalreviewidid");

    if (lookupFieldObject.getValue() != null) {
        entityId = lookupFieldObject.getValue()[0].id;
        entityName = lookupFieldObject.getValue()[0].entityType;
        entityLabel = lookupFieldObject.getValue()[0].name;
    }
    //
    var Name = entityLabel;
    var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
  "<entity name='gems_referral'>" +
    "<attribute name='gems_referralid' />" +
    "<attribute name='gems_name' />" +
    "<attribute name='createdon' />" +
    "<order attribute='gems_name' descending='false' />" +
    "<filter type='and'>" +
       "<condition attribute='gems_name' operator='eq' value='" + Name + "' />" +
    "</filter>" +
  "</entity>" +
"</fetch>";

    var collection = XrmServiceToolkit.Soap.Fetch(fetchXml);
    if (collection.length > 0) {

        if (collection[0].attributes["gems_referralid"] != null && collection[0].attributes["gems_referralid"] != undefined) {
            var referralid = collection[0].attributes["gems_referralid"].value
            var caseconfiguration = new Array();
            caseconfiguration[0] = new Object();
            caseconfiguration[0].id = referralid;
            caseconfiguration[0].name = lookupFieldObject.getValue()[0].name;
            caseconfiguration[0].entityType = "gems_referral";

            Xrm.Page.getAttribute("gems_referral").setValue(caseconfiguration);
        }
    }
}