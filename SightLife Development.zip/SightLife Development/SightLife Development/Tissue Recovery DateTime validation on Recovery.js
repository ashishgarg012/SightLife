﻿//Tissue Recovery should be greater or equal to Date/Time of Death Notification------16 feb

function recoveryDateofDeath_Validation() {
    debugger;
    var monthTissue; var dayTissue; var monthDeath; var dayDeath; var tissueRecoveryTime; var dateofdeathnotification; var flag;

    if (Xrm.Page.getAttribute("gems_tissuerecoverydatetime") != null || Xrm.Page.getAttribute("gems_tissuerecoverydatetime") != undefined) {
        tissueRecoveryTime = Xrm.Page.getAttribute("gems_tissuerecoverydatetime").getValue();
        if (tissueRecoveryTime != null || tissueRecoveryTime != undefined) {
            monthTissue = tissueRecoveryTime.getMonth() + 1;
            dayTissue = tissueRecoveryTime.getDate();
        }
    }
    if (Xrm.Page.getAttribute("gems_referralrecoverydeathnotificationdatetime") != null) {
        dateofdeathnotification = Xrm.Page.getAttribute("gems_referralrecoverydeathnotificationdatetime").getValue();
        if (dateofdeathnotification != null || dateofdeathnotification != undefined) {
            monthDeath = dateofdeathnotification.getMonth() + 1;
            dayDeath = dateofdeathnotification.getDate();
        }

        if (dayTissue == dayDeath) {
            var deathnoticationmillsec = dateofdeathnotification.getTime() + 1800000;
            Xrm.Page.getAttribute("gems_tissuerecoverydatetime").setValue(deathnoticationmillsec);
            tissueRecoveryTimeSameDay = Xrm.Page.getAttribute("gems_tissuerecoverydatetime").getValue();
            flag = true;
        }

        if (dateofdeathnotification != null && monthTissue <= monthDeath) {
            if (flag != true) {
                if (tissueRecoveryTime < dateofdeathnotification) {
                    alert("The tissue recovery date/time should be later than Death Notification Date/Time.");
                    Xrm.Page.getAttribute("gems_tissuerecoverydatetime").setValue();
                }
            }
            
        }
    }
}














