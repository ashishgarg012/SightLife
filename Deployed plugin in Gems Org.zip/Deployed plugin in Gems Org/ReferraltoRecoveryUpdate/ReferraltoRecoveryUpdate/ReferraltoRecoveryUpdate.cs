﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace ReferraltoRecoveryUpdate
{
    public class ReferraltoRecoveryUpdate : IPlugin
    {
        void IPlugin.Execute(IServiceProvider serviceProvider)
        {
            string donorID = string.Empty;

            IPluginExecutionContext executionContext = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService orgService = serviceFactory.CreateOrganizationService(executionContext.UserId);

            if (executionContext.InputParameters.Contains("Target") && executionContext.InputParameters["Target"] != null)
            {
                Entity enReferral = (Entity)executionContext.InputParameters["Target"];


                Entity preEntity = (Entity)executionContext.PreEntityImages["ReferralPreImage"];
                donorID = preEntity.Attributes["gems_name"].ToString();


                QueryExpression qe = new QueryExpression("gems_recovery");
                ColumnSet col = new ColumnSet("gems_name", "gems_referralrecoveryfirstname", "gems_referralrecoverylastname", "gems_datetimeofdeath", "gems_primarycausedeath");
                qe.ColumnSet = col;
                qe.Criteria.AddCondition("gems_name", ConditionOperator.Equal, donorID);

                EntityCollection targetRecovery = orgService.RetrieveMultiple(qe);

                if (targetRecovery.Entities.Count > 0)
                {
                    for (int i = 0; i < targetRecovery.Entities.Count; i++)
                    {

                        if (enReferral.Attributes.Contains("gems_donorfirstname"))
                        {
                            if (enReferral.Attributes["gems_donorfirstname"] != null)
                            {
                                targetRecovery[i].Attributes["gems_referralrecoveryfirstname"] = enReferral.Attributes["gems_donorfirstname"];
                            }
                        }

                        if (enReferral.Attributes.Contains("gems_donorlastname"))
                        {
                            if (enReferral.Attributes["gems_donorlastname"] != null)
                            {

                                targetRecovery[i].Attributes["gems_referralrecoverylastname"] = enReferral.Attributes["gems_donorlastname"];
                            }
                        }
                        if (enReferral.Attributes.Contains("gems_datetimeofdeath"))
                        {
                            if (enReferral.Attributes["gems_datetimeofdeath"] != null)
                            {
                                targetRecovery[i].Attributes["gems_datetimeofdeath"] = enReferral.Attributes["gems_datetimeofdeath"];
                            }
                        }
                        if (enReferral.Attributes.Contains("gems_deathnotificationdatetime"))
                        {
                            if (enReferral.Attributes["gems_deathnotificationdatetime"] != null)
                            {
                                targetRecovery[i].Attributes["gems_referralrecoverydeathnotificationdatetime"] = enReferral.Attributes["gems_deathnotificationdatetime"];
                            }
                        }
                        if (enReferral.Attributes.Contains("gems_deathcause1"))
                        {
                            if (enReferral.Attributes["gems_deathcause1"] != null)
                            {
                                string deathcause = string.Empty;
                                int deathoptionset = ((OptionSetValue)enReferral.Attributes["gems_deathcause1"]).Value;
                                switch (deathoptionset)
                                {
                                    case 1:
                                        deathcause = "Cancer";
                                        break;
                                    case 2:
                                        deathcause = "Heart Disease";
                                        break;
                                    case 3:
                                        deathcause = "Cerebral Vascular Accident";
                                        break;
                                    case 4:
                                        deathcause = "Respiratory Disease";
                                        break;
                                    case 5:
                                        deathcause = "Trauma";
                                        break;
                                    case 10:
                                        deathcause = "Other Diseases";
                                        break;
                                    default:
                                        deathcause = string.Empty;
                                        break;
                                }

                                targetRecovery[i].Attributes["gems_primarycausedeath"] = deathcause;
                            }
                        }
                        orgService.Update(targetRecovery[i]);
                    }
                }

            }
        }
    }
}
