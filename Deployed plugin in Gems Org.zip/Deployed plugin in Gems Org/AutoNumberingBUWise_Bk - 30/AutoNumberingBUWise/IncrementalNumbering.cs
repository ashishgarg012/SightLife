﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

// <copyright file="IncrementalNumbering.cs" company="Pragmasys" >
//     This code is property of pragmasys.
// </copyright>
// <summary>Workflow for Synchronizing Complaints with IRDA</summary>
namespace AutoNumberingBUWise
{

    /// <summary>
    /// Class IncrementalNumbering
    /// </summary>
    public class IncrementalNumbering
    {
        /// <summary>
        /// Constant String
        /// </summary>
        private const string SchemaName = "new_numberingscheme";

        /// <summary>
        /// The documentation text within the constructor's summary tag must begin with the text: Initializes a new instance of the <see cref="IncrementalNumbering" /> class
        /// </summary>
        public IncrementalNumbering()
        {

        }

        /// <summary>
        /// The documentation text within the constructor's summary tag must begin with the text: Initializes a new instance of the <see cref="IncrementalNumbering" /> class
        /// </summary>
        /// <param name="entity">new Entity</param>
        public IncrementalNumbering(Entity entity)
        {
            this.Id = new Guid(entity[Fields.Id].ToString());
            this.EntityName = entity[Fields.EntityName].ToString();
            this.PropertyName = entity[Fields.PropertyName].ToString();
            this.CurrentPosition = int.Parse(entity[Fields.CurrentPosition].ToString(), CultureInfo.CurrentCulture);

            this.PrefixType = (entity[Fields.PrefixType] as OptionSetValue).Value;
            this.Prefix = entity[Fields.Prefix].ToString();
            this.SuffixType = (entity[Fields.SuffixType] as OptionSetValue).Value;
            if (entity.Contains(Fields.Suffix))
            {
                this.Suffix = entity[Fields.Suffix].ToString();
            }
            this.Autonumberlength = int.Parse(entity[Fields.Autonumberlength].ToString(), CultureInfo.CurrentCulture);
            EntityReference temp = (EntityReference)entity[Fields.BusinessUnit];
            this.buId = new Guid(temp.Id.ToString());
        }

        /// <summary>
        /// Gets or sets GUID
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// Gets or sets EntityName
        /// </summary>
        public string EntityName { get; set; }

        /// <summary>
        /// Gets or sets PropertyName
        /// </summary>
        public string PropertyName { get; set; }

        /// <summary>
        /// Gets or sets CurrentPosition
        /// </summary>
        public int CurrentPosition { get; set; }

        /// <summary>
        /// Gets or sets PrefixType
        /// </summary>
        public int PrefixType { get; set; }

        /// <summary>
        /// Gets or sets Prefix
        /// </summary>
        public string Prefix { get; set; }

        /// <summary>
        /// Gets or sets SuffixType
        /// </summary>
        public int SuffixType { get; set; }

        /// <summary>
        /// Gets or sets Suffix
        /// </summary>
        public string Suffix { get; set; }

        /// <summary>
        /// Gets or sets Auto number length
        /// </summary>
        public int Autonumberlength { get; set; }
        /// <summary>
        /// Gets or sets GUID of Business unit
        /// </summary>
        public Guid buId { get; set; }


        /// <summary>
        /// method IncrementalNumbering GetSettings
        /// </summary>
        /// <param name="service">organization Service</param>
        /// <param name="entityName">entity name</param>
        /// <returns>setting Increment numbering</returns>
        public static IncrementalNumbering GetSettings(IOrganizationService service, string entityName, Guid buGuid)
        {
            IncrementalNumbering setting = null;

            QueryExpression query = new QueryExpression()
            {
                EntityName = IncrementalNumbering.SchemaName,
                ColumnSet = new ColumnSet(true),
                Criteria =
                {
                    Conditions =
                    {
                        new ConditionExpression(Fields.EntityName, ConditionOperator.Equal, entityName),
                        new ConditionExpression(Fields.BusinessUnit, ConditionOperator.Equal, buGuid)
                    }
                }
            };
            DataCollection<Entity> entityCollection = service.RetrieveMultiple(query).Entities;

             if (entityCollection.Count == 1)
            {
                foreach (Entity ent in entityCollection)
                {
                    setting = new IncrementalNumbering(ent);
                }
                return setting;
            }
            else
            {
                /* foreach (Entity ent in entityCollection)
                 {
                     if (((Microsoft.Xrm.Sdk.EntityReference)(ent.Attributes["pcl_center"])).Id == centerGuid)
                     {
                         setting = new IncrementalNumbering(ent);
                         return setting;
                     }
                 }*/
            }

            return setting;
        }

        /// <summary>
        /// function Increment updating the auto numbering entity record.
        /// </summary>
        /// <param name="service">organization service</param>
        /// <param name="next">integer next</param>
        /// <returns>true false</returns>
        public bool Increment(IOrganizationService service, int next)
        {
            bool success = false;
            try
            {
                this.CurrentPosition = next;

                Entity autonumbering = this.ToDynamic();
                service.Update(autonumbering);
                success = true;
            }
            catch (System.Web.Services.Protocols.SoapException ex)
            {
                throw ex;
            }

            return success;
        }

        /// <summary>
        /// returns entity with id
        /// </summary>
        /// <returns>return entity</returns>
        public Entity ToDynamic()
        {
            Entity entity = new Entity(IncrementalNumbering.SchemaName);
            entity.Id = this.Id;
            entity[Fields.CurrentPosition] = this.CurrentPosition;
            return entity;
        }

        /// <summary>
        /// Constant String
        /// </summary>
        private static class Fields
        {
            /// <summary>
            /// string ID
            /// </summary>
            public const string Id = "new_numberingschemeid";

            /// <summary>
            /// string EntityName
            /// </summary>
            public const string EntityName = "new_entityschemaname";

            /// <summary>
            /// string PropertyName
            /// </summary>
            public const string PropertyName = "new_fieldschemaname";

            /// <summary>
            /// string CurrentPosition
            /// </summary>
            public const string CurrentPosition = "new_currentnumber";

            /// <summary>
            /// string PrefixType
            /// </summary>
            public const string PrefixType = "new_prefixtype";

            /// <summary>
            /// string Prefix
            /// </summary>
            public const string Prefix = "new_prefixvalue";

            /// <summary>
            /// string SuffixType
            /// </summary>
            public const string SuffixType = "new_suffixtype";

            /// <summary>
            /// string Suffix Type name
            /// </summary>
            public const string SuffixTypename = "new_suffixtypename";

            /// <summary>
            /// string Suffix
            /// </summary>
            public const string Suffix = "new_suffixvalue";

            /// <summary>
            /// string Auto number length
            /// </summary>
            public const string Autonumberlength = "new_autonumberlength";

            /// <summary>
            /// string SuffixType
            /// </summary>
            public const string BusinessUnit = "new_businessunit";

        }
    }
}

