﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Forms;

namespace AutoNumberingBUWise
{
    public class NumberingScheme : IPlugin
    {
        /// <summary>
        /// static string
        /// </summary>
        public static string oConfig = string.Empty;

        /// <summary>
        /// Tracing Service object
        /// </summary>
        private static ITracingService tracingService;

        /// <summary>
        /// lock object
        /// </summary>
        private static Object lockobject;

        /// <summary>
        /// null string value
        /// </summary>
        private string userrecordguid = null;

        /// <summary>
        /// global Configuration dictionary
        /// </summary>
        private Dictionary<string, string> globalConfig = new Dictionary<string, string>();

        /// <summary>
        /// The documentation text within the constructor's summary tag must begin with the text: Initializes a new instance of the <see cref="IncrementalNumberingPlugin" /> class.
        /// </summary>
        /// <param name="Config">string parameter</param>
        public NumberingScheme(string Config)
        {
            oConfig = Config;
        }

        /// <summary>
        /// The documentation text within the constructor's summary tag must begin with the text: Initializes a new instance of the <see cref="IncrementalNumberingPlugin" /> class.
        /// </summary>
        /// <param name="unscecured">string parameter</param>
        /// <param name="secured">string parameter</param>
        public NumberingScheme(string unscecured, string secured)
        {
            oConfig = unscecured;
        }

        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            IOrganizationService service = factory.CreateOrganizationService(context.UserId);

            tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            lockobject = new Object();

            string organizationname = context.OrganizationName.ToString(CultureInfo.CurrentCulture);
            this.ReadUnSecuredConfig(oConfig);
            //this.userrecordguid = this.GetValueForKey("autonumrecordguid");

            if (context.InputParameters.Contains("Target") &&
                context.InputParameters["Target"] is Entity)
            {

                Entity entity = (Entity)context.InputParameters["Target"];
                try
                {
                    //EntityReference entref= (EntityReference)context.InputParameters["Target"];
                    //tracingService.Trace("in invoice id" +entity.Attributes["new_centreid"]);
                    lock (lockobject)
                    {
                        // this.LockProgramExecution(service, tracingService);
                        Guid buGuid = new Guid();
                       // if (entity.LogicalName == "gems_referral")
                       // {
                            buGuid = context.BusinessUnitId;
                       // }
                        double suffixtypenone = Convert.ToDouble("3", CultureInfo.CurrentCulture); // comment- 798,330,002 value used for <Option None> is of <SuffixType>
                        double preffixtyoevalue = Convert.ToDouble("1", CultureInfo.CurrentCulture); // comment- 798,330,001 value used for <Option Value> is of <PrefixType>
                        double preffixtyoeexpresion = Convert.ToDouble("2", CultureInfo.CurrentCulture); // comment- 798,330,002 value used for <Option Expression> is of <PrefixType>

                        IncrementalNumbering setting = IncrementalNumbering.GetSettings(service, entity.LogicalName, buGuid);
                        if (setting != null)
                        {

                            if (setting.EntityName != null)
                            {
                                tracingService.Trace("entity.LogicalName=" + entity.LogicalName);
                                int next;
                                next = setting.CurrentPosition + 1;

                                int prefixtype = setting.PrefixType;
                                int suffixtype = setting.SuffixType;
                                int autonumlength = setting.Autonumberlength;
                                //string dd = DateTime.Today.ToString("dd", CultureInfo.CurrentCulture);
                                //string mm = DateTime.Today.ToString("MM", CultureInfo.CurrentCulture);
                                //string yy = DateTime.Today.ToString("yy", CultureInfo.CurrentCulture);
                                string casePrefix = setting.Prefix.ToLower(CultureInfo.CurrentCulture);
                                string nextnum = next.ToString(CultureInfo.CurrentCulture);
                                string prefix = string.Empty;
                                string suffix = string.Empty;
                                if (suffixtype != suffixtypenone)
                                {
                                    suffix = setting.Suffix;
                                }

                                if (prefixtype == preffixtyoevalue)
                                {
                                    DateTime dt = DateTime.Now;
                                    string year = dt.Year.ToString();
                                    //MessageBox.Show(year);
                                    prefix = setting.Prefix+year.Substring(2,2)+"-";
                                }
                                /*  else if (prefixtype == preffixtyoeexpresion)
                                  {
                                      switch (casePrefix)
                                      {
                                          case "dd":
                                              prefix = dd;
                                              break;
                                          case "mm":
                                              prefix = mm;
                                              break;
                                          case "ddmm":
                                              prefix = dd + mm;
                                              break;
                                          case "mmdd":
                                              prefix = mm + dd;
                                              break;
                                          case "mmyy":
                                              prefix = mm + yy;
                                              break;
                                          case "yymm":
                                              prefix = yy + mm;
                                              break;
                                          case "ddmmyy":
                                              prefix = dd + mm + yy;
                                              break;
                                          case "yymmdd":
                                              prefix = yy + mm + dd;
                                              break;
                                          default:
                                              prefix = dd + mm + yy;
                                              break;
                                      }
                                  }*/

                                int loopcount = autonumlength - next.ToString(CultureInfo.CurrentCulture).Length;
                                for (int i = 0; i < loopcount; i++)
                                {
                                    nextnum = "0" + nextnum;
                                }

                                nextnum = prefix + nextnum + suffix;

                                if (setting.Increment(service, next))
                                {
                                    entity[setting.PropertyName] = nextnum;
                                    tracingService.Trace("nextnum=" + nextnum);
                                }
                            }
                        }
                        else
                        {
                            throw new InvalidPluginExecutionException("You do not have numbering scheme access or you do not have record of numbering scheme for particular center.");
                        }
                    }
                   // throw new InvalidPluginExecutionException("error");
                }
                catch (Exception ex)
                {
                    tracingService.Trace("Incremental Numbering Plugin", "Execute", ex.Message);
                    throw new InvalidPluginExecutionException(ex.Message, ex);
                }
            }
        }

        /// <summary>
        /// Creates Key pair dictionary from unsecured configuration text
        /// </summary>
        /// <param name="localConfig">unsecured configuration text</param>
        private void ReadUnSecuredConfig(string localConfig)
        {
            try
            {
                this.globalConfig = new Dictionary<string, string>();
                if (!string.IsNullOrEmpty(localConfig))
                {
                    XmlDocument doc = new XmlDocument();

                    doc.LoadXml(localConfig);

                    foreach (XmlElement entityNode in doc.SelectNodes("/appSettings/add"))
                    {
                        this.globalConfig.Add(entityNode.GetAttribute("key").ToString(), entityNode.GetAttribute("value").ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Value for given key is returned
        /// </summary>
        /// <param name="keyName">key</param>
        /// <returns>string</returns>
        private string GetValueForKey(string keyName)
        {
            try
            {
                string valueString = string.Empty;
                if (this.globalConfig.ContainsKey(keyName))
                {
                    valueString = this.globalConfig[keyName];
                }
                else
                {
                    throw new InvalidPluginExecutionException("Given key was not present in config: " + keyName);
                }

                return valueString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// lock execution program
        /// </summary>
        /// <param name="service">service</param>
        /// <param name="traceservice">traceservice</param>
        //private void LockProgramExecution(IOrganizationService service, ITracingService traceservice)
        //{
        //    try
        //    {
        //        Guid contactNumberingSchemeGuid = Guid.Empty;
        //        contactNumberingSchemeGuid = new Guid(this.GetValueForKey("autonumrecordguid"));
        //        Random randNo = new Random();
        //        int newRandomNo = randNo.Next(1, 1000);
        //        Entity numSchemeRecordEntity = new Entity("pcl_numberingscheme");
        //        numSchemeRecordEntity.Id = contactNumberingSchemeGuid;
        //        numSchemeRecordEntity.Attributes["pcl_randomnumber"] = newRandomNo.ToString();
        //        service.Update(numSchemeRecordEntity);
        //    }
        //    catch (Exception exception001)
        //    {
        //        traceservice.Trace("error while applying lock : " + exception001.Message);
        //        throw exception001;
        //    }
        //}
    }
}
