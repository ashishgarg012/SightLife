﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Activities;
using Microsoft.Xrm.Sdk.Workflow;

namespace AnnotationtoEntityImage
{
    public class ReadAnnotation : CodeActivity
    {
        [Input("ObjectId")]
        [ReferenceTarget("gems_tissuedetail")]
        public InArgument<EntityReference> ObjectID { get; set; }

        [Output("Result")]
        public OutArgument<string> Result { get; set; }
        protected override void Execute(CodeActivityContext context)
        {
            IWorkflowContext workflowContext = (IWorkflowContext)context.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)context.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService trace = (ITracingService)context.GetExtension<ITracingService>();
            //retrieve annotation file

            EntityReference tissueeval = context.GetValue<EntityReference>(ObjectID);

            if (workflowContext.Depth <= 1)
            {
                #region Main
                try
                {
                    QueryExpression Notes = new QueryExpression { EntityName = "annotation", ColumnSet = new ColumnSet("filename", "subject", "annotationid", "documentbody") };
                    Notes.Criteria.AddCondition("notetext", ConditionOperator.Equal, "$precut$");
                    Notes.Criteria.AddCondition("objectid", ConditionOperator.Equal, tissueeval.Id);
                    Notes.Criteria.AddCondition("mimetype", ConditionOperator.BeginsWith, "image");
                    Notes.AddOrder("createdon", OrderType.Descending);
                    trace.Trace("Subject");
                    EntityCollection NotesRetrieve = service.RetrieveMultiple(Notes);
                    trace.Trace("Step 1");
                    if (NotesRetrieve != null && NotesRetrieve.Entities.Count == 1)
                    {
                        UpdateEntityImage(NotesRetrieve, trace, workflowContext, service, tissueeval);
                    }
                    else if (NotesRetrieve.Entities.Count > 1)
                    {
                        UpdateEntityImage(NotesRetrieve, trace, workflowContext, service, tissueeval);
                        for (int i = 1; i < NotesRetrieve.Entities.Count; i++)
                        {
                            service.Delete("annotation", NotesRetrieve[i].Id);
                            trace.Trace(NotesRetrieve[0].Attributes["filename"] + "Annotation Deleted");
                        }
                    }

                }
                catch (Exception e)
                {
                    throw new InvalidPluginExecutionException(e.Message);
                }
                #endregion

            }
        }

        public static void UpdateEntityImage(EntityCollection notes, ITracingService trace, IWorkflowContext workflowContext, IOrganizationService service, EntityReference tissueeval)
        {
            //converting document body content to bytes
            byte[] fil = Convert.FromBase64String(notes.Entities[0].Attributes["documentbody"].ToString());

            Image temp = ResizeImage(byteArrayToImage(fil), 144, 144, trace);
            trace.Trace("Image Object Made");
            byte[] fillfinal = imgToByteConverter(temp, trace);
            trace.Trace("Image Object Converted to byte Array");
            Entity tissue = service.Retrieve(workflowContext.PrimaryEntityName, tissueeval.Id, new ColumnSet(true));

            tissue["entityimage"] = fillfinal;

            trace.Trace("Before Update");
            service.Update(tissue);
            trace.Trace("Updated");

        }

        public static Bitmap ResizeImage(Image image, int width, int height, ITracingService tr)
        {
            var destRect = new Rectangle(0, 0, width, height);
            var destImage = new Bitmap(width, height);

            destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);
            tr.Trace("In Function");
            using (var graphics = Graphics.FromImage(destImage))
            {
                graphics.CompositingMode = CompositingMode.SourceOver;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.TextRenderingHint = TextRenderingHint.SingleBitPerPixelGridFit;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
                tr.Trace("111");
                using (var wrapMode = new ImageAttributes())
                {
                    tr.Trace("222");
                    wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
                    tr.Trace("333");
                }
            }

            return destImage;
        }

        public static Image byteArrayToImage(byte[] byteArrayIn)
        {
            using (MemoryStream mStream = new MemoryStream(byteArrayIn))
            {
                return Image.FromStream(mStream);
            }
        }

        public static byte[] imgToByteConverter(Image inImg, ITracingService tr)
        {
            tr.Trace("Insuide byte function");
            ImageConverter imgCon = new ImageConverter();
            tr.Trace("before return");
            return (byte[])imgCon.ConvertTo(inImg, typeof(byte[]));
        }



    }
}
