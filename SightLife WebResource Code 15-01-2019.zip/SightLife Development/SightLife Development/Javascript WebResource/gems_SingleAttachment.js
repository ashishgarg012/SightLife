﻿function EnforceSingleNote() {
    EnforceSingleNoteImpl();
    setInterval("EnforceSingleNoteImpl()", 500);
}

function EnforceSingleNoteImpl() {
    var notesInput = $(document.getElementById('header_notescontrol').contentWindow.document.getElementById('noteTextInput-create'));
    //document.getElementById('header_notescontrol')
    var notesContainer = notesInput.closest('.notesContainerScrollDiv');
    var nAttachments = notesContainer.find('.attachment').length;
    var notesTextBoxDivs = notesContainer.find('.notesTextBoxDiv');
    if (nAttachments > 0 && notesTextBoxDivs.length > 0) {
        notesTextBoxDivs.hide();
    }
    var notesTextCreate = notesContainer.find('.ms-crm-Note-Text-create');
    if (nAttachments > 0 && notesTextCreate.length > 0) {
        notesTextCreate.hide();
    }
}