﻿function ValidateTissueWithSubType(context) {
    var args = context.getEventArgs();
    var tissueValue = Xrm.Page.getAttribute('gems_tissuetype').getValue();
    var tissueSubTypeValue = Xrm.Page.getAttribute('gems_tissuesubtype').getValue();

    if (tissueValue != null && tissueSubTypeValue != null) {
        if (tissueValue == 1 && tissueSubTypeValue == 2) {
            alert("Cornea Half is an invalid selection. Please select another tissue sub type");
            args.preventDefault();
        }
    }
}