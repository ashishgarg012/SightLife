﻿//new_reportButtonsHidenShow

function reportButtons() {
    // debugger;
    var WebResourceArray;
    var entityName = Xrm.Page.data.entity.getEntityName();
    if (entityName == "gems_request") {
        WebResourceArray = ["WebResource_RecipientInformation"];
    } else if (entityName == "gems_distribution") {
        WebResourceArray = ["WebResource_AdverseReactionButton", "WebResource_testbutton"];
    } else if (entityName == "gems_tissuedetail") {
        WebResourceArray = ["WebResource_tissueDetailsButton", "WebResource_adhesiveButton", "WebResource_PostCustForm"];
    }
    hideandshowbuttons(WebResourceArray);
}

function hideandshowbuttons(webresourcenames) {
    for (var i = 0; i < webresourcenames.length; i++) {
        var resource = webresourcenames[i];
        if (Xrm.Page.ui.getFormType() == 1) {
            Xrm.Page.getControl(resource).setVisible(false);
        } else {
            Xrm.Page.getControl(resource).setVisible(true);
        }
    }
}

//***********Add Header line on Tissue & Placement form*************************************************
function HeaderLine() {
    debugger;
    if (parent.document.getElementById("crmFormHeaderTop") != null) {
        parent.document.getElementById("crmFormHeaderTop").style.borderBottom = "2px solid";
        parent.document.getElementById("crmFormHeaderTop").style.borderBottomColor = "#b3aeae";
    }
}

//***********Add Header line on Request form*************************************************

function HeaderLineRequestPage() {
    //  debugger;
    if (parent.document.getElementById("crmFormHeaderTop") != null) {
        parent.document.getElementById("crmFormHeaderTop").style.borderBottom = "2px solid";
        parent.document.getElementById("crmFormHeaderTop").style.borderBottomColor = "#b3aeae";
    }
    if (parent.document.getElementById("HeaderTitleElement") != null) {
        parent.document.getElementById("HeaderTitleElement").style.marginBottom = "-2%";
    }
}

//**************************************************************************************************

//----To Call Workflow on Cancel Request to update Request Status=Cancel & change status,status reason as Inactive on Request Entity
function callRequestWorkflow() {
    debugger;
    var r = confirm("Click Ok to cancel this request? This request will be deactivated and will not be available for placement.");
    if (r == true) {
        var entityId = Xrm.Page.data.entity.getId();
        var objectID = entityId.replace("{", "").replace("}", "");

        var collection;
        var placementID;
        if (objectID != null && objectID != undefined) {
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
				"<entity name='gems_distribution'>" +
				"<attribute name='gems_distributionid' />" +
				"<attribute name='gems_name' />" +
				"<attribute name='createdon' />" +
				"<order attribute='gems_name' descending='false' />" +
				"<filter type='and'>" +
				"<condition attribute='gems_requestdetail' operator='eq'  value='" + objectID + "' />" +
				"<condition attribute='statecode' operator='eq' value='0' />" +
				"</filter>" +
				"</entity>" +
				"</fetch>";

            collection = XrmServiceToolkit.Soap.Fetch(fetchXml);
        }

        if (collection.length > 0) {
            for (i = 0; i < collection.length; i++) {
                if (collection[i].attributes.gems_name != null && collection[i].attributes.gems_name != undefined) {
                    placementID = collection[i].attributes.gems_name.value;
                }

                alert("You cannot cancel this request, as this request is already mapped to Placement id " + placementID + ".");
            }
        } else {
            Process.callWorkflow("81F1969B-EB64-45EC-8866-8AD103C16837",
				objectID,
				function () {
				    alert("Request Cancelled successfully");
				    window.parent.Xrm.Utility.openEntityForm("gems_request", objectID);
				},
				function () {
				    alert("Error executing Request Cancel");
				});
        }
    }
}
//-------To Call Workflow on Cancel Request to update Request Status=Cancel & change status,status reason as Inactive on Request Entity

//-------To Call Workflow on Cancel Placement to update Tissue Disposition=Cancel & change status,status reason as Inactive on Request Entity
function callPlacementWorkflow() {
    debugger;

    lookupselectTissue = Xrm.Page.data.entity.attributes.get("gems_tissuedetail");

    if (lookupselectTissue.getValue() != null) {
        tissueLabel = lookupselectTissue.getValue()[0].name;
    }

    lookupselectRequest = Xrm.Page.data.entity.attributes.get("gems_requestdetail");

    if (lookupselectRequest.getValue() != null) {
        requestLabel = lookupselectRequest.getValue()[0].name;
    }

    var r = confirm("Click Ok to cancel this placement request? This will deactivate the placement.The Request id " + requestLabel + " and Tissue disposition for " + tissueLabel + " will be reset to “New/In Progress”.");
    if (r == true) {
        var entityId = Xrm.Page.data.entity.getId();
        var objectID = entityId.replace("{", "").replace("}", "");
        Process.callWorkflow("7ff206e8-f29f-4cf9-96ef-b5af95fa83bb",
			objectID,
			function () {
			    alert("Placement Cancelled successfully");
			    window.parent.Xrm.Utility.openEntityForm("gems_distribution", objectID);
			},
			function () {
			    alert("Error executing Placement Cancel");
			});
    }
}
//------To Call Workflow on Cancel Placement to update Tissue Disposition=Cancel & change status,status reason as Inactive on Request Entity


//******************************************************************************************************************************************
//---To search tissue is already placed for placement record on Placement entity...fun on change  of "Tissue Disposition" field
function searchDuplicatePlacementsRecord() {
    debugger;
    var collection,
	placementID;
    // var message =
    var type = "INFO"; //INFO, WARNING, ERROR
    var id = "Info1"; //Notification Id
    var time = 3000; //Display time in milliseconds
    lookupselectTissue = Xrm.Page.data.entity.attributes.get("gems_tissuedetail");

    if (lookupselectTissue.getValue() != null) {
        entityId = lookupselectTissue.getValue()[0].id;
        entityName = lookupselectTissue.getValue()[0].entityType;
        entityLabel = lookupselectTissue.getValue()[0].name;

        if (entityLabel != null && entityLabel != undefined) {
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
				"<entity name='gems_distribution'>" +
				"<attribute name='gems_distributionid' />" +
				"<attribute name='gems_name' />" +
				"<order attribute='gems_name' descending='false' />" +
				"<filter type='and'>" +
				"<condition attribute='gems_tissuedetailname' operator='eq' value='" + entityLabel + "' />" +
				"<condition attribute='gems_tissuedisposition' operator='eq' value='1' />" +
				"</filter>" +
				"</entity>" +
				"</fetch>";

            collection = XrmServiceToolkit.Soap.Fetch(fetchXml);
        }
        if (collection.length > 0) {
            if (collection[0].attributes.gems_name != null && collection[0].attributes.gems_name != undefined) {
                placementID = collection[0].attributes.gems_name.value;
            }
            Xrm.Page.ui.setFormNotification("This Tissue is already placed for Placement " + placementID + ".", type, id);
        } else {
            Xrm.Page.ui.clearFormNotification(id);
        }

        //Wait the designated time and then remove tissue if it was already placed
        setTimeout(
			function () {
			    if (collection.length > 0) {
			        Xrm.Page.getAttribute("gems_tissuedetail").setValue();
			    }
			},
			time);

    }
}

//----The user should not be able to create multiple placements for a single request on Placement entity...fun on change
//----of "Select Request" field
function toCheckSingleRequestforSinglePlacement() {
    debugger;
    var collection;
    var message = "This Request is already placed.";
    var type = "INFO"; //INFO, WARNING, ERROR
    var id = "Info1"; //Notification Id
    var time = 3000; //Display time in milliseconds
    lookupselectRequest = Xrm.Page.data.entity.attributes.get("gems_requestdetail");

    if (lookupselectRequest.getValue() != null) {
        selectRequestId = lookupselectRequest.getValue()[0].id;
        selectRequestName = lookupselectRequest.getValue()[0].entityType;
        selectRequest = lookupselectRequest.getValue()[0].name;

        if (selectRequestId != null && selectRequestId != undefined) {
            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
				"<entity name='gems_distribution'>" +
				"<attribute name='gems_distributionid' />" +
				"<attribute name='gems_name' />" +
				"<order attribute='gems_name' descending='false' />" +
				"<filter type='and'>" +
				"<condition attribute='gems_requestdetail' operator='eq' value='" + selectRequestId + "' />" +
				"</filter>" +
				"</entity>" +
				"</fetch>";

            collection = XrmServiceToolkit.Soap.Fetch(fetchXml);
        }

        if (collection.length > 0) {
            Xrm.Page.ui.setFormNotification(message, type, id);
        } else {
            Xrm.Page.ui.clearFormNotification(id);
        }

        //Wait the designated time and then remove request if it was already placed
        setTimeout(
			function () {
			    if (collection.length > 0) {
			        Xrm.Page.getAttribute("gems_requestdetail").setValue();
			    }
			},
			time);

    }
}

//Move tab control from Opacity1 field to Opacity2...10March

function tabSequence() {
    debugger;
    Xrm.Page.getControl("gems_opacities2").setFocus(true);
}
//------------------------------------------------------------------------------

//Reported Deaths During Work Hours must be less than or equal to Reported Deaths..in Death Notification entity
function reportedDeathsDuringWH_validation() {
    debugger;
    if (Xrm.Page.getAttribute("gems_reporteddeaths") != null || Xrm.Page.getAttribute("gems_reporteddeaths") != undefined ||
		Xrm.Page.getAttribute("gems_reportedduringwh") != null || Xrm.Page.getAttribute("gems_reportedduringwh") != undefined) {
        var reportedDeaths = Xrm.Page.getAttribute("gems_reporteddeaths").getValue();
        var reportedDeathsduringWH = Xrm.Page.getAttribute("gems_reportedduringwh").getValue();
    }
    if (reportedDeaths < reportedDeathsduringWH) {
        alert("Reported deaths during work hours must be less than or equal to Reported deaths.");
        Xrm.Page.getAttribute("gems_reportedduringwh").setValue();
    }
}

//-------------------------------


//------Hide + symbol from Unit subgrid from Organization(Account) entity...12 April...onload
function hidePlusFromUnitSubgrid() {
    debugger;
    var unitGrid = window.parent.document.getElementById("Unit_Name");
    if (unitGrid.control == null || unitGrid.control == "undefined") {
        setTimeout('hidePlusFromUnitSubgrid()', 500);
    } else {
        //var shipmentbutton = shipmentgrid.control.get_addContextualButton();
        window.parent.document.getElementById("Unit_Name").control.get_addContextualButton().style.display = "none";
    }
}
//-----------------------------------------------------------------------------------------------------

//---Concat % symbol to Exposure Percentage field----12 April...onchange of Exposure Percentage
function concatPercentagetoExposurePercentage() {
    debugger;
    var exposurePercentage = Xrm.Page.getAttribute("gems_exposurepercentage").getValue();
    if (exposurePercentage != null && exposurePercentage != undefined) {
        if (exposurePercentage.indexOf('%') > 0) {
            Xrm.Page.getAttribute("gems_exposurepercentage").setValue(exposurePercentage);
        } else {
            percentage = exposurePercentage + "%";
            Xrm.Page.getAttribute("gems_exposurepercentage").setValue(percentage);
        }

    }
}
//--------------------------------------------------------------

//---Concat % symbol to Percent of Total Cornea field----26 April...onchange of Percent of Total Cornea
function concatPercentagetoPercentofTotalCornea() {
    debugger;
    var percentofTotalCornea = Xrm.Page.getAttribute("gems_percenttotalcornea").getValue();
    if (percentofTotalCornea != null && percentofTotalCornea != undefined) {
        if (percentofTotalCornea.indexOf('%') > 0) {
            Xrm.Page.getAttribute("gems_percenttotalcornea").setValue(percentofTotalCornea);
        } else {
            percentage = percentofTotalCornea + "%";
            Xrm.Page.getAttribute("gems_percenttotalcornea").setValue(percentage);
        }

    }
}
//--------------------------------------------------------------

//--Set Expiry date for Preservation medium..Recovery Entity...on load of Tissue Evaluation entity & on chnge of Plasma medium(Tissue Eval entity)...Lib name=new_reportButtonsHidenShow--------------19 April
function setExpiryDateForPreservationMedium(event) {
    debugger;
    var calculatedExpiryDate = null;
    var collection = {};
    var tissueRecoveryDateTime;
    var tissueRecoveryDateTime1;
    var preservationMedium;
    var lookupMedicalReviewID = Xrm.Page.data.entity.attributes.get("gems_medicalreviewidid");
    var corneaLFH = Xrm.Page.getAttribute("gems_werecorneasprocessedunderanlafhood").getValue();
    var TissueID = Xrm.Page.getAttribute("gems_name").getValue();
    //if(TissueID!=null && TissueID!=undefined)
    //{
    var formType = Xrm.Page.ui.getFormType();
    if (formType == 1 || event == "onchange") {
        if (lookupMedicalReviewID.getValue() != null) {
            MedicalReviewId = lookupMedicalReviewID.getValue()[0].id;

            if (MedicalReviewId != null && MedicalReviewId != undefined) {
                var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
								  "<entity name='gems_recovery'>" +
									"<attribute name='createdon' />" +
									"<attribute name='gems_name' />" +
									"<attribute name='gems_recoveryid' />" +
									"<attribute name='gems_tissuerecoverydatetime' />" +
									"<attribute name='gems_preservationmedia' />" +
									"<order attribute='createdon' descending='false' />" +
									"<link-entity name='gems_medicalreview' from='gems_originatingrecoveryid' to='gems_recoveryid' alias='ab'>" +
									  "<filter type='and'>" +
										"<condition attribute='gems_medicalreviewid' operator='eq' value='" + MedicalReviewId + "' />" +
									  "</filter>" +
									"</link-entity>" +
								  "</entity>" +
								"</fetch>";

                /*"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
					"<entity name='gems_recovery'>" +
					"<attribute name='createdon' />" +
					"<attribute name='gems_name' />" +
					"<attribute name='gems_recoveryid' />" +
					"<attribute name='gems_tissuerecoverydatetime' />" +
					"<attribute name='gems_preservationmedia' />" +
					"<order attribute='createdon' descending='false' />" +
					"<filter type='and'>" +
					"<condition attribute='gems_tissuerecoverydatetime' operator='not-null' />" +
					"<condition attribute='gems_preservationmedia' operator='not-null' />" +
					"</filter>" +
					"<link-entity name='gems_medicalreview' from='gems_originatingrecoveryid' to='gems_recoveryid' alias='ag'>" +
					"<link-entity name='gems_tissuedetail' from='gems_medicalreviewidid' to='gems_medicalreviewid' alias='ah'>" +
					"<filter type='and'>" +
					"<condition attribute='gems_medicalreviewidid' operator='eq' value='" + MedicalReviewId + "' />" +
					"</filter>" +
					"</link-entity>" +
					"</link-entity>" +
					"</entity>" +
				"</fetch>";*/

                collection = XrmServiceToolkit.Soap.Fetch(fetchXml);
            }
        }

        if (collection.length > 0) {
            if (collection[0].attributes.gems_tissuerecoverydatetime != null && collection[0].attributes.gems_tissuerecoverydatetime != undefined) {
                tissueRecoveryDateTime1 = collection[0].attributes.gems_tissuerecoverydatetime.formattedValue;
                var bits = tissueRecoveryDateTime1.split(/\D/);
                var tissueRecoveryDateTime = new Date(bits[2], --bits[1], bits[0], bits[3], bits[4]); //ddmmyy
                //  var tissueRecoveryDateTime = new Date(bits[2], --bits[0], bits[1], bits[3], bits[4]);

                //new Date(year, month, day, hours, minutes, seconds, milliseconds)
            }
            if (collection[0].attributes.gems_preservationmedia != null && collection[0].attributes.gems_preservationmedia != undefined) {
                if (corneaLFH == true) {
                    preservationMedium = Xrm.Page.getAttribute("gems_preservationmedium").getText(); //Preservation medium form Tissue Evaluation

                } else {
                    preservationMedium = collection[0].attributes.gems_preservationmedia.formattedValue; ////Preservation medium form Recovery
                }
            }
        }

        if (preservationMedium != null && preservationMedium != undefined && tissueRecoveryDateTime != null && tissueRecoveryDateTime != undefined) {
            if (preservationMedium == "MK") {
                // tissueRecoveryDateTime.setDate(tissueRecoveryDateTime.getDate() + 5);
                tissueRecoveryDateTime.setHours(tissueRecoveryDateTime.getHours() + 96);
                calculatedExpiryDate = tissueRecoveryDateTime;
            } else if (preservationMedium == "Cornisol") {
                tissueRecoveryDateTime.setHours(tissueRecoveryDateTime.getHours() + 336);
                calculatedExpiryDate = tissueRecoveryDateTime;
            } else if (preservationMedium == "Optisol GS") {
                tissueRecoveryDateTime.setHours(tissueRecoveryDateTime.getHours() + 336);
                calculatedExpiryDate = tissueRecoveryDateTime;
            }

            if (calculatedExpiryDate != null && calculatedExpiryDate != undefined) {
                Xrm.Page.getAttribute("gems_tissueexpirationdate").setValue(calculatedExpiryDate);
                //
                //var formType = Xrm.Page.ui.getFormType();
                if (formType == 2) //2:Update
                {
                    //Xrm.Page.data.entity.save();
                }
                //
            }
        }
    }

    if (event == "onchange") {
        Xrm.Page.getControl("gems_tissueexpirationdate").setFocus();
        //setTimeout(Xrm.Page.data.entity.save(), 1000);

        setTimeout(function () {
            Xrm.Page.data.entity.save();
        }, 1500);
    }
    //}
}
//-----------------------------------------------------------


//---Lock RecoveryOutcome field if select Consented:Recoveredvalue...fun is ON Save & on load only---lib:gems_reportbuttonhide&show
function setLockedRecoveryOutcome() {
    debugger;
    var recoveryOutcome = Xrm.Page.getAttribute("gems_recoveryoutcome").getValue();
    if (recoveryOutcome == "3") //3=Consented:Recovered
        // Xrm.Page.getControl("gems_recoveryoutcome").setDisabled(true);
        Xrm.Page.ui.controls.get("gems_recoveryoutcome").setDisabled(true)
}

//---------------------------------------------------------------
//----Retrive BU Address in From field on Placement entity----on load of placement-------------------------------------
function retriveBUAddress() {
    debugger;
    //To get current user Business Unit Id
    var userid = Xrm.Page.context.getUserId();

    prodJatinGuid = '1AC83408-B755-E611-80C6-000D3AF00778';
    prodAmanGuid = '6354AA4F-F913-E611-80C4-000D3AF00778';
    devJatinGuid = 'CDD96B02-BB55-E611-80C6-000D3AF000DC';
    devAmanGuid = '617421F8-A683-E611-80C9-000D3AF01A8F';
    qaJatinGuid = '1F1E0E29-B955-E611-80C6-000D3AF00061';
    qaAmanGuid = '0DED30C3-390E-E611-80C3-000D3AF00061';

    var UserName = Xrm.Page.context.getUserName();
    var businessunit;
    userid = userid.replace("{", "").replace("}", "");

    var req = new XMLHttpRequest();
    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.1/systemusers(" + userid + ")?$select=_businessunitid_value", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                debugger;
                var result = JSON.parse(this.response);
                businessunit = result["_businessunitid_value"];
                //alert("businessunit"+businessunit);
            } else {
                Xrm.Utility.alertDialog(this.statusText);
            }
        }
    };
    req.send();

    var FetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
		"<entity name='businessunit'>" +
		"<attribute name='name' />" +
		"<attribute name='parentbusinessunitid' />" +
		"<attribute name='address2_postalcode' />" +
		"<attribute name='address2_line3' />" +
		"<attribute name='address2_line2' />" +
		"<attribute name='address2_line1' />" +
		"<attribute name='address2_stateorprovince' />" +
		"<attribute name='address2_country' />" +
		"<attribute name='address2_city' />" +
		"<order attribute='name' descending='false' />" +
		"<filter type='and'>" +
		"<condition attribute='businessunitid' operator='eq'  value='" + businessunit + "' />" +
		"</filter>" +
		"</entity>" +
		"</fetch>";

    var collection = XrmServiceToolkit.Soap.Fetch(FetchXML);

    if (collection.length > 0) {
        var name;
        var street1;
        var street2;
        var street3;
        var country;
        var state;
        var city;
        var postalCode;

        if (collection[0].attributes.name != null && collection[0].attributes.name != undefined) {
            name = collection[0].attributes.name.value;
            concatAddress = name;
        }

        if (collection[0].attributes.address2_line1 != null && collection[0].attributes.address2_line1 != undefined) {
            street1 = collection[0].attributes.address2_line1.value;
            concatAddress += ", " + street1;
        }

        if (collection[0].attributes.address2_line2 != null && collection[0].attributes.address2_line2 != undefined) {
            street2 = collection[0].attributes.address2_line2.value;
            concatAddress += ", " + street2;
        }

        if (collection[0].attributes.address2_line3 != null && collection[0].attributes.address2_line3 != undefined) {
            street3 = collection[0].attributes.address2_line3.value;
            concatAddress += ", " + street3;
        }

        if (collection[0].attributes.address2_country != null && collection[0].attributes.address2_country != undefined) {
            country = collection[0].attributes.address2_country.value;
            concatAddress += ", " + country;
        }

        if (collection[0].attributes.address2_stateorprovince != null && collection[0].attributes.address2_stateorprovince != undefined) {
            state = collection[0].attributes.address2_stateorprovince.value;
            concatAddress += ", " + state;
        }

        if (collection[0].attributes.address2_city != null && collection[0].attributes.address2_city != undefined) {
            city = collection[0].attributes.address2_city.value;
            concatAddress += ", " + city;
        }

        if (collection[0].attributes.address2_postalcode != null && collection[0].attributes.address2_postalcode != undefined) {
            postalCode = collection[0].attributes.address2_postalcode.value;
            concatAddress += ", " + postalCode;
        }

        ///
        if (userid == prodJatinGuid || userid == prodAmanGuid || userid == devJatinGuid || userid == devAmanGuid || userid == qaJatinGuid || userid == qaAmanGuid) {
        } else if (Xrm.Page.getAttribute("gems_fromaddress").getValue() == null || Xrm.Page.getAttribute("gems_fromaddress").getValue() == undefined) {
            var from = Xrm.Page.getAttribute('gems_fromaddress').setValue(concatAddress);
        }

        var formType = Xrm.Page.ui.getFormType();
        if (formType == 2) //2:Update
        {
            Xrm.Page.data.entity.save();
        }
        //
    }

}
//--------------------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------------------


//----Retrive BU Name in Account Name field on Contact entity----on load of Contact-----7 June 2017----------------
function retriveOrgName() {
    debugger;
    //To get current user Business Unit Id
    var userid = Xrm.Page.context.getUserId();
    var businessunitID;
    userid = userid.replace("{", "").replace("}", "");

    var req = new XMLHttpRequest();
    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.1/systemusers(" + userid + ")?$select=_businessunitid_value", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                debugger;
                var result = JSON.parse(this.response);
                businessunitID = result["_businessunitid_value"];
                //alert("businessunitID"+businessunitID);
            } else {
                Xrm.Utility.alertDialog(this.statusText);
            }
        }
    };
    req.send();
    //To get current user Business Unit Id

    if (businessunitID != null && businessunitID != undefined) {

        //To get current user businessunitacronym i.e EBAK
        var FetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
			"<entity name='businessunit'>" +
			"<attribute name='businessunitid' />" +
			"<attribute name='name' />" +
			"<attribute name='gems_businessunitacronym' />" +
			"<attribute name='parentbusinessunitid' />" +
			"<order attribute='name' descending='false' />" +
			"<filter type='and'>" +
			"<condition attribute='businessunitid' operator='eq'  value='" + businessunitID + "' />" +
			"</filter>" +
			"</entity>" +
			"</fetch>";

        var collection = XrmServiceToolkit.Soap.Fetch(FetchXML);

        if (collection.length > 0) {
            if (collection[0].attributes.gems_businessunitacronym != null && collection[0].attributes.gems_businessunitacronym != undefined) {
                orgnizationName = collection[0].attributes.gems_businessunitacronym.value;
            }
            //To get current user businessunitacronym ie EBAK
        }

        if (orgnizationName != null && orgnizationName != undefined) {
            //To get ID of Organization name ie EBAK
            var Fetchxml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
				"<entity name='account'>" +
				"<attribute name='name' />" +
				"<attribute name='primarycontactid' />" +
				"<attribute name='telephone1' />" +
				"<attribute name='accountid' />" +
				"<order attribute='name' descending='false' />" +
				"<filter type='and'>" +
				"<condition attribute='name' operator='eq' value='" + orgnizationName + "' />" +
				"</filter>" +
				"</entity>" +
				"</fetch>";

            var collectionAccount = XrmServiceToolkit.Soap.Fetch(Fetchxml);

            if (collectionAccount.length > 0) {
                if (collectionAccount[0].attributes.accountid != null && collectionAccount[0].attributes.accountid != undefined) {
                    ID = collectionAccount[0].attributes.accountid.value;
                }
            }
        }
        //To get ID of Organization name ie EBAK

        if (orgnizationName != null && orgnizationName != undefined && ID != null && ID != undefined) {
            var lookupValue = new Array();
            lookupValue[0] = new Object();
            lookupValue[0].id = ID; // Guid Of That Look Up
            lookupValue[0].name = orgnizationName; // Name  Of That Look Up
            lookupValue[0].entityType = "account"; // Entity Name Of That Look Up

            if (Xrm.Page.getAttribute("parentcustomerid").getValue() == null || Xrm.Page.getAttribute("parentcustomerid").getValue() == undefined)
                Xrm.Page.getAttribute("parentcustomerid").setValue(lookupValue);
        }

        //
        var formType = Xrm.Page.ui.getFormType();
        if (formType == 2) //2:Update
        {
            Xrm.Page.data.entity.save();
        }
        //
    }
}
//7 June 2017------------------------------------------------------------------------------------------
