﻿function ShowHideTab_SlitLampDone() {

    var optionValue = Xrm.Page.getAttribute('gems_slitlampdone').getValue();
    if (optionValue == true) {

        Xrm.Page.ui.tabs.get('tab_Epithelium').setVisible(true);
        Xrm.Page.ui.tabs.get('tab_Stroma').setVisible(true);
        Xrm.Page.ui.tabs.get('tab_Descemets').setVisible(true);
        Xrm.Page.ui.tabs.get('tab_Endothelium').setVisible(true);
    }
    else {

        Xrm.Page.ui.tabs.get('tab_Epithelium').setVisible(false);
        Xrm.Page.ui.tabs.get('tab_Stroma').setVisible(false);
        Xrm.Page.ui.tabs.get('tab_Descemets').setVisible(false);
        Xrm.Page.ui.tabs.get('tab_Endothelium').setVisible(false);
    }

}

// Hide the Approval Outcome Tab as per crteria
function ShowHideTab_ApprovalOutcome() {
    var formId = Xrm.Page.ui.getFormType();

    if (formId == "2" || formId == "4") {
        var CheckTissueSuitability = Xrm.Page.getAttribute('gems_tissuesuitability').getValue();

        if (CheckTissueSuitability != null) {
            Xrm.Page.ui.tabs.get('tab_ApprovalOutcome').setVisible(true);
        }
        else {
            Xrm.Page.ui.tabs.get('tab_ApprovalOutcome').setVisible(false);
        }
    }
}


// Function call when PreCut value select the 'No' on Tissue Details Form

function ShowHideTab_PreCut() {
    var precutptionValue = Xrm.Page.getAttribute('gems_precut').getValue();
    if (precutptionValue == 2) {
        Xrm.Page.ui.tabs.get('Tab_CustomCornealTissueInformation').setVisible(true);
        Xrm.Page.ui.tabs.get('Tab_PostCutEvaluation').setVisible(true);
        //Xrm.Page.ui.tabs.get('Tab_PreCutPostCutEvaluation').sections.get('Post_Cut_Evaluation_Form_Button_Section1').setVisible(true);
        Xrm.Page.ui.controls.get("gems_cuttype").setVisible(true);
        Xrm.Page.ui.controls.get("gems_cutparameters").setVisible(true);
        //
        //Xrm.Page.ui.tabs.get('Tab_PreCutPostCutEvaluation').sections.get('Post_Cut_Evaluation_Form_Button_Section2').setVisible(true);
    }
    else {
        Xrm.Page.ui.tabs.get('Tab_CustomCornealTissueInformation').setVisible(false);
        Xrm.Page.ui.tabs.get('Tab_PostCutEvaluation').setVisible(false);
        // Xrm.Page.ui.tabs.get('Tab_PreCutPostCutEvaluation').sections.get('Post_Cut_Evaluation_Form_Button_Section1').setVisible(false);
        Xrm.Page.ui.controls.get("gems_cuttype").setVisible(false);
        Xrm.Page.ui.controls.get("gems_cutparameters").setVisible(false);
        //
        //Xrm.Page.ui.tabs.get('Tab_PreCutPostCutEvaluation').sections.get('Post_Cut_Evaluation_Form_Button_Section2').setVisible(false);
    }
}

// Function call to hide the section when Specular Evaluation value is 'No' on Tissue Details Form and vice-versa
function ShowHideSection_UploadSpecularImage() {
    var optionValue = Xrm.Page.getAttribute('gems_specularevaluationdone').getValue();
    if (optionValue == true) {
        Xrm.Page.ui.tabs.get('Specular_Evaluation').sections.get('Specular_Evaluation_section_5').setVisible(true);
    }
    else {
        Xrm.Page.ui.tabs.get('Specular_Evaluation').sections.get('Specular_Evaluation_section_5').setVisible(false);
    }

}
