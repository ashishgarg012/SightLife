﻿function CheckNumber() {
    var checktextboxid = $("#gems_donorfirstname_d");
    if (checktextboxid != null && checktextboxid.length > 0) {
        $("#gems_donorfirstname_d").keypress(function (e) {

            debugger;

            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                return false;
            }
        });
    }
}