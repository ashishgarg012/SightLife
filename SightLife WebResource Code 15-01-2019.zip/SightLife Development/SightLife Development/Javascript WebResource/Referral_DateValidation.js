﻿
/******************************************************************************************************************************/
/******************************************************************************************************************************/
/*    Library Name              :  gems_referral_DateValidation                                                               */  
/*                                                                                                                            */ 
/*    Aurthor                   :  Rajneesh Kumar Singh                                                                       */
/*                                                                                                                            */ 
/*   Organization               :  SightLife                                                                                  */
/*                                                                                                                            */ 
/*   Entity Used                :  Referral                                                                                   */
/*                                                                                                                            */
/*   Created On                 :  23 Dec 2014                                                                                */
/*                                                                                                                            */
/*   Comments                   :                                                                                             */
/*                                                                                                                            */              
/* *******      Name of Functions         **********      Description    ******************************************************/
/*                                                                                                                            */
/*         BirthDate_Valdation()                   :  Date and Time Validation on Birth Date and Time on Referral entity      */
/*                                                                                                                            */
/*         DeathDate_Valdation()                   :  Date and Time Validation on Death Date and Time on Referral entity      */
/*                                                                                                                            */
/*         DeathNotificationDate_Valdation()       :  Date and Time Validation on Death Notification on Referral entity       */
/*                                                                                                                            */              
/*                                                                                                                            */              
/******************************************************************************************************************************/
/******************************************************************************************************************************/


//Date and Time Validation on Death Notification on Referral entity
function DeathNotificationDate_Valdation()
{
    var CurrentDate = new Date();
    var BirthDate= Xrm.Page.getAttribute('gems_donordob').getValue();
    var DeathDate= Xrm.Page.getAttribute('gems_datetimeofdeath').getValue();
    var DeathNotificationDate= Xrm.Page.getAttribute('gems_deathnotificationdatetime').getValue();

    if(DeathNotificationDate>CurrentDate)
    {
        alert('Please enter an appropriate Date and Time!! ')
        //  	 Xrm.Page.getAttribute('gems_deathnotificationdatetime').setValue();
    }
    elseif ((BirthDate!=null) && (BirthDate>DeathNotificationDate)) 
    {
        alert('Please enter an appropriate Date and Time1!! ')
        //      Xrm.Page.getAttribute('gems_deathnotificationdatetime').setValue();
    }
    elseif ((DeathDate!=null) && (DeathDate>DeathNotificationDate)) 
    {
        alert('Please enter an appropriate Date and Time2!! ')
        //      Xrm.Page.getAttribute('gems_deathnotificationdatetime').setValue();
    }
    elseif (((BirthDate!=null)||(DeathDate!=null)) && ((DeathDate>DeathNotificationDate)||(BirthDate>DeathNotificationDate))) 
    {
        alert('Please enter an appropriate Date and Time3!! ')
        //      Xrm.Page.getAttribute('gems_deathnotificationdatetime').setValue();
    }

}





//Date and Time Validation on Birth Date and Time on Referral entity
function BirthDate_Valdation()
{
    var CurrentDate = new Date();
    var BirthDate= Xrm.Page.getAttribute('gems_donordob').getValue();
    var DeathDate= Xrm.Page.getAttribute('gems_datetimeofdeath').getValue();
    var DeathNotificationDate= Xrm.Page.getAttribute('gems_deathnotificationdatetime').getValue();
    alert(DeathDate);
	
    //	if((BirthDate>CurrentDate)||(BirthDate>DeathDate)||(BirthDate>DeathNotificationDate))
    if(BirthDate>CurrentDate)
    {
        alert('Please enter an appropriate Date and Time!! ')
        Xrm.Page.getAttribute('gems_donordob').setValue();
    }
    if((DeathDate!=null)&&(DeathNotificationDate!=null)(BirthDate>CurrentDate)
    {
        alert('Please enter an appropriate Date and Time!! ')
        Xrm.Page.getAttribute('gems_donordob').setValue();
    }
}	 


//Date and Time Validation on Death Date and Time on Referral entity
function DeathDate_Valdation()
{
    var CurrentDate = new Date();
    var BirthDate= new Date(Xrm.Page.getAttribute('gems_donordob').getValue());
    var DeathDate= new Date(Xrm.Page.getAttribute('gems_datetimeofdeath').getValue());
    var DeathNotificationDate= new Date(Xrm.Page.getAttribute('gems_deathnotificationdatetime').getValue());
	
    if((DeathDate>CurrentDate)||(BirthDate>DeathDate)||(DeathDate>DeathNotificationDate))
    {
        alert('Please enter an appropriate Date and Time!! ')
        Xrm.Page.getAttribute('gems_datetimeofdeath').setValue();
    }
}
