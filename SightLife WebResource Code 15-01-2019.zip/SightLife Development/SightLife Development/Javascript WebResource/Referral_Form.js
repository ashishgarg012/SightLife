﻿//gems_Referral_Form
function CalculateAge() {

    var Age = "";
    var agedonor = Xrm.Page.getAttribute('gems_agedonor');
    var BirthDate = Xrm.Page.getAttribute('gems_donordob').getValue();
    var DeathDate = Xrm.Page.getAttribute('gems_datetimeofdeath').getValue();

    var DB = new Date(BirthDate);
    var DD = new Date(DeathDate);

    var BirthYr = DB.getFullYear();
    var DeathYr = DD.getFullYear()

    if (BirthDate != null) {
        //Age=DeathYr-BirthYr;
        //agedonor.setValue(Age + "");
        NewCalculateAge(DB, DD);
    } else {
        if (agedonor != null) {
            agedonor.setValue(null);
        }
    }

    MakeReadOnlyFields();
}

function NewCalculateAge(DB, DD) {
    var agedonor = Xrm.Page.getAttribute('gems_agedonor');

    var yearNow = DD.getFullYear();
    var monthNow = DD.getMonth();
    var dateNow = DD.getDate();

    var yearDob = DB.getFullYear();
    var monthDob = DB.getMonth();
    var dateDob = DB.getDate();
    var age = {};
    var ageString = "";
    var yearString = "";
    var monthString = "";
    var dayString = "";

    var monthAge;
    var dateAge;

    var yearAge = yearNow - yearDob;

    if (monthNow >= monthDob) {
        monthAge = monthNow - monthDob;
    } else {
        yearAge--;
        monthAge = 12 + monthNow - monthDob;
    }

    if (dateNow >= dateDob) {
        dateAge = dateNow - dateDob;
    } else {
        monthAge--;
        dateAge = 31 + dateNow - dateDob;

        if (monthAge < 0) {
            monthAge = 11;
            yearAge--;
        }
    }

    age = {
        years: yearAge,
        months: monthAge,
        days: dateAge
    };

    if (age.years > 1) {
        yearString = " years";
    } else {
        yearString = " year";
    }

    if (age.months > 1) {
        monthString = " months";
    } else {
        monthString = " month";
    }

    if (age.days > 1) {
        dayString = " days";
    } else {
        dayString = " day";
    }


    if ((age.years > 0) && (age.months > 0) && (age.days > 0)) {
        ageString = age.years + yearString + " and " + age.months + monthString;// + ", and " + age.days + dayString ;
        //ageString = age.years + yearString;
        //} else if ((age.years == 0) && (age.months == 0) && (age.days > 0)) {
        //ageString = age.days + dayString;
    } else if ((age.years > 0) && (age.months == 0) && (age.days == 0)) {
        ageString = age.years + yearString;
    } else if ((age.years > 0) && (age.months > 0) && (age.days == 0)) {
        ageString = age.years + yearString + " and " + age.months + monthString;
        //ageString = age.years + yearString;
    } else if ((age.years == 0) && (age.months > 0) && (age.days > 0)) {
        ageString = age.months + monthString;// + " and " + age.days + dayString;
    } else if ((age.years > 0) && (age.months == 0) && (age.days > 0)) {
        ageString = age.years + yearString;// + " and " + age.days + dayString ;
        //ageString = age.years + yearString;
    } else if ((age.years == 0) && (age.months > 0) && (age.days == 0)) {
        ageString = age.months + monthString;
    } else {
        ageString = "0";
    }


    if (agedonor != null) {
        agedonor.setValue(ageString);
    }

    // alert(ageString );
}

function MakeReadOnlyFields() {

    // if ($("#header_process_d").length > 0) {
    if (Xrm.Page.getControl('header_process_gems_datetimeofdeath') != null) {
        Xrm.Page.getControl('header_process_gems_datetimeofdeath').setDisabled(true);
    }
    if (Xrm.Page.getControl('header_process_gems_deathnotificationdatetime') != null) {
        Xrm.Page.getControl('header_process_gems_deathnotificationdatetime').setDisabled(true);
    }
    if (Xrm.Page.getControl('header_process_gems_donorfirstname') != null) {
        Xrm.Page.getControl('header_process_gems_donorfirstname').setDisabled(true);
    }
    if (Xrm.Page.getControl('header_process_gems_donorlastname') != null) {
        Xrm.Page.getControl('header_process_gems_donorlastname').setDisabled(true);
    }
    if (Xrm.Page.getControl('header_process_gems_referraloutcome') != null) {
        Xrm.Page.getControl('header_process_gems_referraloutcome').setDisabled(true);
    }
    //   }

}

function calculateDOBfromAge() {
    debugger;
    var age = Xrm.Page.getAttribute("gems_agedonor").getValue();
    var currentDate = new Date();
    //var dobyear = currentDate.getFullYear() - age;

    var splitAge = age.split(".");
    var ageYear = 0;
    var ageMonth = 0;
    if (splitAge.length > 1) {
        ageYear = splitAge[0];
        if (splitAge[1] > 11) {
            ageYear = "";
            Xrm.Page.getAttribute("gems_donordob").setValue(ageYear);
            Xrm.Page.getAttribute("gems_agedonor").setValue(null);
            Xrm.Page.getControl("gems_agedonor").setNotification("Please enter an appropriate age.");
        } else {
            Xrm.Page.getControl("gems_agedonor").clearNotification();
            ageMonth = splitAge[1];
        }
    } else {
        Xrm.Page.getControl("gems_agedonor").clearNotification();
        Xrm.Page.getAttribute("gems_donordob").setValue();
        Xrm.Page.getAttribute("gems_agedonor").setValue(null);
        ageYear = age;
    }

    var dobyear = currentDate.getFullYear() - ageYear;
    var dobMonth = currentDate.getMonth() - ageMonth;

    //var dateofbirth = new Date(dobyear, '00', '01', 0, 0, 0);
    var dateofbirth = new Date(dobyear, dobMonth, '01', 0, 0, 0);
    Xrm.Page.getAttribute("gems_donordob").setValue(dateofbirth);
    var months = "0";
    var years = "0";
    if (ageMonth == 1) {
        months = ageMonth + " month";
    } else if (ageMonth > 1) {
        months = ageMonth + " months";
    }

    if (ageYear == 1) {
        years = ageYear + " year";
    } else if (ageYear > 1) {
        years = ageYear + " years";
    }

    var donorAge;
    if (ageYear > 0 && ageMonth > 0) {
        donorAge = years + " and " + months;
    } else if (ageYear > 0 && ageMonth == 0) {
        donorAge = years;
    } else if (ageYear == 0 && ageMonth > 0) {
        donorAge = months;
    }

    Xrm.Page.getAttribute("gems_agedonor").setValue(donorAge);
}

//------------------------------------------------------------------------------------------
//Filter "Referral Source Org" option set on change of "Referral Method" & form on load...31March  gems_referralmethod
function filterReferralSourceOrg() {
    debugger;

    var client = Xrm.Page.context.client.getClient();
    var optionsetControl = Xrm.Page.ui.controls.get("new_referralsourceorg_os");

    var options = optionsetControl.getAttribute().getOptions();
    var setReferalSourceOrg = optionsetControl.getAttribute().getValue();
    var type = Xrm.Page.getAttribute("gems_referralmethod").getValue();

    if (type == 10) {
        optionsetControl.clearOptions();
        if (client.toLowerCase() == "mobile") {
            optionsetControl.addOption({ value: 6, text: "" });
        }

        for (var i = 0; i < options.length; i++) {
            if (i == 2) {							//HCRP motivated=3

                optionsetControl.addOption(options[i]);
                if (setReferalSourceOrg != null) {
                    Xrm.Page.getAttribute("new_referralsourceorg_os").setValue(setReferalSourceOrg);
                }

            }
        }
    }
        //'Voluntary'=11 is selected..shows no value for others
    else if (type == 11) {
        optionsetControl.clearOptions();
        if (client.toLowerCase() == "mobile") {
            optionsetControl.addOption({ value: 6, text: "" });
        }

        for (var i = 0; i < options.length; i++) {
            if (i == 0 || i == 1) {							//Voluntary-family initiated=1 & Voluntary-volunteer motivated=2
                optionsetControl.addOption(options[i]);
                if (setReferalSourceOrg != null) {
                    Xrm.Page.getAttribute("new_referralsourceorg_os").setValue(setReferalSourceOrg);
                }
            }
        }
    }

        //'Eye Retrieval Center'=12 is selected..shows no value for others
    else if (type == 12) {
        optionsetControl.clearOptions();
        if (client.toLowerCase() == "mobile") {
            optionsetControl.addOption({ value: 6, text: "" });
        }

        for (var i = 0; i < options.length; i++) {
            if (i == 0 || i == 1 || i == 2) {							//Voluntary-family initiated=1 & Voluntary-volunteer motivated=2,
                optionsetControl.addOption(options[i]);                        //HCRP motivated=3
                if (setReferalSourceOrg != null) {
                    Xrm.Page.getAttribute("new_referralsourceorg_os").setValue(setReferalSourceOrg);
                }
            }
        }
    }

        //'Others'=13 is selected..shows no value for others
    else if (type == 13) {
        optionsetControl.clearOptions();
        if (client.toLowerCase() == "mobile") {
            optionsetControl.addOption({ value: 6, text: "" });
        }

        for (var i = 0; i < options.length; i++) {
            if (i == 0 || i == 3) {							//Voluntary-family initiated=1 & EDC Influenced=4
                optionsetControl.addOption(options[i]);
                if (setReferalSourceOrg != null) {
                    Xrm.Page.getAttribute("new_referralsourceorg_os").setValue(setReferalSourceOrg);
                }
            }
        }
    }
}


//---------------------------------------------------------------------------------------------------------------------------

//---Lock Referral outcome field if select Approaced:Consented value...fun is ON Save only---lib:gems_ReferralForm
function setLockedReferralOutcome() {
    debugger;
    var referralOutcome = Xrm.Page.getAttribute("gems_referraloutcome").getValue();
    if (referralOutcome == "6")                                                //6=Approaced:Consented
        Xrm.Page.getControl("gems_referraloutcome").setDisabled(true);
    //  Xrm.Page.data.entity.save();

}


//------------------------------------------
//Conact FName & LName on referral entity..lib:gems_Referral
function concatDonorFNameLName() {
    var donorName = "";
    var FName = "";
    var LName = "";
    if (Xrm.Page.getAttribute("gems_donorfirstname") != null && Xrm.Page.getAttribute("gems_donorfirstname") != undefined) {
        if (Xrm.Page.getAttribute("gems_donorfirstname").getValue() != null && Xrm.Page.getAttribute("gems_donorfirstname").getValue() != undefined) {
            FName = Xrm.Page.getAttribute("gems_donorfirstname").getValue();
        }
    }

    if (Xrm.Page.getAttribute("gems_donorlastname") != null && Xrm.Page.getAttribute("gems_donorlastname") != undefined) {
        if (Xrm.Page.getAttribute("gems_donorlastname").getValue() != null && Xrm.Page.getAttribute("gems_donorlastname").getValue() != undefined) {
            LName = Xrm.Page.getAttribute("gems_donorlastname").getValue();
        }
    }

    donorName = FName + " " + LName;

    Xrm.Page.getAttribute("gems_donorname").setValue(donorName);
}

//------------------------------------------------------------------------------------------------------------------
//Save form if we select Referral Outcome as "Approached:Consented"..fun is on change of Referral Outcome
function autosaveReferralOutcome() {
    debugger;
    var referralOutcome = Xrm.Page.getAttribute("gems_referraloutcome").getValue();//Approached: Consented=6
    if (referralOutcome == 6) {
        Xrm.Page.data.entity.save();
    }
}