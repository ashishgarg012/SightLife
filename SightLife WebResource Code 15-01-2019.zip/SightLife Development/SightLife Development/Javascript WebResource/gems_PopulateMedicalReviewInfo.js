﻿function PopulateMedicalReviewDetail() {

    if (Xrm.Page.getAttribute("gems_medicalreviewidid") && Xrm.Page.getAttribute("gems_medicalreviewidid").getValue() != null) {
        var medicalObj = Xrm.Page.getAttribute("gems_medicalreviewidid").getValue();
        var medicalGuidId = medicalObj[0].id;
        // var objrefentity1id = getlookup("den_refentity1id");
        // alert(objrefentity1id);
        var oDataURI = Xrm.Page.context.getClientUrl() + "/xrmservices/2011/OrganizationData.svc/gems_MedicalReviewSet?$select=gems_RecoveryMedicalDateTimeDeath,gems_name&$filter=gems_MedicalReviewId eq guid'" + medicalGuidId + "'";
        //Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/ProcessStageSet?$select=ProcessStageId,StageName,PrimaryEntityTypeCode&$filter=ProcessId/Id eq (guid'" + processId + "')";
        var req = new XMLHttpRequest();
        req.open("GET", encodeURI(oDataURI), true);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.onreadystatechange = function () {
            if (this.readyState == 4) {
                req.onreadystatechange = null;
                if (this.status == 200) {
                    var stages = JSON.parse(this.responseText);
                    var RetrievedDate = stages.d.results[0].gems_RecoveryMedicalDateTimeDeath;
                    if (RetrievedDate != null) {
                        var DateofDeath = new Date(parseInt(RetrievedDate.replace("/Date(", "").replace(")/", ""), 10));
                        Xrm.Page.data.entity.attributes.get("gems_medicaltissuedatetimedeath").setValue(DateofDeath);
                        Xrm.Page.data.entity.attributes.get("gems_medicaltissuedatetimedeath").setSubmitMode("always");
                    }
                    else {
                        Xrm.Page.data.entity.attributes.get("gems_medicaltissuedatetimedeath").setValue();
                        Xrm.Page.data.entity.attributes.get("gems_medicaltissuedatetimedeath").setSubmitMode("always");
                    }
                    var DonerID = stages.d.results[0].gems_name; // This will give the entity2 name	
                    if (DonerID != null) {
                        Xrm.Page.data.entity.attributes.get("gems_donorid").setValue(DonerID);
                        Xrm.Page.data.entity.attributes.get("gems_donorid").setSubmitMode("always");
                    }
                    else {
                        Xrm.Page.data.entity.attributes.get("gems_donorid").setValue();
                        Xrm.Page.data.entity.attributes.get("gems_donorid").setSubmitMode("always");

                    }

                } else {
                    errorCallback1();
                }
            }
        };
        req.send();
    }
    else {
        Xrm.Page.data.entity.attributes.get("gems_medicaltissuedatetimedeath").setValue();
        Xrm.Page.data.entity.attributes.get("gems_donorid").setValue();
        Xrm.Page.data.entity.attributes.get("gems_medicaltissuedatetimedeath").setSubmitMode("always");
        Xrm.Page.data.entity.attributes.get("gems_donorid").setSubmitMode("always");

    }

}

function errorCallback1() {
    alert("Ahh !!! the error occurred onchange");
}

function populate() {
    debugger;
    if (Xrm.Page.getAttribute("gems_medicalreviewidid") != undefined && Xrm.Page.getAttribute("gems_medicalreviewidid") != null) {

        var medicalObj = Xrm.Page.getAttribute("gems_medicalreviewidid").getValue();
        if (medicalObj != null) {
            var medicalGuidId = medicalObj[0].id;
            var cols = ["gems_recoverymedicaldatetimedeath", "gems_name"];
            var retrievedRecord = XrmServiceToolkit.Soap.Retrieve("gems_medicalreview", medicalGuidId, cols);

            setTissueEvaluationDetails("gems_medicaltissuedatetimedeath", retrievedRecord, "gems_recoverymedicaldatetimedeath");
            setTissueEvaluationDetails("gems_donorid", retrievedRecord, "gems_name");
        }
    }
}
function setTissueEvaluationDetails(fieldname, entityCollection, masterEntityField) {
    debugger;
    var record = eval("entityCollection.attributes." + masterEntityField);
    if (record != null && record != undefined) {
        Xrm.Page.getAttribute(fieldname).setValue(record.value);

    }
    else {
        Xrm.Page.getAttribute(fieldname).setValue(null);

    }
    Xrm.Page.getAttribute(fieldname).setSubmitMode("always");
}



// Populate data from Recovery to Tissue Evaluation
function getTissueMediaDetails() {
    debugger;
    if (Xrm.Page.getAttribute("gems_medicalreviewidid").getValue() != null || Xrm.Page.getAttribute("gems_medicalreviewidid").getValue() != undefined) {
        if (Xrm.Page.getAttribute("gems_werecorneasprocessedunderanlafhood") != null || Xrm.Page.getAttribute("gems_werecorneasprocessedunderanlafhood") != undefined) {
            var checkLFH = Xrm.Page.getAttribute("gems_werecorneasprocessedunderanlafhood").getValue();
            var donorID = Xrm.Page.getAttribute("gems_donorid").getValue();
            if (checkLFH == 0) {
                var fetchXML = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
					  '<entity name="gems_recovery">' +
						'<attribute name="gems_name" />' +
						'<attribute name="gems_recoveryid" />' +
						'<attribute name="gems_preservationmediaexpirationdate" />' +
						'<attribute name="gems_preservationmedia" />' +
						'<attribute name="gems_medialot" />' +
						'<order attribute="gems_name" descending="false" />' +
						'<filter type="and">' +
						  '<condition attribute="gems_name" operator="eq" value="' + donorID + '" />' +
						'</filter>' +
					  '</entity>' +
					'</fetch>'

                var collection = XrmServiceToolkit.Soap.Fetch(fetchXML);
                if (collection[0].attributes.gems_medialot != null && collection[0].attributes.gems_medialot != undefined) {
                    Xrm.Page.getAttribute("gems_medialot").setValue(collection[0].attributes.gems_medialot.value);
                    var newMediaLot = Xrm.Page.getAttribute("gems_newmedialot").getValue();
                    if (newMediaLot == null && newMediaLot == undefined) {
                        Xrm.Page.getAttribute("gems_newmedialot").setValue(collection[0].attributes.gems_medialot.value);
                    }
                }
                if (collection[0].attributes.gems_preservationmediaexpirationdate != null && collection[0].attributes.gems_preservationmediaexpirationdate != undefined) {
                    Xrm.Page.getAttribute("gems_mediaexpirationdate").setValue(collection[0].attributes.gems_preservationmediaexpirationdate.value);
                    var newMediaLotExpiryDate = Xrm.Page.getAttribute("gems_newmediaexpirydate").getValue();
                    if (newMediaLotExpiryDate == null && newMediaLotExpiryDate == undefined) {
                        Xrm.Page.getAttribute("gems_newmediaexpirydate").setValue(collection[0].attributes.gems_preservationmediaexpirationdate.value);
                    }
                }
                if (collection[0].attributes.gems_preservationmedia != null && collection[0].attributes.gems_preservationmedia != undefined) {
                    Xrm.Page.getAttribute("gems_preservationmedium").setValue(collection[0].attributes.gems_preservationmedia.value);
                }
            }
            //else{
            //Xrm.Page.getAttribute("gems_medialot").setValue(null);
            //Xrm.Page.getAttribute("gems_mediaexpirationdate").setValue(null);
            //Xrm.Page.getAttribute("gems_preservationmedium").setValue(null);
            //}

        }
    }
    //var formType=Xrm.Page.ui.getFormType();
    //	if(formType==2)   //2:Update
    //	{
    //		Xrm.Page.data.entity.save();
    //	}	
}




