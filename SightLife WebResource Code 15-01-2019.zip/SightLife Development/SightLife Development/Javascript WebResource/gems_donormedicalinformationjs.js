﻿var donorId = null;
var xrmObject = Xrm.Page.context.getQueryStringParameters();
donorId = xrmObject["Data"].toString();

var physicalAssessment = {};

var formattedValueArr = ["gems_evidenceofhivinfection", "gems_evidenceoftransmitteddisease", "gems_lymphadenopathy", "gems_signsofivdruguse", "gems_spotsorlesions", "gems_evidenceofbloodloss", "gems_redskinlesions", "gems_evidenceofsmallpox", "gems_mucousmembranehemorrhages"];

var assignFormattedValueArr = ["gems_whitespotsinmouthexplain", "gems_explainifyes"];

var valueArr = ["gems_donorname"];//"gems_medialot", 

var lookupAttrArr = ["gems_physicalinspectionby"];//"gems_assistedby", "gems_collectedby", "gems_recoverycompletedby", ];

var performedBy = ["gems_forodperformedby", "gems_forosperformedby"];

var otherAttributesArr = ["gems_whitespotsinmouth", "gems_commentsonconditionofcornealstromaforod", "gems_pupildiameterofod", "gems_abnormalitiesofod", "gems_evidenceofsurgeryforod", "gems_ifyesspecifyforod", "gems_wbcsnotperformedexplain", "gems_culturesnotdoneexplain"];//"gems_iriscolorofod", "gems_conditionofintraocularforod", "gems_conditionofcornealstromaforod", "gems_conditionofepitheliumforod", "gems_conditionofconjunctivaforos", "gems_conditionofconjunctivaforod", "gems_conditionofinferiorlidforos", "gems_conditionofinferiorlidforod", "gems_conditionofsuperiorlidforos", "gems_conditionofsuperiorlidforod", 
//"gems_commentsonconditionofsuperiorlidforod", "gems_commentsonconditionofinferiorlidforod", "gems_commentsonconditionofconjunctivaforod", "gems_commentsonconditionofepitheliumforod", "gems_commentsonconditionofinferiorlidforos", "gems_commentsonconditionofsuperiorlidforos", "gems_commentsonconditionofconjunctivaforos", "gems_commentsonconditionofepitheliumforos", 

var recAttributesArr = ["gems_commentsonconditionofcornealstromaforos", "gems_pupildiameterofos", "gems_abnormalitiesofos", "gems_evidenceofsurgeryforos", "gems_ifyesspecifyforos", "gems_wbcsperformed", "gems_wbcscount1", "gems_wbcscount2", "gems_wbcscount3", "gems_temperaturerecorded", "gems_temperaturenotrecordedreason", "gems_temperaturerecordedresult1", "gems_temperaturerecordedunits1", "gems_temperaturerecordedresult2", "gems_temperaturerecordedunits2", "gems_temperaturerecordedresult3", "gems_temperaturerecordedunits3", "gems_culturesdone", "gems_culturesource1", "gems_cultureresult1", "gems_culturesource2", "gems_cultureresult2", "gems_culturesource3", "gems_cultureresult3"];//"gems_iriscolorofos", "gems_conditionofintraocularforos", "gems_conditionofcornealstromaforos", "gems_conditionofepitheliumforos", 

var unusedAttrArr = ["gems_referralrecoverylastname", "gems_referralrecoveryfirstname", "gems_datetimebodysubjectedtocooling", "gems_coolingmethod", "gems_deathverifiedby", "gems_eyesorcorneasrecovered", "gems_bodyidentificationmethod", "gems_bodyidentifiedby", "gems_physicalassessment", "createdon", "gems_name", "gems_recoveryid", "gems_datetimebodyremovedfromcooling"];//"gems_prepostmortem", "gems_datetimebloodcollection", "gems_preservationmediaexpirationdate", "gems_preservationmedia", "gems_recoveryintent", "gems_tissuerecoverydatetime", "gems_recoverymethod", "gems_scleraprocessed", 

var dateAttrArr = ["gems_wbcsperformeddatetime1", "gems_wbcsperformeddatetime2", "gems_wbcsperformeddatetime3", "gems_temperaturerecordeddatetime1", "gems_temperaturerecordeddatetime2", "gems_temperaturerecordeddatetime3", "gems_culturedatetime1", "gems_culturedatetime2", "gems_culturedatetime3"];

var multiselect = ["gems_iriscolorofostext", "gems_iriscolorofodtext", "gems_conditionofintraocularforostext", "gems_conditionofintraocularforodtext", "gems_conditionofcornealstromaforostext", "gems_conditionofcornealstromaforodtext", "gems_conditionofepitheliumforostext", "gems_conditionofepitheliumforodtext", "gems_conditionofconjunctivaforostext", "gems_conditionofconjunctivaforodtext", "gems_conditionofinferiorlidforostext", "gems_conditionofinferiorlidforodtext", "gems_conditionofsuperiorlidforostext", "gems_conditionofsuperiorlidforodtext"];

var recoveryAttributesArr = formattedValueArr.concat(assignFormattedValueArr).concat(valueArr).concat(lookupAttrArr).concat(otherAttributesArr).concat(recAttributesArr).concat(unusedAttrArr).concat(dateAttrArr).concat(performedBy).concat(multiselect);

var expanded = false;
var checkboxes;
var prevCheckbox;
var prevEleId = null;

function showCheckboxes(id) {
    checkboxes = document.getElementById(id);

    if (!expanded) {
        checkboxes.style.display = "block";
        checkboxes.style.zIndex = '999';
        if (prevEleId != null && prevEleId != id) {
            prevCheckbox = document.getElementById(prevEleId);
            prevCheckbox.style.display = "none";
        }
        checkboxes.style.width = document.getElementById("gems_conditionofsuperiorlidforod").offsetWidth;
        expanded = true;
    } else {
        checkboxes.style.display = "none";
        expanded = false;
        if (prevEleId != null && prevEleId != id) {
            prevCheckbox = document.getElementById(prevEleId);
            prevCheckbox.style.display = "none";
        }
    }

    prevEleId = id;
}

function retrieveContacts() {
    debugger;
    var contactsFetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                              "<entity name='contact'>" +
                                "<attribute name='fullname' />" +
                                "<order attribute='fullname' descending='false' />" +
                                "<filter type='and'>" +
                                  "<condition attribute='gems_contacttype' operator='in'>" +
                                    "<value>3</value>" +//Eye Donation Counselor
                                    "<value>4</value>" +//Recovery Technician
                                  "</condition>" +
                                "</filter>" +
                              "</entity>" +
                            "</fetch>";

    var contactsCollection = XrmServiceToolkit.Soap.Fetch(contactsFetchXML);
    var contactId = "";
    var contactName = "";
    if (contactsCollection != null && contactsCollection != undefined) {
        if (contactsCollection.length > 0) {
            for (var i = 0; i < contactsCollection.length; i++) {
                if (contactsCollection[i].attributes["contactid"] != null && contactsCollection[i].attributes["contactid"] != undefined) {
                    contactId = contactsCollection[i].attributes["contactid"].value;
                }

                if (contactsCollection[i].attributes["fullname"] != null && contactsCollection[i].attributes["fullname"] != undefined) {
                    contactName = contactsCollection[i].attributes["fullname"].value;
                }

                if (contactId != "" && contactName != "") {
                    $(".gems_forodperformedby").append($("<option></option>").attr("value", contactId).text(contactName));
                    $(".gems_forosperformedby").append($("<option></option>").attr("value", contactId).text(contactName));
                }
            }
        }
    }
}

function clearInputBox(attribute) {
    for (var i = 0; i < attribute.length; i++) {
        var attrArr = attribute[i];
        $("#" + attrArr).val("");
    }
}

function evidenceOfSurgeryOD() {
    var evidenceOfSurgeryVal = $("#gems_evidenceofsurgeryforod option:selected").text();//$("#gems_evidenceofsurgeryforod")[0].checked;

    if (evidenceOfSurgeryVal == "Yes") {
        $("#gems_ifyesspecifyforod").show();
        //$(".gems_forodperformedby").show();
    } else {
        $("#gems_ifyesspecifyforod").hide();
        //$(".gems_forodperformedby").hide();
    }

    evidenceOfSurgery();
}

function evidenceOfSurgeryOS() {
    var evidenceOfSurgeryOS = $("#gems_evidenceofsurgeryforos option:selected").text();//$("#gems_evidenceofsurgeryforos")[0].checked;

    if (evidenceOfSurgeryOS == "Yes") {
        $("#gems_ifyesspecifyforos").show();
        //$(".gems_forosperformedby").show();
    } else {
        $("#gems_ifyesspecifyforos").hide();
        //$(".gems_forosperformedby").hide();
    }
    evidenceOfSurgery();
}

function evidenceOfSurgery() {
    var evidenceOfSurgeryVal = $("#gems_evidenceofsurgeryforod option:selected").text(); //$("#gems_evidenceofsurgeryforod")[0].checked;
    var evidenceOfSurgeryOS = $("#gems_evidenceofsurgeryforos option:selected").text(); //$("#gems_evidenceofsurgeryforos")[0].checked;

    if (evidenceOfSurgeryVal == "No" && evidenceOfSurgeryOS == "No") {
        $("#evidenceOfSurgerySpecify").hide();
        //$("#evidenceOfSurgeryPerformed").hide();
    }
    else if (evidenceOfSurgeryVal == "Yes" && evidenceOfSurgeryOS == "Yes") {
        $("#evidenceOfSurgerySpecify").show();
        //$("#evidenceOfSurgeryPerformed").show();
        $("#gems_ifyesspecifyforod").show();
        //$(".gems_forodperformedby").show();
        $("#gems_ifyesspecifyforos").show();
        //$(".gems_forosperformedby").show();
    } else if (evidenceOfSurgeryVal == "Yes" && evidenceOfSurgeryOS == "No") {
        $("#evidenceOfSurgerySpecify").show();
        //$("#evidenceOfSurgeryPerformed").show();
        $("#gems_ifyesspecifyforod").show();
        //$(".gems_forodperformedby").show();
        $("#gems_ifyesspecifyforos").hide();
        //$(".gems_forosperformedby").hide();
    } else if (evidenceOfSurgeryVal == "No" && evidenceOfSurgeryOS == "Yes") {
        $("#evidenceOfSurgerySpecify").show();
        //$("#evidenceOfSurgeryPerformed").show();
        $("#gems_ifyesspecifyforod").hide();
        //$(".gems_forodperformedby").hide();
        $("#gems_ifyesspecifyforos").show();
        //$(".gems_forosperformedby").show();
    }

    /*if (evidenceOfSurgeryVal) {
        $("#gems_ifyesspecifyforod").show();
        $(".gems_performedbyforod").show();
        $("#gems_ifyesspecifyforos").hide();
        $(".gems_performedbyforos").hide();
    } else if (evidenceOfSurgeryOS) {
        $("#gems_ifyesspecifyforos").show();
        $(".gems_performedbyforos").show();
        $("#gems_ifyesspecifyforod").hide();
        $(".gems_performedbyforod").hide();
    } else {
        $("#gems_ifyesspecifyforod").hide();
        $(".gems_performedbyforod").hide();
        $("#gems_ifyesspecifyforos").hide();
        $(".gems_performedbyforos").hide();
    }*/
}

function whiteSpots() {
    debugger;
    var whiteSpots = $("#gems_whitespotsinmouth option:selected").text(); //$("select option:selected").text();
    if (whiteSpots.toLowerCase() == "yes") {
        $("#whiteSpotsYes").show();
    }
    else {
        $("#whiteSpotsYes").hide();
    }
}

function wbcsPerformedFun() {
    var wbcsperformed = $("#gems_wbcsperformed option:selected").text();//$("#gems_wbcsperformed")[0].checked;

    if (wbcsperformed == "Yes") {
        $("#wbcsperformed").show();
        $("#wbcsnotperformed").hide();
    }
    else {
        $("#wbcsperformed").hide();
        $("#wbcsnotperformed").show();
    }
}

function temperatureFun() {
    var tempRecorded = $("#gems_temperaturerecorded option:selected").text();//$("#gems_temperaturerecorded")[0].checked;

    if (tempRecorded == "Yes") {
        $("#tempInfo").show();
        $("#tempReason").hide();
    }
    else {
        $("#tempReason").show();
        $("#tempInfo").hide();
    }
}

function culturesFun() {
    var culturesDone = $("#gems_culturesdone option:selected").text();//$("#gems_culturesdone")[0].checked;

    if (culturesDone == "Yes") {
        $("#culturesInfo").show();
        $("#culturesnotdone").hide();
    }
    else {
        $("#culturesInfo").hide();
        $("#culturesnotdone").show();
    }
}

/*$('.some_class').datetimepicker({ format: 'd-m-Y H:i', timepickerScrollbar: true, step: 5 });*/

//$("#print").bind("click", function () { window.print(); });

//$("#submitForm").bind("click", function () {
function submitForm() {
    debugger;

    for (var j = 0; j < multiselect.length; j++) {
        var valArr = "";
        for (var i = 0; i < $('input[name="' + multiselect[j] + '"]').length; i++) {
            if ($('input[name="' + multiselect[j] + '"]')[i].checked) {
                valArr += $('input[name="' + multiselect[j] + '"]')[i].value + ", ";
            }
        }

        physicalAssessment[multiselect[j]] = valArr.substring(0, valArr.length - 2);
    }


    //$("#val").text(valArr.substring(0, valArr.length - 2));

    var recoveryAttrArr = formattedValueArr.concat(assignFormattedValueArr).concat(otherAttributesArr).concat(recAttributesArr).concat(dateAttrArr);

    for (var f = 0; f < recoveryAttrArr.length; f++) {
        var attrArr = recoveryAttrArr[f];
        var elementType = document.getElementById(attrArr).type;//$("#" + attrArr).attr('type');
        if (elementType != null && elementType != undefined) {
            if (elementType == "checkbox") {
                physicalAssessment[attrArr] = $('input[name="' + attrArr + '"]')[0].checked;
            }
            else if (elementType == "text") {
                physicalAssessment[attrArr] = $("#" + attrArr).val();
            }
            else if (elementType == "select-one") {
                physicalAssessment[attrArr] = $("#" + attrArr + " option:selected").val();
            }
            else if (elementType == "textarea") {
                physicalAssessment[attrArr] = $("#" + attrArr).val();
            }
        }
        else {
            console.log("Attribute: " + attrArr);
        }
    }

    //for (var p = 0; p < performedBy.length; p++) {
    //var perform = performedBy[p];
    //var performedBy = ["gems_performedbyforod", "gems_performedbyforos"];
    //for (var f = 0; f < recoveryAttrArr.length; f++) {
    if ($(".gems_forodperformedby option:selected").text() != "--Select Value--") {
        physicalAssessment["gems_performedbyforodval"] = $(".gems_forodperformedby option:selected").val();
        physicalAssessment["gems_performedbyforodtext"] = $(".gems_forodperformedby option:selected").text();
    }

    if ($(".gems_forosperformedby option:selected").text() != "--Select Value--") {
        physicalAssessment["gems_performedbyforosval"] = $(".gems_forosperformedby option:selected").val();
        physicalAssessment["gems_performedbyforostext"] = $(".gems_forosperformedby option:selected").text();
    }


    Mscrm.Utilities.setReturnValue(physicalAssessment);
}
//});

function retrieveBULogo() {
    debugger;

    var addressLine1 = "";
    var addressLine2 = "";
    var addressLine3 = "";
    var addressCity = "";
    var addressCountry = "";
    var addressStateOrProvince = "";

    var buInfoFetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                          "<entity name='gems_businessunitlogo'>" +
                            "<attribute name='gems_businessunitlogoid' />" +
                            "<attribute name='gems_name' />" +
                            "<attribute name='entityimage' />" +
                            "<attribute name='createdon' />" +
                            "<attribute name='gems_businessunit' />" +
                            "<order attribute='gems_name' descending='false' />" +
                            "<filter type='and'>" +
                              "<condition attribute='gems_businessunit' operator='eq-businessid' />" +
                            "</filter>" +
                            "<link-entity name='businessunit' from='businessunitid' to='gems_businessunit' alias='aa'>" +
                              "<attribute name='name' />" +
                              "<attribute name='address2_line3' />" +
                              "<attribute name='address2_line2' />" +
                              "<attribute name='address2_line1' />" +
                              "<attribute name='address2_stateorprovince' />" +
                              "<attribute name='address2_country' />" +
                              "<attribute name='address2_city' />" +
                            "</link-entity>" +
                          "</entity>" +
                        "</fetch>";

    var buCollection = XrmServiceToolkit.Soap.Fetch(buInfoFetchXML);

    if (buCollection != null && buCollection != undefined) {
        if (buCollection.length > 0) {
            if (buCollection[0].attributes["entityimage"] != null && buCollection[0].attributes["entityimage"] != undefined) {
                var imageval = buCollection[0].attributes["entityimage"].value;

                if (imageval != null && imageval != undefined) {
                    var image = new Image();
                    image.src = 'data:image/png;base64,' + imageval;
                    image.style = 'height:50px;width:50px';
                    document.getElementById('buLogo').appendChild(image);
                }

                var nameval = buCollection[0].attributes["gems_name"];

            }

            if (buCollection[0].attributes["aa.name"] != null && buCollection[0].attributes["aa.name"] != undefined) {
                var buName = buCollection[0].attributes["aa.name"].value;
            }

            if (buCollection[0].attributes["aa.address2_line1"] != null && buCollection[0].attributes["aa.address2_line1"] != undefined) {
                addressLine1 = buCollection[0].attributes["aa.address2_line1"].value;
            }

            if (buCollection[0].attributes["aa.address2_line2"] != null && buCollection[0].attributes["aa.address2_line2"] != undefined) {
                addressLine2 = buCollection[0].attributes["aa.address2_line2"].value;
            }

            if (buCollection[0].attributes["aa.address2_line3"] != null && buCollection[0].attributes["aa.address2_line3"] != undefined) {
                addressLine3 = buCollection[0].attributes["aa.address2_line3"].value;
            }

            if (buCollection[0].attributes["aa.address2_city"] != null && buCollection[0].attributes["aa.address2_city"] != undefined) {
                addressCity = buCollection[0].attributes["aa.address2_city"].value;
            }

            if (buCollection[0].attributes["aa.address2_country"] != null && buCollection[0].attributes["aa.address2_country"] != undefined) {
                addressCountry = buCollection[0].attributes["aa.address2_country"].value;
            }

            if (buCollection[0].attributes["aa.address2_stateorprovince"] != null && buCollection[0].attributes["aa.address2_stateorprovince"] != undefined) {
                addressStateOrProvince = buCollection[0].attributes["aa.address2_stateorprovince"].value;
            }

            var buDettailsLine1 = "";
            var buDetailsLine2 = "";

            if (addressLine1 != null && addressLine1 != "") {
                buDettailsLine1 += addressLine1;
            }

            if (addressLine2 != null && addressLine2 != "") {
                buDettailsLine1 += ", " + addressLine2;
            }

            if (addressLine3 != null && addressLine3 != "") {
                buDettailsLine1 += ", " + addressLine3 + ",";
            }

            if (addressCity != null && addressCity != "") {
                buDetailsLine2 += addressCity;
            }

            if (addressCountry != null && addressCountry != "") {
                buDetailsLine2 += ", " + addressCountry;
            }

            if (addressStateOrProvince != null && addressStateOrProvince != "") {
                buDetailsLine2 += ", (" + addressStateOrProvince + ")";
            }

            $("#BUDetailsLine1").text(buName);
            $("#BUDetailsLine2").text(buDettailsLine1);
            $("#BUDetailsLine3").text(buDetailsLine2);
        }
    }
}


function getRecoveryData() {
    debugger;

    var recoveryFetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
      "<entity name='gems_recovery'>";

    for (var j = 0; j < recoveryAttributesArr.length; j++) {
        recoveryFetchXML += "<attribute name='" + recoveryAttributesArr[j] + "' />";
    }

    recoveryFetchXML += "<order attribute='createdon' descending='false' />" +
      "<filter type='and'>" +
      "<condition attribute='gems_name' operator='eq' value='" + donorId + "' />" +
      "</filter>" +
      "</entity>" +
      "</fetch>";

    var collection = XrmServiceToolkit.Soap.Fetch(recoveryFetchXML);
    if (collection != null && collection != undefined) {
        if (collection.length > 0) {
            for (var i = 0; i < recoveryAttributesArr.length; i++) {
                var attribute = recoveryAttributesArr[i];
                if (collection[0].attributes[attribute] != null && collection[0].attributes[attribute] != undefined) {
                    if (collection[0].attributes[attribute].type.toLowerCase() == "boolean") {
                        if (collection[0].attributes[attribute].formattedValue.toLowerCase() == "yes") {
                            //$('input[name="' + attribute + '"]').filter(function () {
                            //    return true;
                            //}).prop('checked', true);
                            $("#" + attribute).val("true");

                        } else {
                            $("#" + attribute).val("false");
                        }

                        //if (attribute == "gems_scleraprocessed") {
                        //    if (collection[0].attributes[attribute].formattedValue != null && collection[0].attributes[attribute].formattedValue != undefined) {
                        //        $("#" + attribute).text(collection[0].attributes[attribute].formattedValue);
                        //    }
                        //}
                    }
                    else if (collection[0].attributes[attribute].type.toLowerCase() == "datetime") {
                        if (collection[0].attributes[attribute] != null && collection[0].attributes[attribute] != undefined) {
                            $("#" + attribute).text(collection[0].attributes[attribute].formattedValue);
                            $("#" + attribute).val(collection[0].attributes[attribute].formattedValue);
                        }
                    }
                    else if (collection[0].attributes[attribute].type.toLowerCase() == "entityreference") {
                        if (collection[0].attributes[attribute] != null && collection[0].attributes[attribute] != undefined) {
                            var id = collection[0].attributes[attribute].id;
                            var cols = ["fullname"];
                            var contact = XrmServiceToolkit.Soap.Retrieve("contact", id, cols);
                            if (contact.id != null) {
                                var contactArray = new Array();
                                contactArray[0] = new Object();
                                contactArray[0].id = contact.id;
                                contactArray[0].name = contact.attributes.fullname.value;
                                contactArray[0].entityType = "contact";
                                for (var q = 0; q < performedBy.length; q++) {
                                    if (attribute == performedBy[q].toString()) {
                                        $("." + attribute).val(contactArray[0].id);
                                    }
                                    else {
                                        $("#" + attribute).text(contactArray[0].name);
                                    }
                                }
                            }
                        }
                    }
                    else if (collection[0].attributes[attribute].type.toLowerCase() == "string") {
                        if (collection[0].attributes[attribute] != null && collection[0].attributes[attribute] != undefined) {
                            $("#" + attribute).text(collection[0].attributes[attribute].value);
                            $("#" + attribute).val(collection[0].attributes[attribute].value);

                            for (var m = 0; m < multiselect.length; m++) {
                                if (multiselect[m] == attribute) {
                                    var values = collection[0].attributes[attribute].value;//"Abrasion, Contusion, Edematous";
                                    console.log(values);
                                    $.each(values.split(", "), function (i, e) {
                                        //console.log($('input[value="' + e + '"]'));
                                        //$('input[value="' + e + '"]').filter(function () {return true;}).prop('checked', true);
                                        $('input[value="' + e + '"]').filter($('input.' + attribute)).prop('checked', true);
                                    });
                                    var selectOptionId = attribute.substring(0, attribute.length - 4);
                                    $("#" + selectOptionId + " option").text(values);
                                }
                            }
                        }
                    }
                    else if (collection[0].attributes[attribute].type.toLowerCase() == "optionsetvalue") {
                        var attributeFormattedValue = collection[0].attributes[attribute].formattedValue;
                        var attributeValue = collection[0].attributes[attribute].value;

                        for (var j = 0; j < unusedAttrArr.length; j++) {
                            if (attribute == unusedAttrArr[j].toString()) {
                                if (attribute != "gems_bodyidentificationmethod") {
                                    $("#" + attribute).text(attributeFormattedValue);
                                }
                                else {
                                    if (attributeValue == 1) {
                                        $("#" + attribute).text("Yes");
                                        $("#bodyidentifiedbyYes").show();
                                        $("#bodyidentifiedbyNo").hide();
                                    } else if (attributeValue == 2) {
                                        $("#" + attribute).text("No");
                                        $("#bodyidentifiedbyNo").show();
                                        $("#bodyidentifiedbyYes").hide();
                                    }
                                }
                            }
                            else {
                                $('#' + attribute).val(attributeValue);
                            }
                        }
                    }
                }
                else {
                    $("#bodyidentifiedbyYes").hide();
                    $("#bodyidentifiedbyNo").hide();
                    $("#gems_bodyidentifiedby").hide();
                }
            }
        }
    }
}

function collapse(e) {
    var elementType = e.target.className;
    var secondElement = null;
    if (e.path[1].attributes.length > 0) {
        secondElement = e.path[1].attributes["0"].value;
    }
    //console.log("Element Type: " + elementType);
    if (elementType != "overSelect" && secondElement != "chbx") {
        if (expanded) {
            checkboxes.style.display = "none";
            expanded = false;
        }
    }
}