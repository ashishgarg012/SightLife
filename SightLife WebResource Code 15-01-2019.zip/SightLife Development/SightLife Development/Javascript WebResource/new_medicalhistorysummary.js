﻿function setValueMedicalHistorySummary() {
    debugger;
    var recoveryId = Xrm.Page.getAttribute("gems_originatingrecoveryid").getValue()[0].id;

    var fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
			  "<entity name='gems_recovery'>" +
				"<attribute name='gems_name' />" +
				"<attribute name='gems_recoveryid' />" +
				"<attribute name='gems_originatingrefferalid' />" +
				"<order attribute='gems_name' descending='false' />" +
				"<filter type='and'>" +
				  "<condition attribute='gems_recoveryid' operator='eq' value='" + recoveryId + "' />" +
				"</filter>" +
			  "</entity>" +
			"</fetch>";

    var result = XrmServiceToolkit.Soap.Fetch(fetchXML);
    var referralId = null;
    if (result.length > 0) {
        if (result[0].attributes.gems_originatingrefferalid != undefined && result[0].attributes.gems_originatingrefferalid != null) {
            if (result[0].attributes["gems_originatingrefferalid"] != undefined && result[0].attributes["gems_originatingrefferalid"].id != null) {
                referralId = result[0].attributes["gems_originatingrefferalid"].id;
            }
        }
    }

    var fetchReferral = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                     "<entity name='gems_referral'>" +
                        "<attribute name='gems_referralid' />" +
                        "<attribute name='gems_name' />" +
                        "<attribute name='gems_medicalocularhistory' />" +
                        "<order attribute='gems_name' descending='false' />" +
                        "<filter type='and'>" +
                          "<condition attribute='gems_referralid' operator='eq' value='" + referralId + "' />" +
                        "</filter>" +
                      "</entity>" +
                    "</fetch>";
    var referralResult = XrmServiceToolkit.Soap.Fetch(fetchReferral);
    var medicalHistory = null;

    if (referralResult.length > 0) {
        if (referralResult[0].attributes.gems_medicalocularhistory != undefined && referralResult[0].attributes.gems_medicalocularhistory != null) {
            if (referralResult[0].attributes["gems_medicalocularhistory"] != undefined && referralResult[0].attributes["gems_medicalocularhistory"] != null) {
                medicalHistory = referralResult[0].attributes.gems_medicalocularhistory.value;
            }
        }
        Xrm.Page.getAttribute("gems_medicalsurgicalhistorysummary").setValue(medicalHistory);
    }

}