﻿function DeathNotificationDate_Valdation() {
    debugger;
    var CurrentDate = new Date();
    var BirthDate = Xrm.Page.getAttribute('gems_donordob').getValue();
    var DeathDate = Xrm.Page.getAttribute('gems_datetimeofdeath').getValue();
    var DeathNotificationDate = Xrm.Page.getAttribute('gems_deathnotificationdatetime').getValue();

    if (DeathNotificationDate > CurrentDate) {
        alert('Please enter an appropriate Date and Time ! ')
        Xrm.Page.getAttribute('gems_deathnotificationdatetime').setValue();
    }
}



function BirthDate_Valdation() {
    //debugger;
    var CurrentDate = new Date();
    var BirthDate = Xrm.Page.getAttribute('gems_donordob').getValue();
    var DeathDate = Xrm.Page.getAttribute('gems_datetimeofdeath').getValue();
    var DeathNotificationDate = Xrm.Page.getAttribute('gems_deathnotificationdatetime').getValue();

    if (BirthDate > CurrentDate) {
        alert('Please enter an appropriate Date and Time ! ')
        Xrm.Page.getAttribute('gems_donordob').setValue();
    }
}



//function DeathDate_Valdation()
// {
//debugger;
//    var CurrentDate = new Date();
//	var BirthDate= Xrm.Page.getAttribute('gems_donordob').getValue();
//	var DeathDate= Xrm.Page.getAttribute('gems_datetimeofdeath').getValue();
//	var DeathNotificationDate= Xrm.Page.getAttribute('gems_deathnotificationdatetime').getValue();

//	if(DeathDate>CurrentDate)
//	{
//	 alert('Please ensure that Date/Time of death should not be later than Date/Time of death notification.')
//	 Xrm.Page.getAttribute('gems_datetimeofdeath').setValue(DeathNotificationDate);
//	}
//}



function ReferralDate_Valdation(context) {
    debugger;
    var BirthDate = Xrm.Page.getAttribute('gems_donordob').getValue();
    var DeathDate = Xrm.Page.getAttribute('gems_datetimeofdeath').getValue();
    var DeathNotificationDate = Xrm.Page.getAttribute('gems_deathnotificationdatetime').getValue();

    var saveEvt = context.getEventArgs();
    if ((BirthDate > DeathNotificationDate) || (BirthDate > DeathDate)) {
        alert('Please enter an appropriate Date and Time ! ');
        saveEvt.preventDefault();
    }
    else if (DeathDate > DeathNotificationDate) {
        alert('Please ensure that Date/Time of death should not be later than Date/Time of death notification.');
        Xrm.Page.getAttribute('gems_datetimeofdeath').setValue(null);
        saveEvt.preventDefault();
    }
}


function ReferralDate_Valdation_death() {
    debugger;
    var CurrentDate = new Date();
    var DeathDate = Xrm.Page.getAttribute('gems_datetimeofdeath').getValue();
    var DeathNotificationDate = Xrm.Page.getAttribute('gems_deathnotificationdatetime').getValue();

    if (DeathDate > CurrentDate || DeathDate > DeathNotificationDate) {
        alert('Please ensure that Date/Time of death should not be later than Date/Time of death notification.')
        // Xrm.Page.getAttribute('gems_datetimeofdeath').setValue(null);
    }
}


function DateOfAdmission_Valdation() {
    //debugger;
    var CurrentDate = new Date();
    var Dateofadmission = Xrm.Page.getAttribute('gems_admissiondate').getValue();

    if (Dateofadmission > CurrentDate) {
        alert('Please enter an appropriate Date and Time ! ')
        Xrm.Page.getAttribute('gems_admissiondate').setValue();
    }
}