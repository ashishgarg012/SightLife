﻿function SaveReadOnlyFields() {
    Xrm.Page.data.entity.attributes.get("gems_name").setSubmitMode("always");
}