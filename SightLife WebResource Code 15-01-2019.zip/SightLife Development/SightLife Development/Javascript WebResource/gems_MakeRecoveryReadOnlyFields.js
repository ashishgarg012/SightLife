﻿function MakeReadOnlyFields() {

    //   if ($("#header_process_d").length>0)
    // {
    if (Xrm.Page.getControl('header_process_gems_coolingmethod') != null) {
        Xrm.Page.getControl('header_process_gems_coolingmethod').setDisabled(true);
    }
    if (Xrm.Page.getControl('header_process_gems_datetimebodysubjectedtocooling') != null) {
        Xrm.Page.getControl('header_process_gems_datetimebodysubjectedtocooling').setDisabled(true);
    }
    if (Xrm.Page.getControl('header_process_gems_datetimebodyremovedfromcooling') != null) {
        Xrm.Page.getControl('header_process_gems_datetimebodyremovedfromcooling').setDisabled(true);
    }
    if (Xrm.Page.getControl('header_process_gems_recoveryoutcome') != null) {
        Xrm.Page.getControl('header_process_gems_recoveryoutcome').setDisabled(true);
    }
    //    }
}
