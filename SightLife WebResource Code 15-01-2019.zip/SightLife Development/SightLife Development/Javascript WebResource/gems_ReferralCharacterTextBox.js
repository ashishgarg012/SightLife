﻿function checkDon() {
    var checkkeypressfunction = function (ext) {
        masterCheck("gems_donorfirstname");
        masterCheck("gems_donorlastname");
        masterCheck("gems_callersfirstname");
        masterCheck("gems_callerslastname");
        masterCheck("gems_otherrelationship");
    }
    Xrm.Page.getControl("gems_donorfirstname").addOnKeyPress(checkkeypressfunction);
    Xrm.Page.getControl("gems_donorlastname").addOnKeyPress(checkkeypressfunction);
    Xrm.Page.getControl("gems_callersfirstname").addOnKeyPress(checkkeypressfunction);
    Xrm.Page.getControl("gems_callerslastname").addOnKeyPress(checkkeypressfunction);
    Xrm.Page.getControl("gems_otherrelationship").addOnKeyPress(checkkeypressfunction);
}

function masterCheck(targetfield) {
    var checkValue = Xrm.Page.getControl(targetfield).getValue();
    if (checkValue != null && checkValue != undefined) {
        if (checkValue.length > 0) {
            var c = checkValue.substr(checkValue.length - 1);
            var s = c.charCodeAt(0);
            if (s != 8 && s != 0 && s != 45 && s != 46 && (s < 65 || s > 90) && (s < 97 || s > 122)) {
                if (checkValue.length > 1)

                    Xrm.Page.getAttribute(targetfield).setValue(checkValue.substr(0, checkValue.length - 1));

                else

                    Xrm.Page.getAttribute(targetfield).setValue(null);
            }
        }
    }
}


function CheckCharacter() {
    if (Xrm.Page.context.client.getClient() != "Mobile") {
        var checkkeypressfunction = function (ext) {
            masterCheck("gems_donorfirstname");
            masterCheck("gems_donorlastname");
            masterCheck("gems_callersfirstname");
            masterCheck("gems_callerslastname");
            masterCheck("gems_otherrelationship");
        }
        Xrm.Page.getControl("gems_donorfirstname").addOnKeyPress(checkkeypressfunction);
        Xrm.Page.getControl("gems_donorlastname").addOnKeyPress(checkkeypressfunction);
        Xrm.Page.getControl("gems_callersfirstname").addOnKeyPress(checkkeypressfunction);
        Xrm.Page.getControl("gems_callerslastname").addOnKeyPress(checkkeypressfunction);
        Xrm.Page.getControl("gems_otherrelationship").addOnKeyPress(checkkeypressfunction);
    }
}

function masterCheck(targetfield) {
    var checkValue = Xrm.Page.getControl(targetfield).getValue();
    if (checkValue != null && checkValue != undefined) {
        if (checkValue.substr(checkValue.length - 1).charCodeAt(0) != 8) {
            var finalValue = Xrm.Page.getControl(targetfield).getValue().toString().replace(/[^a-z\A-Z\.\-]+/g, "");
            Xrm.Page.getAttribute(targetfield).setValue(finalValue);
        }
    }
}