﻿function GetDonorId() {
    var gid = Xrm.Page.getAttribute('gems_referraldonorid');
    var donorId = Xrm.Page.data.entity.getId();

    if (donorId != null) {
        donorId = donorId.substring(1, donorId.length - 1);
        gid.setValue(donorId);
    }

}
