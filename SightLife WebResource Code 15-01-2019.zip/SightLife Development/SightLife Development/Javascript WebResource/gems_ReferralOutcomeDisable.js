﻿function DisableRO() {
    debugger;
    if (Xrm.Page.getAttribute('gems_isrecoverycreated') != null) {

        var checkRecovery = Xrm.Page.getAttribute('gems_isrecoverycreated').getValue();

        if (checkRecovery != null) {

            if (checkRecovery == true) {

                if (Xrm.Page.getControl('header_process_gems_referraloutcome') != null) {
                    Xrm.Page.getControl('header_process_gems_referraloutcome').setDisabled(true);
                    Xrm.Page.getControl('gems_referraloutcome').setDisabled(true);
                }
            }
            else {
                if (Xrm.Page.getControl('header_process_gems_referraloutcome') != null) {
                    Xrm.Page.getControl('header_process_gems_referraloutcome').setDisabled(false);
                    Xrm.Page.getControl('gems_referraloutcome').setDisabled(false);
                }
            }
        }
    }
}