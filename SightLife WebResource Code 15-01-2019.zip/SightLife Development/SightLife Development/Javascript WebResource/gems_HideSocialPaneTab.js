﻿function HideSocialPaneTab() {
    var ctrlElement = parent.document.getElementById("header_notescontrol");
    //.getElementById() is not supported by many browsers and causes errors
    if (ctrlElement != null && ctrlElement.children != null && ctrlElement.children.length > 0) {
        for (var ele = 0; ele < ctrlElement.children.length; ele++) {
            var ctrl = ctrlElement.children[ele];
            if (ctrl.title == 'ACTIVITIES') {
                ctrl.style.display = "none";
                if (ele + 1 < ctrlElement.children.length) {
                    ctrlElement.children[ele + 1].click();
                    return;
                } else if ((ele - 1) >= 0) {
                    ctrlElement.children[ele - 1].click();
                    return;
                }
            }
        }
    }
}

function showDonorMedInfoTabsForMobile() {
    debugger;
    var client = Xrm.Page.context.client.getClient();

    if (Xrm.Page.getAttribute("gems_eyesorcorneasrecovered") != null && Xrm.Page.getAttribute("gems_eyesorcorneasrecovered") != undefined) {
        var eyesOrCorneasRecovered = Xrm.Page.getAttribute("gems_eyesorcorneasrecovered").getValue();

        if (client.toLowerCase() == "mobile") {
            Xrm.Page.ui.tabs.get("DonorMedicalInformation").setVisible(true);
            Xrm.Page.ui.tabs.get("LaboratoryInformationTab").setVisible(true);

            if (eyesOrCorneasRecovered == 1) {
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EYEASSESSMENTPENLIGHTEXAM").setVisible(false);
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EyeAssessmentOS").setVisible(true);
            } else if (eyesOrCorneasRecovered == 2) {
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EyeAssessmentOS").setVisible(false);
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EYEASSESSMENTPENLIGHTEXAM").setVisible(true);
            } else {
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EyeAssessmentOS").setVisible(true);
                Xrm.Page.ui.tabs.get("DonorMedicalInformation").sections.get("EYEASSESSMENTPENLIGHTEXAM").setVisible(true);
            }
        } else {
            Xrm.Page.ui.tabs.get("DonorMedicalInformation").setVisible(false);
            Xrm.Page.ui.tabs.get("LaboratoryInformationTab").setVisible(false);
        }
    }
}

function wbcChange() {
    debugger;
    var client = Xrm.Page.context.client.getClient();

    if (client.toLowerCase() == "mobile") {
        if (Xrm.Page.getAttribute("gems_wbcsperformed") != null && Xrm.Page.getAttribute("gems_wbcsperformed") != undefined) {
            var wbcsPerformed = Xrm.Page.getAttribute("gems_wbcsperformed").getValue();

            if (wbcsPerformed) {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("WBCPerformedData").setVisible(true);
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("wbcnotperformedexplain").setVisible(false);
            } else {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("WBCPerformedData").setVisible(false);
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("wbcnotperformedexplain").setVisible(true);
            }
        }
    }
}

function temperatureChange() {
    debugger;
    var client = Xrm.Page.context.client.getClient();

    if (client.toLowerCase() == "mobile") {
        if (Xrm.Page.getAttribute("gems_temperaturerecorded") != null && Xrm.Page.getAttribute("gems_temperaturerecorded") != undefined) {
            var temperatureRecorded = Xrm.Page.getAttribute("gems_temperaturerecorded").getValue();

            if (temperatureRecorded) {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("TemperatureReason").setVisible(false);
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("TemperatureData").setVisible(true);
            } else {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("TemperatureData").setVisible(false);
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("TemperatureReason").setVisible(true);
            }
        }
    }
}

function culturesChange() {
    debugger;
    var client = Xrm.Page.context.client.getClient();

    if (client.toLowerCase() == "mobile") {
        if (Xrm.Page.getAttribute("gems_culturesdone") != null && Xrm.Page.getAttribute("gems_culturesdone") != undefined) {
            var culturesDone = Xrm.Page.getAttribute("gems_culturesdone").getValue();
            if (culturesDone) {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("CulturesData").setVisible(true);
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("Culturesnotdoneexplain").setVisible(false);
            } else {
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("CulturesData").setVisible(false);
                Xrm.Page.ui.tabs.get("LaboratoryInformationTab").sections.get("Culturesnotdoneexplain").setVisible(true);
            }
        }
    }
}

function clearFields(attribute) {
    debugger;
    var attrArr = [];
    if (attribute == "cultures") {
        attrArr = ["gems_culturesnotdoneexplain", "gems_culturesource1", "gems_culturedatetime1", "gems_cultureresult1", "gems_culturesource2", "gems_culturedatetime2", "gems_cultureresult2", "gems_culturesource3", "gems_culturedatetime3", "gems_cultureresult3"];
    }
    else if (attribute == "temperature") {
        attrArr = ["gems_temperaturenotrecordedreason", "gems_temperaturerecordeddatetime1", "gems_temperaturerecordeddatetime2", "gems_temperaturerecordeddatetime3", "gems_temperaturerecordedresult1", "gems_temperaturerecordedresult2", "gems_temperaturerecordedresult3", "gems_temperaturerecordedunits1", "gems_temperaturerecordedunits2", "gems_temperaturerecordedunits3"];
    }
    else if (attribute == "tlc") {
        attrArr = ["gems_wbcsnotperformedexplain", "gems_wbcsperformeddatetime1", "gems_wbcsperformeddatetime2", "gems_wbcsperformeddatetime3", "gems_wbcscount1", "gems_wbcscount2", "gems_wbcscount3"];
    }

    for (var i = 0; i < attrArr.length; i++) {
        var attr = attrArr[i];
        if (Xrm.Page.getAttribute(attr) != null && Xrm.Page.getAttribute(attr) != undefined) {
            Xrm.Page.getAttribute(attr).setValue();
        }
    }
}