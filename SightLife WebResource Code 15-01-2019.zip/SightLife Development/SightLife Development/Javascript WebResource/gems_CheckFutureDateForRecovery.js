﻿//gems_CheckFutureDateForRecovery
function ValidateBodySubjectedToCooling() {
    debugger;
    var CurrentDate = new Date();
    var compareDate;
    if (Xrm.Page.getAttribute('gems_datetimebodysubjectedtocooling') != null && Xrm.Page.getAttribute('gems_datetimebodysubjectedtocooling') != undefined) {
        if (Xrm.Page.getAttribute('gems_datetimebodysubjectedtocooling').getValue() != null && Xrm.Page.getAttribute('gems_datetimebodysubjectedtocooling').getValue() != undefined) {

            compareDate = Xrm.Page.getAttribute('gems_datetimebodysubjectedtocooling').getValue();
            var dateTimeOfDeath = Xrm.Page.getAttribute('gems_datetimeofdeath').getValue();

            if (compareDate.toDateString() == dateTimeOfDeath.toDateString()) {
                if (compareDate.getTime() < dateTimeOfDeath.getTime()) {
                    compareDate = new Date(compareDate.setMilliseconds(dateTimeOfDeath.getTime() - compareDate.getTime()));
                    Xrm.Page.getAttribute('gems_datetimebodysubjectedtocooling').setValue(compareDate);
                }
            } else if (compareDate != null && compareDate > CurrentDate) {
                Xrm.Page.getControl("gems_datetimebodysubjectedtocooling").setNotification("Date/Time of body subjected to cooling should not be greater than current date/time.");
                //Xrm.Page.getAttribute('gems_datetimebodysubjectedtocooling').setValue();
            } else if (compareDate < dateTimeOfDeath) {
                Xrm.Page.getControl("gems_datetimebodysubjectedtocooling").setNotification("Date/Time of body subjected to cooling should not be less than Date/Time of death.");
                //Xrm.Page.getAttribute('gems_datetimebodysubjectedtocooling').setValue();
            } else {
                Xrm.Page.getControl("gems_datetimebodysubjectedtocooling").clearNotification();
            }
        }
    }
}

function ValidateRemovedFromCooling() {
    var CurrentDate = new Date();
    var compareDate = Xrm.Page.getAttribute('gems_datetimebodyremovedfromcooling').getValue();
    if (compareDate != null && compareDate > CurrentDate) {
        Xrm.Page.getControl("gems_datetimebodyremovedfromcooling").setNotification('Date/Time body removed from cooling should not be greater than current date/time.');
        //Xrm.Page.getAttribute('gems_datetimebodyremovedfromcooling').setValue();
    } else {
        Xrm.Page.getControl("gems_datetimebodyremovedfromcooling").clearNotification();
    }
}

function ValidateTissueRecovery() {
    debugger;
    var CurrentDate = new Date();
    var compareDate = Xrm.Page.getAttribute('gems_tissuerecoverydatetime').getValue();
    if (compareDate != null && compareDate > CurrentDate) {
        Xrm.Page.getControl("gems_tissuerecoverydatetime").setNotification('Tissue recovery date/time should not be greater than current date/time');
        //Xrm.Page.getAttribute('gems_tissuerecoverydatetime').setValue();
    } else {
        Xrm.Page.getControl("gems_tissuerecoverydatetime").clearNotification();
    }
}

function ValidateCorneaPreservation() {
    debugger;
    var CurrentDate = new Date();
    var tissueRecoveryDateTime = null;
    var compareDate;
    if (Xrm.Page.getAttribute('gems_corneapreservationdatetime') != null && Xrm.Page.getAttribute('gems_corneapreservationdatetime') != undefined) {
        if (Xrm.Page.getAttribute('gems_corneapreservationdatetime').getValue() != null && Xrm.Page.getAttribute('gems_corneapreservationdatetime').getValue() != undefined) {

            compareDate = Xrm.Page.getAttribute('gems_corneapreservationdatetime').getValue();

            if (Xrm.Page.getAttribute("gems_tissuerecoverydatetime") != null && Xrm.Page.getAttribute("gems_tissuerecoverydatetime") != undefined) {
                if (Xrm.Page.getAttribute("gems_tissuerecoverydatetime").getValue() != null && Xrm.Page.getAttribute("gems_tissuerecoverydatetime").getValue() != undefined) {
                    tissueRecoveryDateTime = Xrm.Page.getAttribute("gems_tissuerecoverydatetime").getValue();
                }
            }

            if (compareDate.toDateString() == tissueRecoveryDateTime.toDateString()) {
                if (compareDate.getTime() < tissueRecoveryDateTime.getTime()) {
                    compareDate = new Date(compareDate.setMilliseconds(tissueRecoveryDateTime.getTime() - compareDate.getTime()));
                    Xrm.Page.getAttribute('gems_corneapreservationdatetime').setValue(compareDate);
                }
            }

            // if (compareDate < tissueRecoveryDateTime) {
            // alert("Cornea preservation Date/Time should not be less than Tissue recovery Date/Time.");
            // Xrm.Page.getAttribute('gems_corneapreservationdatetime').setValue(tissueRecoveryDateTime);
            // compareDate = Xrm.Page.getAttribute('gems_corneapreservationdatetime').getValue();
            // }

            if (compareDate != null && compareDate > CurrentDate) {
                //alert('Please enter an appropriate Date and Time ! ');
                Xrm.Page.getControl("gems_corneapreservationdatetime").setNotification("Cornea preservation Date/Time should not be greater than current date/time.");
                //Xrm.Page.getAttribute('gems_corneapreservationdatetime').setValue();
            } else if (compareDate != null && tissueRecoveryDateTime != null) {
                if (compareDate < tissueRecoveryDateTime) {
                    Xrm.Page.getControl("gems_corneapreservationdatetime").setNotification("Cornea preservation Date/Time should not be less than Tissue recovery Date/Time.");
                    //Xrm.Page.getAttribute('gems_corneapreservationdatetime').setValue();
                } else {
                    Xrm.Page.getControl("gems_corneapreservationdatetime").clearNotification();
                }
            } else {
                Xrm.Page.getControl("gems_corneapreservationdatetime").clearNotification();
            }
        }
    }
}

function ValidateScleraPreservation() {
    var CurrentDate = new Date();
    var compareDate = Xrm.Page.getAttribute('gems_sclerapreservationdatetime').getValue();
    if (compareDate != null && compareDate > CurrentDate) {
        Xrm.Page.getControl("gems_sclerapreservationdatetime").setNotification('Sclera presservation date/time should not be greater than current date/time');
        //Xrm.Page.getAttribute('gems_sclerapreservationdatetime').setValue();
    } else {
        Xrm.Page.getControl("gems_sclerapreservationdatetime").clearNotification();
    }
}

function ValidateBloodSampleCollection() {
    var CurrentDate = new Date();
    var compareDate = Xrm.Page.getAttribute('gems_datetimebloodcollection').getValue();
    if (compareDate != null && compareDate > CurrentDate) {
        Xrm.Page.getControl("gems_datetimebloodcollection").setNotification('Date/time blood collection should not be greater than current date/time');
        //Xrm.Page.getAttribute('gems_datetimebloodcollection').setValue();
    } else {
        Xrm.Page.getControl("gems_datetimebloodcollection").clearNotification();
    }
}

//Tissue Recovery should be greater or equal to Date/Time of Death Notification...10 Feb 2017
function recoveryDateofDeath_Validation() {
    debugger;
    var monthTissue;
    var dayTissue;
    var monthDeath;
    var dayDeath;
    var tissueRecoveryTime;
    var dateofdeathnotification;
    var flag;
    var dateTimeBodySubjectedToCooling;
    var monthCooling;
    var dayCooling;

    if (Xrm.Page.getAttribute("gems_tissuerecoverydatetime") != null || Xrm.Page.getAttribute("gems_tissuerecoverydatetime") != undefined) {
        if (Xrm.Page.getAttribute("gems_tissuerecoverydatetime").getValue() != null || Xrm.Page.getAttribute("gems_tissuerecoverydatetime").getValue() != undefined) {
            tissueRecoveryTime = Xrm.Page.getAttribute("gems_tissuerecoverydatetime").getValue();
            // if (tissueRecoveryTime != null || tissueRecoveryTime != undefined) {
            // monthTissue = tissueRecoveryTime.getMonth() + 1;
            // dayTissue = tissueRecoveryTime.getDate();
            // }

            if (Xrm.Page.getAttribute("gems_datetimebodysubjectedtocooling").getValue() != null && Xrm.Page.getAttribute("gems_datetimebodysubjectedtocooling").getValue() != undefined) {
                dateTimeBodySubjectedToCooling = Xrm.Page.getAttribute("gems_datetimebodysubjectedtocooling").getValue();
                // if (dateTimeBodySubjectedToCooling != null || dateTimeBodySubjectedToCooling != undefined) {
                // monthCooling = dateTimeBodySubjectedToCooling.getMonth() + 1;
                // dayCooling = dateTimeBodySubjectedToCooling.getDate();
                // }

                if (tissueRecoveryTime.toDateString() == dateTimeBodySubjectedToCooling.toDateString()) {
                    if (tissueRecoveryTime.getTime() < dateTimeBodySubjectedToCooling.getTime()) {
                        tissueRecoveryTime = new Date(tissueRecoveryTime.setMilliseconds(dateTimeBodySubjectedToCooling.getTime() - tissueRecoveryTime.getTime()));
                        Xrm.Page.getAttribute('gems_tissuerecoverydatetime').setValue(tissueRecoveryTime);
                        Xrm.Page.getControl("gems_tissuerecoverydatetime").clearNotification();
                    } else {
                        Xrm.Page.getControl("gems_tissuerecoverydatetime").clearNotification();
                    }
                } else if (tissueRecoveryTime < dateTimeBodySubjectedToCooling) {
                    Xrm.Page.getControl("gems_tissuerecoverydatetime").setNotification("The tissue recovery date/time should be later than Date/Time Body Subjected To Cooling.");
                    //Xrm.Page.getAttribute("gems_tissuerecoverydatetime").setValue();
                } else {
                    Xrm.Page.getControl("gems_tissuerecoverydatetime").clearNotification();
                }

                // if (dayTissue == dayCooling) {
                // var dateTimeBodySubjectedToCoolingMillsec = dateTimeBodySubjectedToCooling.getTime() + 1800000;
                // Xrm.Page.getAttribute("gems_tissuerecoverydatetime").setValue(dateTimeBodySubjectedToCoolingMillsec);
                // tissueRecoveryTimeSameDay = Xrm.Page.getAttribute("gems_tissuerecoverydatetime").getValue();
                // flag = true;
                // }

            } else {
                if (Xrm.Page.getAttribute("gems_referralrecoverydeathnotificationdatetime") != null && Xrm.Page.getAttribute("gems_referralrecoverydeathnotificationdatetime") != undefined) {
                    dateofdeathnotification = Xrm.Page.getAttribute("gems_referralrecoverydeathnotificationdatetime").getValue();

                    if (tissueRecoveryTime.toDateString() == dateofdeathnotification.toDateString()) {
                        if (tissueRecoveryTime.getTime() < dateofdeathnotification.getTime()) {
                            tissueRecoveryTime = new Date(tissueRecoveryTime.setMilliseconds(dateofdeathnotification.getTime() - tissueRecoveryTime.getTime()));
                            Xrm.Page.getAttribute('gems_tissuerecoverydatetime').setValue(tissueRecoveryTime);
                            Xrm.Page.getControl("gems_tissuerecoverydatetime").clearNotification();
                        } else {
                            Xrm.Page.getControl("gems_tissuerecoverydatetime").clearNotification();
                        }
                    } else if (tissueRecoveryTime < dateofdeathnotification) {
                        Xrm.Page.getControl("gems_tissuerecoverydatetime").setNotification("The tissue recovery date/time should be later than Death Notification Date/Time.");
                        //Xrm.Page.getAttribute("gems_tissuerecoverydatetime").setValue();
                    } else {
                        Xrm.Page.getControl("gems_tissuerecoverydatetime").clearNotification();
                    }

                    // if (dateofdeathnotification != null || dateofdeathnotification != undefined) {
                    // monthDeath = dateofdeathnotification.getMonth() + 1;
                    // dayDeath = dateofdeathnotification.getDate();
                    // }

                    // if (dayTissue == dayDeath) {
                    // var deathnoticationmillsec = dateofdeathnotification.getTime() + 1800000;
                    // Xrm.Page.getAttribute("gems_tissuerecoverydatetime").setValue(deathnoticationmillsec);
                    // tissueRecoveryTimeSameDay = Xrm.Page.getAttribute("gems_tissuerecoverydatetime").getValue();
                    // flag = true;
                    // }

                    // if (dateofdeathnotification != null && monthTissue <= monthDeath) {
                    // if (flag != true) {
                    // if (tissueRecoveryTime < dateofdeathnotification) {
                    // Xrm.Page.getControl("gems_tissuerecoverydatetime").setNotification("The tissue recovery date/time should be later than Death Notification Date/Time.");
                    // Xrm.Page.getAttribute("gems_tissuerecoverydatetime").setValue();
                    // } else {
                    // Xrm.Page.getControl("gems_tissuerecoverydatetime").clearNotification();
                    // }
                    // }
                    // }
                }
            }

            Xrm.Page.getAttribute("gems_corneapreservationdatetime").setValue(tissueRecoveryTime);
        }
    }
}
