﻿//gems_MedicalReviewReadOnlyFields

function MakeReadOnlyFields() {
    //debugger;
    if (Xrm.Page.getControl('header_process_gems_medicalreviewcompletedby') != null) {
        Xrm.Page.getControl('header_process_gems_medicalreviewcompletedby').setDisabled(true);
    }
    if (Xrm.Page.getControl('header_process_gems_donoreligibility') != null) {
        Xrm.Page.getControl('header_process_gems_donoreligibility').setDisabled(true);
    }
    if (Xrm.Page.getControl('header_process_gems_serologytestdoneby') != null) {
        Xrm.Page.getControl('header_process_gems_serologytestdoneby').setDisabled(true);
    }
}

//set the fields CorneaPreservationTime and TotalCoolingTime
function setDurationfields() {
    debugger;
    if (Xrm.Page.context.client.getClient() != "Mobile") {
        if (Xrm.Page.getAttribute("gems_corneapreservationdatetime").getValue() != null && Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath").getValue() != null) {

            var corneaprevtime = Xrm.Page.getAttribute("gems_corneapreservationdatetime").getValue();
            var datetimeofdeath = Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath").getValue();

            var corneapreservationtime = calculateMinutes(corneaprevtime, datetimeofdeath);

            Xrm.Page.getAttribute("gems_deathcorneapreservationtime").setValue(corneapreservationtime);
        }

        if (Xrm.Page.getAttribute("gems_datetimebodysubjectedcooling").getValue() != null && Xrm.Page.getAttribute("gems_datetimebodyremovedcooling").getValue() != null) {
            var bodysubjecttocoolingtime = Xrm.Page.getAttribute("gems_datetimebodysubjectedcooling").getValue();
            var bodyremovedcoolingtime = Xrm.Page.getAttribute("gems_datetimebodyremovedcooling").getValue();

            var totalcoolingtime = calculateMinutes(bodyremovedcoolingtime, bodysubjecttocoolingtime);

            Xrm.Page.getAttribute("gems_totalcoolingtime").setValue(totalcoolingtime);
        }

        if (Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath") != null && Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath") != undefined) {
            if (Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath").getValue() != null && Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath").getValue() != undefined) {
                var dateTimeofDeath = Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath").getValue();
                var currentDateTime = new Date();
                var deathToCurrentTime = calculateMinutes(currentDateTime, dateTimeofDeath);
                Xrm.Page.getAttribute("gems_deathcurrenttime").setValue(deathToCurrentTime);
            }
        }

        if (Xrm.Page.getAttribute("gems_datetimebodysubjectedcooling") != null && Xrm.Page.getAttribute("gems_datetimebodysubjectedcooling") != undefined) {
            var dateTimeofDeath;
            if (Xrm.Page.getAttribute("gems_datetimebodysubjectedcooling").getValue() != null && Xrm.Page.getAttribute("gems_datetimebodysubjectedcooling").getValue() != undefined) {
                if (Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath") != null && Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath") != undefined) {
                    if (Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath").getValue() != null && Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath").getValue() != undefined) {
                        dateTimeofDeath = Xrm.Page.getAttribute("gems_recoverymedicaldatetimedeath").getValue();
                        var dateTimeBodySubjectedCooling = Xrm.Page.getAttribute("gems_datetimebodysubjectedcooling").getValue();
                        var deathCoolingStartTime = calculateMinutes(dateTimeBodySubjectedCooling, dateTimeofDeath);
                        Xrm.Page.getAttribute("gems_deathcoolingstarttime").setValue(deathCoolingStartTime);
                    }
                }
            }
        }
    }

    Xrm.Page.data.entity.save();
}

function calculateMinutes(date1, date2) {
    // Convert both dates to milliseconds
    var largeDate = date1.getTime();
    var smallDate = date2.getTime();
    var difference = 0;

    if (smallDate > largeDate) {
        difference = 0;
    } else {
        // Calculate the difference in milliseconds
        difference = largeDate - smallDate;

        // Convert back to minutes  and return
    }
    var minutes = difference / (1000 * 60);
    return minutes;
}


function hideShowSerologyTestFields(event) {
    var sampleQualified = false;
    if (Xrm.Page.getAttribute("gems_hemodilutioncompleted") != null && Xrm.Page.getAttribute("gems_hemodilutioncompleted") != undefined) {
        if (Xrm.Page.getAttribute("gems_hemodilutioncompleted").getValue() != null && Xrm.Page.getAttribute("gems_hemodilutioncompleted").getValue() != undefined) {
            if (Xrm.Page.getAttribute("gems_hemodilutioncompleted").getValue() == true) {
                Xrm.Page.getControl("gems_samplequalified").setVisible(true);

                if (Xrm.Page.getAttribute("gems_samplequalified").getValue() != null && Xrm.Page.getAttribute("gems_samplequalified").getValue() != undefined) {
                    sampleQualified = Xrm.Page.getAttribute("gems_samplequalified").getValue();
                }

                if (sampleQualified) {
                    Xrm.Page.getControl("gems_bloodsamplemissingunsuitable").setVisible(true);
                    if (Xrm.Page.getAttribute("gems_bloodsamplemissingunsuitable").getValue()) {
                        Xrm.Page.getControl("gems_hemodilutioncompletedby").setVisible(true);
                        Xrm.Page.getControl("gems_serologytestdoneby").setVisible(true);
                        Xrm.Page.getControl("gems_datetimeserologyreview").setVisible(true);
                        Xrm.Page.getControl("gems_serologytestapprovedby").setVisible(true);
                        Xrm.Page.getControl("gems_hcv").setVisible(true);
                        Xrm.Page.getControl("gems_hbsag").setVisible(true);
                        Xrm.Page.getControl("gems_syphilis").setVisible(true);
                        Xrm.Page.getControl("gems_hiv_i_ii").setVisible(true);
                        Xrm.Page.getControl("gems_reason").setVisible(false);
                        Xrm.Page.getControl("gems_otherreason").setVisible(false);
                    }
                    else {
                        if (event != "onload") {
                            Xrm.Page.getAttribute("gems_datetimeserologyreview").setValue();
                            Xrm.Page.getAttribute("gems_serologytestdoneby").setValue();
                            Xrm.Page.getAttribute("gems_serologytestapprovedby").setValue();
                            Xrm.Page.getAttribute("gems_hcv").setValue();
                            Xrm.Page.getAttribute("gems_hbsag").setValue();
                            Xrm.Page.getAttribute("gems_syphilis").setValue();
                            Xrm.Page.getAttribute("gems_hiv_i_ii").setValue();
                            Xrm.Page.getAttribute("gems_reason").setValue();
                            Xrm.Page.getAttribute("gems_otherreason").setValue();
                        }

                        Xrm.Page.getControl("gems_hemodilutioncompletedby").setVisible(true);
                        Xrm.Page.getControl("gems_serologytestdoneby").setVisible(false);
                        Xrm.Page.getControl("gems_datetimeserologyreview").setVisible(false);
                        Xrm.Page.getControl("gems_serologytestapprovedby").setVisible(false);
                        Xrm.Page.getControl("gems_hcv").setVisible(false);
                        Xrm.Page.getControl("gems_hbsag").setVisible(false);
                        Xrm.Page.getControl("gems_syphilis").setVisible(false);
                        Xrm.Page.getControl("gems_hiv_i_ii").setVisible(false);
                        Xrm.Page.getControl("gems_reason").setVisible(true);
                        Xrm.Page.getControl("gems_otherreason").setVisible(false);
                        if (Xrm.Page.getAttribute("gems_reason").getValue() == 4) {
                            Xrm.Page.getControl("gems_otherreason").setVisible(true);
                        }
                        else {
                            Xrm.Page.getControl("gems_otherreason").setVisible(false);
                        }
                    }
                } else {
                    if (event != "onload") {
                        Xrm.Page.getAttribute("gems_datetimeserologyreview").setValue();
                        Xrm.Page.getAttribute("gems_serologytestdoneby").setValue();
                        Xrm.Page.getAttribute("gems_serologytestapprovedby").setValue();
                        Xrm.Page.getAttribute("gems_hcv").setValue();
                        Xrm.Page.getAttribute("gems_hbsag").setValue();
                        Xrm.Page.getAttribute("gems_syphilis").setValue();
                        Xrm.Page.getAttribute("gems_hiv_i_ii").setValue();
                        Xrm.Page.getAttribute("gems_bloodsamplemissingunsuitable").setValue();
                        Xrm.Page.getAttribute("gems_reason").setValue();
                        Xrm.Page.getAttribute("gems_otherreason").setValue();
                    }

                    Xrm.Page.getControl("gems_hemodilutioncompletedby").setVisible(true);
                    Xrm.Page.getControl("gems_serologytestdoneby").setVisible(false);
                    Xrm.Page.getControl("gems_datetimeserologyreview").setVisible(false);
                    Xrm.Page.getControl("gems_serologytestapprovedby").setVisible(false);
                    Xrm.Page.getControl("gems_hcv").setVisible(false);
                    Xrm.Page.getControl("gems_hbsag").setVisible(false);
                    Xrm.Page.getControl("gems_syphilis").setVisible(false);
                    Xrm.Page.getControl("gems_hiv_i_ii").setVisible(false);
                    Xrm.Page.getControl("gems_bloodsamplemissingunsuitable").setVisible(false);
                    Xrm.Page.getControl("gems_reason").setVisible(false);
                    Xrm.Page.getControl("gems_otherreason").setVisible(false);
                }
            } else {
                if (event != "onload") {
                    Xrm.Page.getAttribute("gems_hemodilutioncompletedby").setValue();
                    Xrm.Page.getAttribute("gems_serologytestdoneby").setValue();
                    Xrm.Page.getAttribute("gems_datetimeserologyreview").setValue();
                    Xrm.Page.getAttribute("gems_serologytestapprovedby").setValue();
                    Xrm.Page.getAttribute("gems_hcv").setValue();
                    Xrm.Page.getAttribute("gems_hbsag").setValue();
                    Xrm.Page.getAttribute("gems_syphilis").setValue();
                    Xrm.Page.getAttribute("gems_hiv_i_ii").setValue();
                    Xrm.Page.getAttribute("gems_bloodsamplemissingunsuitable").setValue();
                    Xrm.Page.getAttribute("gems_reason").setValue();
                    Xrm.Page.getAttribute("gems_otherreason").setValue();
                }

                Xrm.Page.getControl("gems_hemodilutioncompletedby").setVisible(false);
                Xrm.Page.getControl("gems_samplequalified").setVisible(false);
                Xrm.Page.getControl("gems_serologytestdoneby").setVisible(false);
                Xrm.Page.getControl("gems_datetimeserologyreview").setVisible(false);
                Xrm.Page.getControl("gems_serologytestapprovedby").setVisible(false);
                Xrm.Page.getControl("gems_hcv").setVisible(false);
                Xrm.Page.getControl("gems_hbsag").setVisible(false);
                Xrm.Page.getControl("gems_syphilis").setVisible(false);
                Xrm.Page.getControl("gems_hiv_i_ii").setVisible(false);
                Xrm.Page.getControl("gems_bloodsamplemissingunsuitable").setVisible(false);
                Xrm.Page.getControl("gems_reason").setVisible(false);
                Xrm.Page.getControl("gems_otherreason").setVisible(false);
            }
        }
    }
}