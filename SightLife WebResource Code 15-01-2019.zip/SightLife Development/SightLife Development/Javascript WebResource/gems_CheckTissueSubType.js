﻿function CheckTissueSubTypeForRequestTissue(context) {
    debugger;
    var saveEvt = context.getEventArgs();
    //var tissueLookupField = new Array;
    //var requestLookupField = new Array; 

    var tTissueType = 0;
    var rTissueType = 0;
    var tTissueSubType = 0;
    var rTissueSubType = 0;

    var tissueLookupField = Xrm.Page.getAttribute('gems_tissuedetail').getValue();
    var requestLookupField = Xrm.Page.getAttribute('gems_requestdetail').getValue();

    if (tissueLookupField != null && requestLookupField != null) {
        var tissueLookupID = tissueLookupField[0].id;
        var colsTissue = ["gems_tissuetype", "gems_tissuesubtype"];
        var retrievedTissue = XrmServiceToolkit.Soap.Retrieve("gems_tissuedetail", tissueLookupID, colsTissue);
        tTissueType = retrievedTissue.attributes.gems_tissuetype.value;
        if (retrievedTissue.attributes.gems_tissuesubtype != undefined)
            tTissueSubType = retrievedTissue.attributes.gems_tissuesubtype.value;
        RequestCall(requestLookupField, tTissueType, tTissueSubType, saveEvt);
    }
}
function RequestCall(requestLookupField, tTissueType, tTissueSubType, saveEvt) {
    var requestLookupID = requestLookupField[0].id;
    var colsRequest = ["gems_tissuetype", "gems_tissuesubtype"];
    var retrievedRequest = XrmServiceToolkit.Soap.Retrieve("gems_request", requestLookupID, colsRequest);
    rTissueType = retrievedRequest.attributes.gems_tissuetype.value;
    if (retrievedRequest.attributes.gems_tissuesubtype != undefined)
        rTissueSubType = retrievedRequest.attributes.gems_tissuesubtype.value;
    if (tTissueType == null || rTissueType == null || tTissueSubType == null || rTissueSubType == null) {
        alert('The Tissue Type and Request do not match!');
        saveEvt.preventDefault();

    }
    else {
        if (tTissueType != rTissueType || tTissueSubType != rTissueSubType) {
            alert('The Tissue Type and Request do not match!');
            saveEvt.preventDefault();
        }
    }

}

//------------------------------------------------------------------------------------------------------------------------------------------------

//Set by default Placed:Transplant data for Tissue Disposition field if  no data is selected for Tissue Disposition
function defaultTissueDispositionValue() {
    debugger;
    var tissueDisposition = Xrm.Page.getAttribute("gems_tissuedisposition").getValue();
    if (tissueDisposition == null && tissueDisposition == undefined) {
        Xrm.Page.getAttribute("gems_tissuedisposition").setValue(2);
    }
}