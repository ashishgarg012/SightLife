﻿//Library Name:gems_printAllFormsOnSinglePage-------10 April
//Added report button in Dashboard ribbon workbench "Print All Forms On Single Page"
//...for that passed parametres to each button

var reportId;
var ReportName;

function printAllFormsOnSinglePage(ReportName) {
    debugger;
    retriveReportID(ReportName);
    var reportUrl = Xrm.Page.context.getClientUrl() + "/crmreports/viewer/viewer.aspx?action=run&id=%7b" + reportId + "%7d";

    window.open(reportUrl, "reportwindow", "resizable=1,width=1000,height=750");
}


function retriveReportID(name) {
    debugger;
    var ReportName = name;
    var fetchxml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
  "<entity name='report'>" +
    "<attribute name='name' />" +
       "<attribute name='filename' />" +
       "<attribute name='reportid' />" +
     "<order attribute='name' descending='false' />" +
    "<filter type='and'>" +
      "<condition attribute='name' operator='eq' value='" + ReportName + "' />" +
     "</filter>" +
  "</entity>" +
"</fetch>";

    var data = XrmServiceToolkit.Soap.Fetch(fetchxml);
    if (data.length > 0) {
        if (data[0].attributes["reportid"] != null && data[0].attributes["reportid"] != undefined) {
            reportId = data[0].attributes["reportid"].value;
        }
    }
}

