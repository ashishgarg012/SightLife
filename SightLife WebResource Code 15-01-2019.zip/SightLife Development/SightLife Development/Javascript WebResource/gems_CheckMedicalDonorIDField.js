﻿function CheckDonorIDFieldRequired(context) {
    var donorID = Xrm.Page.getAttribute("gems_name").getValue();
    var tissueimportedVal = Xrm.Page.getAttribute("gems_tissueimported").getValue();
    var saveEvt = context.getEventArgs();
    if (tissueimportedVal == false) {
        if (donorID == null) {
            alert("We cannot create a Medical Review without a corresponding Referral and Recovery! If you are trying to add an imported tissue, please set Tissue Imported to Yes and then Save.");
            saveEvt.preventDefault();
        }
    }
}