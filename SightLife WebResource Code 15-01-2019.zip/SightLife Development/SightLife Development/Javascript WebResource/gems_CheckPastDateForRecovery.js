﻿function ValidatePreservationMediaExpiration() {
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();

    if (dd < 10) {
        dd = '0' + dd
    }

    if (mm < 10) {
        mm = '0' + mm
    }
    today = mm + '/' + dd + '/' + yyyy;
    var currentDate = new Date(today);
    var compareDate = Xrm.Page.getAttribute('gems_preservationmediaexpirationdate').getValue();
    if (compareDate != null && compareDate < currentDate) {
        alert('Please enter an appropriate Date and Time ! ')
        Xrm.Page.getAttribute('gems_preservationmediaexpirationdate').setValue();
    }
}

