﻿function MakeButtonPostCutEvaluationForm() {
    var atrname = "gems_postcutevalform";
    if (document.getElementById(atrname) != null) {
        var fieldId = "field" + atrname;
        if (document.getElementById(fieldId) == null) {
            var elementId = document.getElementById(atrname + "_d");
            var div = document.createElement("div");
            div.style.width = "150px";
            div.style.textAlign = "right";
            div.style.display = "inline";

            childDiv = elementId.getElementsByTagName('div')[0]
            childDiv.style.display = "none";

            var formId = Xrm.Page.ui.getFormType();
            var preCut = Xrm.Page.getAttribute('gems_precut').getValue();
            if (formId == "2") {
                elementId.appendChild(div, elementId);
                div.innerHTML = '<button id="' + fieldId + '"  type="button" style="margin-left: 3px;width:40%" >Print Post Cut Evaluation Form</button>';
                document.getElementById(atrname).style.width = "0%";
                document.getElementById(fieldId).onclick = function () { PrintPostCutEvaluationForm(); };
            }
        }
    }
}

function PrintPostCutEvaluationForm() {
    var GetEntityGuid = Xrm.Page.data.entity.getId();
    var orgUrl = Xrm.Page.context.getServerUrl();

    reportUrl = orgUrl + "/crmreports/viewer/viewer.aspx?action=run&helpID=Post_Cut_Evaluation_Form.rdl&id=%7bB36D12CD-A885-E411-80CB-001DD8B71C89%7d&records=" + GetEntityGuid + "&p:records=" + GetEntityGuid + "";
    window.open(reportUrl, "reportwindow", "resizable=1,width=1000,height=750");

}