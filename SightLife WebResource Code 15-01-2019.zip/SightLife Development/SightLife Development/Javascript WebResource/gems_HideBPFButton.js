﻿function HideBPFPlusbutton() {
    //debugger;
    var head = parent.document.getElementsByTagName('head')[0];
    var link = parent.document.createElement('link');
    var path = Xrm.Page.context.getClientUrl() + "/WebResources/gems_HideBPFCreateButton";
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = path;
    link.media = 'all';
    head.appendChild(link);

}