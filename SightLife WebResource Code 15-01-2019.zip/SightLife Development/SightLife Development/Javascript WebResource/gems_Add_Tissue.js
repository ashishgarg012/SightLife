﻿function AddTissue() {
    var atrname = "gems_Add_Tissue";
    if (document.getElementById(atrname) != null) {
        var fieldId = "field" + atrname;
        if (document.getElementById(fieldId) == null) {
            var elementId = document.getElementById(atrname + "_d");
            var div = document.createElement("div");
            div.style.width = "100px";
            div.style.textAlign = "right";
            div.style.display = "inline";

            childDiv = elementId.getElementsByTagName('div')[0]
            childDiv.style.display = "none";

            elementId.appendChild(div, elementId);
            div.innerHTML = '<button id="' + fieldId + '"  type="button" style="margin-left: 3px;width: 40%;" >Add Tissue</button>';
            document.getElementById(atrname).style.width = "0%";
            document.getElementById(fieldId).onclick = function () { YourOnClickFunction(); };
        }
    }
}
function YourOnClickFunction() {
    alert('hi');
}
