﻿function onLoadBusinessProcessCollapsed() {
    //debugger;
    var formType = Xrm.Page.ui.getFormType();
    if (formType == "2") {

        if (Xrm.Page.ui.process != null) {
            Xrm.Page.ui.process.setDisplayState("collapsed");
        }

    }
}

function ShowVisible() {

    $("#header_process_d").on('click', function () {
        debugger;
        document.getElementById('processControlCollapsibleArea').style.display = "block";
        document.getElementById('processControlScrollPane').style.display = "block";
        document.getElementById('processScrollbarMask').style.display = "block";
        document.getElementById('processControlScrollbarContainer').style.display = "block";
        document.getElementById('collapsibleView').style.display = "block";
        document.getElementById('processControlCollapsibleArea').style.borderBottomWidth = "2px";
    });

    //document.getElementById('header_process_d').click(function() {


    //});


}

//Notification for Mobile
function MobileNotificationRecovery() {
    if (Xrm.Page.context.client.getClient() == "Mobile") {
        //Xrm.Page.ui.setFormNotification("Recovery Data is available in read only mode on mobile / tablet.", "WARNING");
    }
}

function MobileNotificationMedicalReview() {
    if (Xrm.Page.context.client.getClient() == "Mobile") {
        Xrm.Page.ui.setFormNotification("Medical Review Data is available in read only mode on mobile / tablet.", "WARNING");
    }
}

function showhideBusinessProcessFlow() {
    debugger;
    if (Xrm.Page.context.client.getClient() == "Mobile") {
        Xrm.Page.ui.process.setVisible(false);
    } else {
        Xrm.Page.ui.process.setVisible(true);
    }
}

function getTissueEvalDetails() {
    var donorId = Xrm.Page.data.entity.getId();//Xrm.Page.getAttribute("gems_medicalreviewidid").getValue()[0].id;

    var tissueEvalXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
		"<entity name='gems_tissuedetail'>" +
		"<attribute name='gems_tissuedetailid' />" +
		"<attribute name='gems_name' />" +
		"<attribute name='createdon' />" +
		"<attribute name='gems_eye' />" +
		"<order attribute='gems_name' descending='false' />" +
		"<filter type='and'>" +
        "<condition attribute='statecode' operator='eq' value='0' />" +
        "<condition attribute='gems_tissuereturned' operator='eq' value='0' />" +
		"<condition attribute='gems_medicalreviewidid' operator='eq' value='" + donorId + "' />" +
		"</filter>" +
		"</entity>" +
		"</fetch>";

    var result = XrmServiceToolkit.Soap.Fetch(tissueEvalXml);

    return result;
}

function hidePlusFromSubgrid() {

    var tissueEvalDetails = getTissueEvalDetails();

    var rowCount = Xrm.Page.getControl("TissueDetails").getGrid().getTotalRecordCount();

    var unitGrid = window.parent.document.getElementById("TissueDetails");
    if (tissueEvalDetails.length >= 10) {
        if (unitGrid.control == null || unitGrid.control == "undefined") {
            setTimeout('hidePlusFromSubgrid()', 500);
        }
        else {
            unitGrid.control.get_addContextualButton().style.display = "none";
        }
    }

    unitGrid.control.add_onRefresh(hidePlusFromSubgrid);

    /*var unitGrid = window.parent.document.getElementById("TissueDetails");
	var rowCount = Xrm.Page.getControl("TissueDetails").getGrid().getTotalRecordCount();
    if (rowCount >= 2) {
        window.parent.document.getElementById("TissueDetails").control.get_addContextualButton().style.display = "none";
    }
    else {
        //var shipmentbutton = shipmentgrid.control.get_addContextualButton();
		setTimeout('hidePlusFromUnitSubgrid()', 500);
    }*/
}