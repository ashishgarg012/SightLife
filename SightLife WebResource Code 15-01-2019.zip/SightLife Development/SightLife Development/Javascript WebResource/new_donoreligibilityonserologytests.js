﻿var hbsag;
var hcv;
var hiv;
var syphilis;

function getSerologyTestFields() {
    if (Xrm.Page.getAttribute("gems_hbsag") != null & Xrm.Page.getAttribute("gems_hbsag") != undefined) {
        hbsag = Xrm.Page.getAttribute("gems_hbsag").getValue();
    }
    if (Xrm.Page.getAttribute("gems_hcv") != null & Xrm.Page.getAttribute("gems_hcv") != undefined) {
        hcv = Xrm.Page.getAttribute("gems_hcv").getValue();
    }
    if (Xrm.Page.getAttribute("gems_hiv_i_ii") != null & Xrm.Page.getAttribute("gems_hiv_i_ii") != undefined) {
        hiv = Xrm.Page.getAttribute("gems_hiv_i_ii").getValue();
    }
    if (Xrm.Page.getAttribute("gems_syphilis") != null & Xrm.Page.getAttribute("gems_syphilis") != undefined) {
        syphilis = Xrm.Page.getAttribute("gems_syphilis").getValue();
    }
}

function donorelgibiltyserology(attribute) {
    debugger;
    getSerologyTestFields();

    if (hbsag == 1 || hcv == 1 || hiv == 1 || syphilis == 1) {

        //        alert("If any of the Serology tests is selected as positive, the Donor is not eligible for donating tissue. Therefore, you cannot select Donor Eligibility as 'Eligible' on this screen.");
        Xrm.Page.getAttribute("gems_donoreligibility").setValue(2);
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(true);
    }
    else {
        Xrm.Page.getAttribute("gems_donoreligibility").setValue(1);
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(false);
    }

    if (Xrm.Page.getAttribute(attribute).getValue() == 1) {
        alert("If any of the Serology tests is selected as positive, the Donor is not eligible for donating tissue. Therefore, you cannot select Donor Eligibility as 'Eligible' on this screen.");
    }
}

function donorelgibiltyserologyhbsag() {
    debugger;
    getSerologyTestFields();

    if (hbsag == 1) {

        alert("If any of the Serology tests is selected as positive, the Donor is not eligible for donating tissue. Therefore, you cannot select Donor Eligibility as 'Eligible' on this screen.");
        Xrm.Page.getAttribute("gems_donoreligibility").setValue(2);
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(true);
    }

    else {
        Xrm.Page.getAttribute("gems_donoreligibility").setValue(null);
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(false);
    }
}

function donorelgibiltyserologyhcv() {
    debugger;
    getSerologyTestFields();

    if (hcv == 1) {

        alert("If any of the Serology tests is selected as positive, the Donor is not eligible for donating tissue. Therefore, you cannot select Donor Eligibility as 'Eligible' on this screen.");
        Xrm.Page.getAttribute("gems_donoreligibility").setValue(2);
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(true);
    }

    else {
        Xrm.Page.getAttribute("gems_donoreligibility").setValue(null);
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(false);
    }
}

function donorelgibiltyserologyhiv() {
    debugger;
    getSerologyTestFields();

    if (hiv == 1) {

        alert("If any of the Serology tests is selected as positive, the Donor is not eligible for donating tissue. Therefore, you cannot select Donor Eligibility as 'Eligible' on this screen.");
        Xrm.Page.getAttribute("gems_donoreligibility").setValue(2);
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(true);
    }

    else {
        Xrm.Page.getAttribute("gems_donoreligibility").setValue(null);
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(false);
    }
}

function donorelgibiltyserologysyphilis() {
    debugger;
    getSerologyTestFields();

    if (syphilis == 1) {

        alert("If any of the Serology tests is selected as positive, the Donor is not eligible for donating tissue. Therefore, you cannot select Donor Eligibility as 'Eligible' on this screen.");
        Xrm.Page.getAttribute("gems_donoreligibility").setValue(2);
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(true);
    }

    else {
        Xrm.Page.getAttribute("gems_donoreligibility").setValue(null);
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(false);
    }
}


function lockdonorEligibilityField() {

    getSerologyTestFields();
    if (hbsag == 1 || hcv == 1 || hiv == 1 || syphilis == 1)
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(true);
    else
        Xrm.Page.getControl("gems_donoreligibility").setDisabled(false);


}

//JS to update owner of medical review record instead of process "Update owner when Medical Review is updated"

function updateMedicalReviewOwner() {
    debugger;
    prodJatinGuid = '{1AC83408-B755-E611-80C6-000D3AF00778}';
    prodAmanGuid = '{6354AA4F-F913-E611-80C4-000D3AF00778}';
    devJatinGuid = '{CDD96B02-BB55-E611-80C6-000D3AF000DC}';
    devAmanGuid = '{617421F8-A683-E611-80C9-000D3AF01A8F}';
    qaJatinGuid = '{1F1E0E29-B955-E611-80C6-000D3AF00061}';
    qaAmanGuid = '{0DED30C3-390E-E611-80C3-000D3AF00061}';

    var UsedID = Xrm.Page.context.getUserId();
    var UserName = Xrm.Page.context.getUserName();

    if (UsedID == prodJatinGuid || UsedID == prodAmanGuid || UsedID == devJatinGuid || UsedID == devAmanGuid || UsedID == qaJatinGuid || UsedID == qaAmanGuid) {
    } else {
        Xrm.Page.getAttribute("ownerid").setValue([{ id: UsedID, name: UserName, entityType: "systemuser" }]);
    }

    //var owner = Xrm.Page.data.entity.attributes.get("ownerid").getValue()[0].name;
    //var ownerid = Xrm.Page.data.entity.attributes.get("ownerid").getValue()[0].id;
    //alert("owner is :" + owner);
    //alert("owner id is :" + ownerid);
    Xrm.Page.data.save();
}

