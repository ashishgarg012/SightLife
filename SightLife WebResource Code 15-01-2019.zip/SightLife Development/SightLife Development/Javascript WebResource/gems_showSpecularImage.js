﻿//To open dialoge box & show Annotation(precut) image
function showImage(buttonName) {
    debugger;
    var parameters = {};
    var objectID = Xrm.Page.data.entity.getId();
    parameters["regardingObjectId_0"] = objectID;
    Xrm.Utility.openWebResource("gems_showEntityImage.html?typename=gems_tissuedetail&id=" + objectID, buttonName, 600, 600);
}

////To open dialoge box & show Annotation(precut) image
//function showImage(buttonName) {
//    debugger;
//    var objID= Xrm.Page.data.entity.getId();
//    var addParams = objID + "&buttonName=" + buttonName;
//    var webResourceName = "/WebResources/gems_showEntityImage.html?pagemode=iframe&data=" + encodeURIComponent(addParams);
//    var dialogOption = new parent.Xrm.DialogOptions;
//    dialogOption.width = 400; dialogOption.height = 400;
//    parent.Xrm.Internal.openDialog(webResourceName, dialogOption, null, null);
//}
