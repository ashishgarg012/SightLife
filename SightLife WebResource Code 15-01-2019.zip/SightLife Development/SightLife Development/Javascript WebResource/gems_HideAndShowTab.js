﻿function ShowHideTab() {

    //var optionValue=Xrm.Page.getAttribute('gems_donoreligibility').getValue();  
    //if (optionValue==2) 
    //{
    //   Xrm.Page.ui.tabs.get('Tab_ReasonForIneleigible').setVisible(true);  
    //}
    //else
    //{
    //    Xrm.Page.ui.tabs.get('Tab_ReasonForIneleigible').setVisible(false);  
    //}
}

function ShowHideTissueImport() {
    if (Xrm.Page.context.client.getClient() != "Mobile") {
        var optionValue_TI = Xrm.Page.getAttribute('gems_tissueimported').getValue();
        if (optionValue_TI == true) {
            Xrm.Page.ui.tabs.get('Tab_TissueImport_General').setVisible(true);
        }
        else {
            Xrm.Page.ui.tabs.get('Tab_TissueImport_General').setVisible(false);
        }
    }
}




function DonorIdImportedtissue() {
    var type = Xrm.Page.ui.getFormType();
    // if(type ==2)
    // {
    var TissueImportStatus = Xrm.Page.getAttribute('gems_tissueimported').getValue();
    if (TissueImportStatus == true) {
        if (Xrm.Page.getAttribute('gems_donorid_importedtissue') != null && Xrm.Page.getAttribute('gems_donorid_importedtissue').getValue() != null) {
            var DonorId_ImportedTiss = Xrm.Page.getAttribute('gems_donorid_importedtissue').getValue();
            Xrm.Page.getAttribute('gems_name').setValue(DonorId_ImportedTiss);
            Xrm.Page.getAttribute('gems_name').setSubmitMode('always');
        }
    }
    //}
}