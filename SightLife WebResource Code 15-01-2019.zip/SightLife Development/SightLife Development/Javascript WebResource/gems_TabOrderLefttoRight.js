﻿function EntityTabOrderLefttoRight() {
    debugger;
    for (var i = 0; i < crmForm.all.length; i++) {
        var element = crmForm.all[i];
        if (element.tabIndex && element.tabIndex != "0") {
            if (element.className == 'ms-crm-Hidden-NoBehavior')
                continue;
            if (element.tagName == 'A') {
                if (element.className != 'ms-crm-InlineTabHeaderText')
                    continue;
            }
            element.tabIndex = 10000 + (i * 10);
        }
    }
}
