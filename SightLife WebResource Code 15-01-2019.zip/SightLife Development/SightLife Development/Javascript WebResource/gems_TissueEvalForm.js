﻿//gems_TissueEvalForm

var SightLife_TissueEval = (function (SightLife_TissueEval) {
    SightLife_TissueEval.showDiscardReasons = function showDiscardReasons() {
        var gems_approvaloutcome = Xrm.Page.getAttribute("gems_approvaloutcome").getValue();
        var gems_tissuedisposition = Xrm.Page.getAttribute("gems_tissuedisposition").getValue();

        if (gems_tissuedisposition == 5)
            //gems_approvaloutcome == 2 &&
        {
            Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("sec_Discard_reasons").setVisible(true);
        } else {
            Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("sec_Discard_reasons").setVisible(false);
        }
    };

    return SightLife_TissueEval;
}
	(SightLife_TissueEval || {}));

SightLife_TissueEval.showDiscardReasons

function getTissueEvalDetails() {
    var donorId;
    var result = {};
    if (Xrm.Page.getAttribute("gems_medicalreviewidid") != null && Xrm.Page.getAttribute("gems_medicalreviewidid") != undefined) {
        if (Xrm.Page.getAttribute("gems_medicalreviewidid").getValue() != null && Xrm.Page.getAttribute("gems_medicalreviewidid").getValue() != undefined) {
            donorId = Xrm.Page.getAttribute("gems_medicalreviewidid").getValue()[0].id;

            var tissueEvalXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
				"<entity name='gems_tissuedetail'>" +
				"<attribute name='gems_tissuedetailid' />" +
				"<attribute name='gems_name' />" +
				"<attribute name='createdon' />" +
				"<attribute name='gems_eye' />" +
				"<order attribute='gems_name' descending='false' />" +
				"<filter type='and'>" +
				"<condition attribute='statecode' operator='eq' value='0' />" +
				"<condition attribute='gems_tissuereturned' operator='eq' value='0' />" +
				"<condition attribute='gems_medicalreviewidid' operator='eq' value='" + donorId + "' />" +
				"</filter>" +
				"</entity>" +
				"</fetch>";

            result = XrmServiceToolkit.Soap.Fetch(tissueEvalXml);
        }
    }
    return result;
}

function getTissues() {
    debugger;

    var tissueId = Xrm.Page.getAttribute("gems_name").getValue();

    var tissuesFetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
		"<entity name='gems_tissuedetail'>" +
		"<attribute name='gems_tissuedetailid' />" +
		"<attribute name='gems_name' />" +
		"<attribute name='gems_medicalreviewidid' />" +
		"<attribute name='createdon' />" +
		"<order attribute='gems_name' descending='false' />" +
		"<filter type='and'>" +
		"<condition attribute='gems_name' operator='eq' value='" + tissueId + "' />" +
		"<condition attribute='gems_tissuereturned' operator='eq' value='1' />" +
		"</filter>" +
		"</entity>" +
		"</fetch>";

    var tissueResult = XrmServiceToolkit.Soap.Fetch(tissuesFetchXML);

    if (tissueResult.length > 0) {
        var tissueReturned = Xrm.Page.getAttribute("gems_tissuereturned").getValue();
        if (tissueId != (tissueId + "(R)") && tissueReturned != 1) {
            Xrm.Page.getAttribute("gems_name").setValue(tissueId + "(R)");
        }

        Xrm.Page.data.entity.save();
    }
}

function tissueEvaluation() {
    var tissueEvalDetails = getTissueEvalDetails();

    var formType = Xrm.Page.ui.getFormType();

    if (formType == 1) {
        if (tissueEvalDetails.length > 0 && tissueEvalDetails.length < 10) {
            var eye = tissueEvalDetails[0].attributes.gems_eye.value;
            if (eye == 1) { //OD = 1 & OS = 2
                Xrm.Page.getAttribute("gems_eye").setValue(2);
                //Xrm.Page.getControl("gems_eye").setDisabled(true);
            } else if (eye == 2) {
                Xrm.Page.getAttribute("gems_eye").setValue(1);
                //Xrm.Page.getControl("gems_eye").setDisabled(true);
            }
        } else if (tissueEvalDetails.length >= 10) {
            Xrm.Utility.alertDialog("You have already added two tissues for the selected Donor.");
            //context.getEventArgs().preventDefault();
        }
    }
}

function onSaveTissueEval(context) {
    var tissueEvalDetails = getTissueEvalDetails();
    if (tissueEvalDetails.length > 10) {
        Xrm.Utility.alertDialog("You have already added ten tissues for the selected Donor.");
        context.getEventArgs().preventDefault();
    }
}

function tissueReturnChecklistForm() {
    debugger;
    var clientURL = Xrm.Page.context.getClientUrl();
    var documentHtml;
    var tissueReturnData = {};

    if (Xrm.Page.getAttribute("gems_tissuereturned").getValue() == true) {
        if (Xrm.Page.getAttribute("gems_tissuereevaluated") != null && Xrm.Page.getAttribute("gems_tissuereevaluated") != undefined) {
            if (Xrm.Page.getAttribute("gems_tissuereevaluated").getValue != null && Xrm.Page.getAttribute("gems_tissuereevaluated").getValue != undefined) {
                if (Xrm.Page.getAttribute("gems_tissuereevaluated").getValue == 2) {
                    if (Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != null && Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != undefined) {
                        Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setVisible(false);
                    }
                } else if (Xrm.Page.getAttribute("gems_tissuereevaluated").getValue() == 1) {
                    if (Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != null && Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != undefined) {
                        Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setVisible(true);
                    }
                }
            } else {
                if (Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != null && Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != undefined) {
                    Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setVisible(false);
                }
            }
        }

        tissueReturnData["tissueGuid"] = Xrm.Page.data.entity.getId();
        tissueReturnData["gems_name"] = Xrm.Page.getAttribute("gems_name").getValue();
        tissueReturnData["gems_tamperevidentseal"] = Xrm.Page.getAttribute("gems_tamperevidentseal").getValue();
        tissueReturnData["gems_tissueiscold"] = Xrm.Page.getAttribute("gems_tissueiscold").getValue();
        tissueReturnData["gems_vialorviewingchamber"] = Xrm.Page.getAttribute("gems_vialorviewingchamber").getValue();
        tissueReturnData["gems_accompanyingpaperwork"] = Xrm.Page.getAttribute("gems_accompanyingpaperwork").getValue();
        tissueReturnData["gems_optisolcheckedvisually"] = Xrm.Page.getAttribute("gems_optisolcheckedvisually").getValue();

        if (Xrm.Page.getAttribute("gems_datetimereturnedtoeyebank") != null && Xrm.Page.getAttribute("gems_datetimereturnedtoeyebank") != undefined) {
            if (Xrm.Page.getAttribute("gems_datetimereturnedtoeyebank").getValue() != null && Xrm.Page.getAttribute("gems_datetimereturnedtoeyebank").getValue() != undefined) {
                var dateTimeReturnVal = Xrm.Page.getAttribute("gems_datetimereturnedtoeyebank").getValue();
                var date = dateTimeReturnVal.getDate();
                var month = dateTimeReturnVal.getMonth() + 1;
                var year = dateTimeReturnVal.getFullYear();
                var hours = dateTimeReturnVal.getHours();
                var minutes = dateTimeReturnVal.getMinutes();
                tissueReturnData["gems_datetimereturnedtoeyebank"] = date + "-" + month + "-" + year + " " + hours + ":" + minutes;
            } else {
                tissueReturnData["gems_datetimereturnedtoeyebank"] = "";
            }
        } else {
            tissueReturnData["gems_datetimereturnedtoeyebank"] = "";
        }

        if (Xrm.Page.getAttribute("gems_tissuereturncompletedby").getValue() != null && Xrm.Page.getAttribute("gems_tissuereturncompletedby").getValue() != undefined) {
            tissueReturnData["gems_tissuereturncompletedby"] = Xrm.Page.getAttribute("gems_tissuereturncompletedby").getValue()[0].id;
        } else {
            tissueReturnData["gems_tissuereturncompletedby"] = null;
        }

        if (Xrm.Page.getAttribute("gems_tissuesentto").getValue() != null && Xrm.Page.getAttribute("gems_tissuesentto").getValue() != undefined) {
            tissueReturnData["gems_tissuesentto"] = Xrm.Page.getAttribute("gems_tissuesentto").getValue()[0].id;
        } else {
            tissueReturnData["gems_tissuesentto"] = null;
        }

        if (Xrm.Page.getAttribute("gems_datetimetissuesent") != null && Xrm.Page.getAttribute("gems_datetimetissuesent") != undefined) {
            if (Xrm.Page.getAttribute("gems_datetimetissuesent").getValue() != null && Xrm.Page.getAttribute("gems_datetimetissuesent").getValue() != undefined) {
                var dateTimeReturnVal = Xrm.Page.getAttribute("gems_datetimetissuesent").getValue();
                var date = dateTimeReturnVal.getDate();
                var month = dateTimeReturnVal.getMonth() + 1;
                var year = dateTimeReturnVal.getFullYear();
                var hours = dateTimeReturnVal.getHours();
                var minutes = dateTimeReturnVal.getMinutes();
                tissueReturnData["gems_datetimetissuesent"] = date + "-" + month + "-" + year + " " + hours + ":" + minutes;
            } else {
                tissueReturnData["gems_datetimetissuesent"] = "";
            }
        } else {
            tissueReturnData["gems_datetimetissuesent"] = "";
        }

        tissueReturnData["gems_reasonforreturn"] = Xrm.Page.getAttribute("gems_reasonforreturn").getValue();
        tissueReturnData["gems_methodoftransporttoeyebank"] = Xrm.Page.getAttribute("gems_methodoftransporttoeyebank").getValue();
        tissueReturnData["gems_storageconditionsduringabsence"] = Xrm.Page.getAttribute("gems_storageconditionsduringabsence").getValue();
        tissueReturnData["formOpenType"] = "checkbox";

        var res = JSON.stringify(tissueReturnData);
        documentHtml = clientURL + "/WebResources/gems_receiptoftissuereturnform?Data=" + res;
        var settingsobject = new parent.Xrm.DialogOptions;
        settingsobject.height = 550; //window.screen.availHeight - Math.ceil(window.screen.availHeight / 3);
        settingsobject.width = 900; //window.screen.availWidth - Math.ceil(window.screen.availWidth / 2);
        if (Xrm.Page.getAttribute("gems_tissuereturned") != null && Xrm.Page.getAttribute("gems_tissuereturned") != undefined) {
            if (Xrm.Page.getAttribute("gems_tissuereturned").getValue() != null && Xrm.Page.getAttribute("gems_tissuereturned").getValue() != undefined) {
                if (Xrm.Page.getAttribute("gems_tissuereturned").getValue() == true) {
                    //if (Xrm.Page.getAttribute("gems_tissuereevaluated") != null && Xrm.Page.getAttribute("gems_tissuereevaluated") != undefined) {
                    //    Xrm.Page.getAttribute("gems_tissuereevaluated").setValue(2);
                    //}
                    Xrm.Internal.openDialog(documentHtml, settingsobject, null, null, callBackFunction);
                    Xrm.Page.ui.controls.get("WebResource_receiptoftissuereturnformbutton").setVisible(true);
                } else {
                    //if (Xrm.Page.getAttribute("gems_tissuereevaluated") != null && Xrm.Page.getAttribute("gems_tissuereevaluated") != undefined) {
                    //    Xrm.Page.getAttribute("gems_tissuereevaluated").setValue(1);
                    //}
                    Xrm.Page.ui.controls.get("WebResource_receiptoftissuereturnformbutton").setVisible(false);
                }
            }
        }
    }
    else {
        if (Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != null && Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != undefined) {
            Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setVisible(false);
            //Xrm.Page.getControl("gems_tissuereturned").setFocus();
        }
    }
}

function hideShowTissueReturnFormButton() {
    if (Xrm.Page.getAttribute("gems_tissuereturned").getValue() == true) {
        Xrm.Page.ui.controls.get("WebResource_receiptoftissuereturnformbutton").setVisible(true);
    } else {
        Xrm.Page.ui.controls.get("WebResource_receiptoftissuereturnformbutton").setVisible(false);
    }
}

function callBackFunction(results) {
    debugger;
    var res = JSON.parse(JSON.stringify(results));

    var tissueAttributes = ["gems_accompanyingpaperwork", "gems_methodoftransporttoeyebank", "gems_optisolcheckedvisually", "gems_reasonforreturn", "gems_storageconditionsduringabsence", "gems_tamperevidentseal", "gems_tissueiscold", "gems_tissuesentto", "gems_vialorviewingchamber"];

    for (var i = 0; i < tissueAttributes.length; i++) {
        var attribute = tissueAttributes[i];
        var val = res[attribute];
        if (val == "True") {
            val = true;
        } else if (val == "False") {
            val = false;
        }
        Xrm.Page.getAttribute(attribute).setValue(val);
    }

    var dateAttrArr = ["gems_datetimetissuesent", "gems_datetimereturnedtoeyebank"];
    for (var j = 0; j < dateAttrArr.length; j++) {
        var dateAttribute = dateAttrArr[j];
        var valDate = res[dateAttribute];
        if (valDate != "") {
            var arr = valDate.split("-");
            valDate = arr[1] + "-" + arr[0] + "-" + arr[2];
            var setDate = new Date(valDate);
            Xrm.Page.getAttribute(dateAttribute).setValue(setDate);
        }
    }

    var contactArr = new Array();
    contactArr[0] = new Object();
    contactArr[0].id = res["gems_tissuereturncompletedbyid"];
    contactArr[0].name = res["gems_tissuereturncompletedbyname"];
    contactArr[0].entityType = "contact";
    if (res["gems_tissuereturncompletedbyid"] != null && res["gems_tissuereturncompletedbyid"] != undefined) {
        Xrm.Page.getAttribute("gems_tissuereturncompletedby").setValue(contactArr);
    }

    var orgArr = new Array();
    orgArr[0] = new Object();
    orgArr[0].id = res["gems_tissuesenttoid"];
    orgArr[0].name = res["gems_tissuesenttoname"];
    orgArr[0].entityType = "contact";
    if (res["gems_tissuesenttoid"] != null && res["gems_tissuesenttoid"] != undefined) {
        Xrm.Page.getAttribute("gems_tissuesentto").setValue(orgArr);
    }
    Xrm.Page.data.entity.save();
    setTimeout("", 2000);

    //var tissueReturnConfirmation = confirm("Form submitted.");// \nDo you want to create new tissue eval record?");
    //if (tissueReturnConfirmation == true) {
    //    setTimeout(openEntityForm, 3000);
    //}
}

function openEntityForm() {
    debugger;
    setTimeout('confirmTissueReEvaluated()', 1000);

}

function confirmTissueReEvaluated() {
    if (Xrm.Page.getAttribute("gems_tissuereevaluated") != null && Xrm.Page.getAttribute("gems_tissuereevaluated") != undefined) {
        if (Xrm.Page.getAttribute("gems_tissuereevaluated").getValue() != null && Xrm.Page.getAttribute("gems_tissuereevaluated").getValue() != undefined) {
            if (Xrm.Page.getAttribute("gems_tissuereevaluated").getValue() == 2) {
                //var tissueReturnConfirmation = confirm("Do you want to create new tissue eval record?");
                showConfirmDialog();

            } else if (Xrm.Page.getAttribute("gems_tissuereevaluated").getValue() == 1) {
                if (Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != null && Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != undefined) {
                    Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setVisible(true);
                    Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setFocus();
                }
            } else {
                if (Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != null && Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != undefined) {
                    Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setVisible(false);
                    Xrm.Page.getControl("gems_tissuereturned").setFocus();
                }
            }
        }
    }
}

function showConfirmDialog() {
    debugger;
    Xrm.Utility.confirmDialog("If you click OK, a new tissue evaluation screen will open for the returned tissue. Do you wish to create a new tissue evaluation record?",//"Do you want to create new tissue evaluation record?",
		function () {
		    debugger;
		    if (Xrm.Page.getControl("gems_tissuereturned") != null && Xrm.Page.getControl("gems_tissuereturned") != undefined) {
		        Xrm.Page.getControl("gems_tissuereturned").setFocus();
		    }

		    if (Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != null && Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != undefined) {
		        Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setVisible(false);
		    }

		    setTimeout(Xrm.Page.data.entity.save(), 2000);
		    var tissueGuid;
		    var entity = new XrmServiceToolkit.Soap.BusinessEntity("gems_tissuedetail");
		    entity.attributes["gems_eye"] = {
		        value: Xrm.Page.getAttribute("gems_eye").getValue(),
		        type: "OptionSetValue"
		    };
		    entity.attributes["gems_tissuesubtype"] = {
		        value: Xrm.Page.getAttribute("gems_tissuesubtype").getValue(),
		        type: "OptionSetValue"
		    };
		    entity.attributes["gems_tissuetype"] = {
		        value: Xrm.Page.getAttribute("gems_tissuetype").getValue(),
		        type: "OptionSetValue"
		    };
		    entity.attributes["gems_medicalreviewidid"] = {
		        id: Xrm.Page.getAttribute("gems_medicalreviewidid").getValue()[0].id,
		        logicalName: "gems_medicalreview",
		        type: 'EntityReference'
		    };
		    entity.attributes["gems_donorid"] = Xrm.Page.getAttribute("gems_donorid").getValue();
		    entity.attributes["gems_name"] = Xrm.Page.getAttribute("gems_name").getValue();
		    entity.attributes["gems_tissuesuitability"] = {
		        value: Xrm.Page.getAttribute("gems_tissuesuitability").getValue(),
		        type: "OptionSetValue"
		    };
		    entity.attributes["gems_tamperevidentseal"] = {
		        value: Xrm.Page.getAttribute("gems_tamperevidentseal").getValue(),
		        type: 'boolean'
		    };
		    entity.attributes["gems_tissueiscold"] = {
		        value: Xrm.Page.getAttribute("gems_tissueiscold").getValue(),
		        type: 'boolean'
		    };
		    entity.attributes["gems_vialorviewingchamber"] = {
		        value: Xrm.Page.getAttribute("gems_vialorviewingchamber").getValue(),
		        type: 'boolean'
		    };
		    entity.attributes["gems_accompanyingpaperwork"] = {
		        value: Xrm.Page.getAttribute("gems_accompanyingpaperwork").getValue(),
		        type: 'boolean'
		    };
		    entity.attributes["gems_optisolcheckedvisually"] = {
		        value: Xrm.Page.getAttribute("gems_optisolcheckedvisually").getValue(),
		        type: 'boolean'
		    };
		    entity.attributes["gems_datetimereturnedtoeyebank"] = Xrm.Page.getAttribute("gems_datetimereturnedtoeyebank").getValue();
		    if (Xrm.Page.getAttribute("gems_tissuereturncompletedby").getValue() != null && Xrm.Page.getAttribute("gems_tissuereturncompletedby").getValue() != undefined) {
		        entity.attributes["gems_tissuereturncompletedby"] = {
		            id: Xrm.Page.getAttribute("gems_tissuereturncompletedby").getValue()[0].id,
		            logicalName: "contact",
		            type: 'EntityReference'
		        };
		    }

		    if (Xrm.Page.getAttribute("gems_tissuesentto").getValue() != null && Xrm.Page.getAttribute("gems_tissuesentto").getValue() != undefined) {
		        entity.attributes["gems_tissuesentto"] = {
		            id: Xrm.Page.getAttribute("gems_tissuesentto").getValue()[0].id,
		            logicalName: "contact",
		            type: 'EntityReference'
		        };
		    }
		    entity.attributes["gems_datetimetissuesent"] = Xrm.Page.getAttribute("gems_datetimetissuesent").getValue();
		    entity.attributes["gems_reasonforreturn"] = Xrm.Page.getAttribute("gems_reasonforreturn").getValue();
		    entity.attributes["gems_methodoftransporttoeyebank"] = Xrm.Page.getAttribute("gems_methodoftransporttoeyebank").getValue();
		    entity.attributes["gems_storageconditionsduringabsence"] = Xrm.Page.getAttribute("gems_storageconditionsduringabsence").getValue();

		    tissueGuid = XrmServiceToolkit.Soap.Create(entity);

		    //To deactivate old tissue for returned tissue
		    if (tissueGuid != null && tissueGuid != undefined) {
		        EntityObjectId = Xrm.Page.data.entity.getId();
		        XrmServiceToolkit.Soap.SetState("gems_tissuedetail", EntityObjectId, 1, 2);
		    }
		    //To deactivate old tissue for returned tissue

		    var updateTissueEval = new XrmServiceToolkit.Soap.BusinessEntity("gems_tissuedetail", tissueGuid);
		    updateTissueEval.attributes["gems_name"] = Xrm.Page.getAttribute("gems_name").getValue() + "(R)";
		    var updateResponse = XrmServiceToolkit.Soap.Update(updateTissueEval);

		    var windowOptions = {
		        openInNewWindow: true
		    };

		    Xrm.Utility.openEntityForm("gems_tissuedetail", tissueGuid, null, windowOptions);
		},
		function () {
		    Xrm.Page.getAttribute("gems_tissuereevaluated").setValue(1);
		    if (Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != null && Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != undefined) {
		        Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setVisible(true);
		        Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setFocus();
		    }
		    Xrm.Page.data.entity.save();
		});
}

function setVisibilityReasonForTissuereEvaluatedNo() {
    debugger;
    if (Xrm.Page.getAttribute("gems_tissuereevaluated") != null && Xrm.Page.getAttribute("gems_tissuereevaluated") != undefined) {
        if (Xrm.Page.getAttribute("gems_tissuereevaluated").getValue() == 1 && Xrm.Page.getControl("gems_tissuereevaluated").getVisible() == true) {
            if (Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != null && Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != undefined) {
                Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setVisible(true);
                //Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setFocus();
            }
        } else {
            if (Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != null && Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != undefined) {
                Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setVisible(false);
                //Xrm.Page.getControl("gems_tissuereturned").setFocus();
            }
        }
    } else {
        if (Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != null && Xrm.Page.getControl("gems_reasonfortissuereevaluatedno") != undefined) {
            Xrm.Page.getControl("gems_reasonfortissuereevaluatedno").setVisible(false);
            //Xrm.Page.getControl("gems_tissuereturned").setFocus();
        }
    }
}

function getTissueEvalRecords() {
    var donorId;
    var result = {};
    if (Xrm.Page.getAttribute("gems_medicalreviewidid") != null && Xrm.Page.getAttribute("gems_medicalreviewidid") != undefined) {
        if (Xrm.Page.getAttribute("gems_medicalreviewidid").getValue() != null && Xrm.Page.getAttribute("gems_medicalreviewidid").getValue() != undefined) {
            donorId = Xrm.Page.getAttribute("gems_medicalreviewidid").getValue()[0].id;

            var tissueEvalXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
				"<entity name='gems_tissuedetail'>" +
				"<attribute name='gems_tissuedetailid' />" +
				"<attribute name='gems_name' />" +
				"<attribute name='createdon' />" +
				"<attribute name='gems_eye' />" +
				"<order attribute='gems_name' descending='false' />" +
				"<filter type='and'>" +
				"<condition attribute='gems_medicalreviewidid' operator='eq' value='" + donorId + "' />" +
				"</filter>" +
				"</entity>" +
				"</fetch>";

            result = XrmServiceToolkit.Soap.Fetch(tissueEvalXml);
        }
    }
    return result;
}

function showOpenOriginalTissueButton() {
    debugger;
    var tissueReturn = false;
    var index = -1;
    var tissueEvalID;
    var tissueIdVal;
    var returnedTissueCreated = false;

    var tissueEvalDetails = getTissueEvalRecords();

    if (Xrm.Page.getAttribute("gems_name") != null && Xrm.Page.getAttribute("gems_name") != undefined) {
        if (Xrm.Page.getAttribute("gems_name").getValue() != null && Xrm.Page.getAttribute("gems_name").getValue() != undefined) {
            tissueEvalID = Xrm.Page.getAttribute("gems_name").getValue();
            //   index = tissueEvalID.search("(R)");
            if (tissueEvalID.substring(tissueEvalID.length - 3) == "(R)") {
                index = 1;
            }
        }
    }

    if (index < 0) {
        if (tissueEvalDetails.length > 0) {
            for (var i = 0; i < tissueEvalDetails.length; i++) {
                if (tissueEvalDetails[i].attributes.gems_name != null && tissueEvalDetails[i].attributes.gems_name != undefined) {
                    if (tissueEvalDetails[i].attributes.gems_name.value != null && tissueEvalDetails[i].attributes.gems_name.value != undefined) {
                        tissueIdVal = tissueEvalDetails[i].attributes.gems_name.value;
                        if (tissueEvalID + "(R)" == tissueIdVal) {
                            returnedTissueCreated = true;
                            break;
                        }
                    }
                }
            }
        }
    }

    if (Xrm.Page.getAttribute("gems_tissuereturned") != null && Xrm.Page.getAttribute("gems_tissuereturned") != undefined) {
        if (Xrm.Page.getAttribute("gems_tissuereturned").getValue() != null && Xrm.Page.getAttribute("gems_tissuereturned").getValue() != undefined) {
            tissueReturn = Xrm.Page.getAttribute("gems_tissuereturned").getValue();
        }
    }

    if ((returnedTissueCreated && tissueReturn) || index > 0) {
        Xrm.Page.ui.controls.get("WebResource_openoriginaltissueevalform").setVisible(true);
    } else {
        Xrm.Page.ui.controls.get("WebResource_openoriginaltissueevalform").setVisible(false);
    }

    if (tissueReturn || index > 0) {
        Xrm.Page.ui.controls.get("WebResource_receiptoftissuereturnformbutton").setVisible(true);
    } else {
        Xrm.Page.ui.controls.get("WebResource_receiptoftissuereturnformbutton").setVisible(false);
    }

    if (index > 0) {
        Xrm.Page.getControl("gems_tissuereturned").setDisabled(true);
    } else {
        Xrm.Page.getControl("gems_tissuereturned").setDisabled(false);
    }
}


function concatSurgeryType() {
    var surgeryType = "";
    if (Xrm.Page.getAttribute("gems_pk") != null && Xrm.Page.getAttribute("gems_pk") != undefined) {
        if (Xrm.Page.getAttribute("gems_pk").getValue() != null && Xrm.Page.getAttribute("gems_pk").getValue() != undefined) {
            if (Xrm.Page.getAttribute("gems_pk").getValue()) {
                surgeryType += "PK, ";
            }

        }
    }

    if (Xrm.Page.getAttribute("gems_ek") != null && Xrm.Page.getAttribute("gems_ek") != undefined) {
        if (Xrm.Page.getAttribute("gems_ek").getValue() != null && Xrm.Page.getAttribute("gems_ek").getValue() != undefined) {
            if (Xrm.Page.getAttribute("gems_ek").getValue()) {
                surgeryType += "EK, ";
            }

        }
    }

    if (Xrm.Page.getAttribute("gems_kla") != null && Xrm.Page.getAttribute("gems_kla") != undefined) {
        if (Xrm.Page.getAttribute("gems_kla").getValue() != null && Xrm.Page.getAttribute("gems_kla").getValue() != undefined) {
            if (Xrm.Page.getAttribute("gems_kla").getValue()) {
                surgeryType += "KLA, ";
            }

        }
    }

    if (Xrm.Page.getAttribute("gems_therapeutic") != null && Xrm.Page.getAttribute("gems_therapeutic") != undefined) {
        if (Xrm.Page.getAttribute("gems_therapeutic").getValue() != null && Xrm.Page.getAttribute("gems_therapeutic").getValue() != undefined) {
            if (Xrm.Page.getAttribute("gems_therapeutic").getValue()) {
                surgeryType += "Tectonic/Therapeutic, ";
            }

        }
    }

    if (Xrm.Page.getAttribute("gems_alk") != null && Xrm.Page.getAttribute("gems_alk") != undefined) {
        if (Xrm.Page.getAttribute("gems_alk").getValue() != null && Xrm.Page.getAttribute("gems_alk").getValue() != undefined) {
            if (Xrm.Page.getAttribute("gems_alk").getValue()) {
                surgeryType += "ALK, ";
            }

        }
    }

    if (Xrm.Page.getAttribute("gems_kpro") != null && Xrm.Page.getAttribute("gems_kpro") != undefined) {
        if (Xrm.Page.getAttribute("gems_kpro").getValue() != null && Xrm.Page.getAttribute("gems_kpro").getValue() != undefined) {
            if (Xrm.Page.getAttribute("gems_kpro").getValue()) {
                surgeryType += "K-Pro";
            }

        }
    }

    if (Xrm.Page.getAttribute("gems_surgerytype") != null && Xrm.Page.getAttribute("gems_surgerytype") != undefined) {
        Xrm.Page.getAttribute("gems_surgerytype").setValue(surgeryType);
    }
}

//-------------------------------------------------------------------------------------------
function onchangeTissueDisposition() {
    //debugger;
    var tissueDispositionValue;
    if (Xrm.Page.getAttribute("gems_tissuedisposition") != null && Xrm.Page.getAttribute("gems_tissuedisposition") != undefined) {
        if (Xrm.Page.getAttribute("gems_tissuedisposition").getValue() != null && Xrm.Page.getAttribute("gems_tissuedisposition").getValue() != undefined) {
            tissueDispositionValue = Xrm.Page.getAttribute("gems_tissuedisposition").getValue();

            if (tissueDispositionValue == 5) {
                Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("DiscardReason").setVisible(true);
                Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("Sub-Categories").setVisible(true);
            } else {
                Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("DiscardReason").setVisible(false);
                Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("Sub-Categories").setVisible(false);
            }
        } else {
            Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("DiscardReason").setVisible(false);
            Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("Sub-Categories").setVisible(false);
        }
    } else {
        Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("DiscardReason").setVisible(false);
        Xrm.Page.ui.tabs.get("tab_ApprovalOutcome").sections.get("Sub-Categories").setVisible(false);
    }
}


function clearSubCategories() {
    var subCategoryFields = ["gems_medicalcontraindication", "gems_issueswithcommunicabledisease", "gems_medicalrecordautopsyfinds", "gems_unknowncodmedicalreasons", "gems_lowcellcount", "gems_stromalscars", "gems_infiltrates", "gems_opacities", "gems_poortissuequality", "gems_positiveserology", "gems_positiveserologyfornonrequiredtests", "gems_inadequatebloodsample", "gems_bloodsamplemissing", "gems_bloodsamplenotsuitablefortesting", "gems_sterilitycompromisediscardreason", "gems_mediaissue", "gems_tissuedamageduetotransportationlogistics", "gems_coldchainbreak", "gems_preservationissue", "gems_surgeonissue", "gems_tissuedamageduringtissuepreparation", "gems_postdistributionissues", "gems_tissueexpiry"];
    for (var i = 0; i < subCategoryFields.length; i++) {
        if (Xrm.Page.getAttribute(subCategoryFields[i]) != null && Xrm.Page.getAttribute(subCategoryFields[i]) != undefined) {
            Xrm.Page.getAttribute(subCategoryFields[i]).setValue(false);
        }
    }
}

function formatDiscardReasonSection() {
    if (parent.document.getElementsByName("DiscardReason")[0] != null && parent.document.getElementsByName("DiscardReason")[0] != undefined) {
        parent.document.getElementsByName("DiscardReason")[0].style.paddingBottom = '0';
    }

    if (parent.document.getElementsByName("Sub-Categories")[0] != null && parent.document.getElementsByName("Sub-Categories")[0] != undefined) {
        parent.document.getElementsByName("Sub-Categories")[0].style.marginTop = '0';
        parent.document.getElementsByName("Sub-Categories")[0].style.paddingTop = '0';
    }
}

//--------On Load uncheck checkbox-----------

function clearValue() {
    debugger;
    if (Xrm.Page.getAttribute("new_tissuereevaluatedfornonplacedtissue").getValue() == true) {
        Xrm.Page.getAttribute("new_tissuereevaluatedfornonplacedtissue").setValue(false);
        Xrm.Page.data.entity.save();
    }
}
